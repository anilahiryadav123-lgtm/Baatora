(function(){
if(window.__btgen)return;window.__btgen=1;
try{Notification.requestPermission=function(){return Promise.resolve('denied')};}catch(e){}
try{Object.defineProperty(Notification,'permission',{get:function(){return 'denied'}});}catch(e){}
var host=(location.hostname||'').toLowerCase();
if(/(^|\.)(youtube\.com|google\.[a-z.]+|instagram\.com|facebook\.com|twitter\.com|x\.com|wikipedia\.org|amazon\.[a-z.]+|flipkart\.com|whatsapp\.com|github\.com)$/.test(host))return;
var adHost=/(doubleclick|googlesyndication|adservice\.google|exoclick|exosrv|exdynsrv|juicyads|trafficstars|clickadu|hilltopads|adcash|popcash|propellerads|onclkds|clickaine|realsrv|magsrv|tsyndicate|adsterra|a-ads|adskeeper|richpush|admaven|ad-maven|bidvertiser|plugrush|ero-advertising|yllix|popads|monetag|profitableratecpm|highperformanceformat|effectivegatecpm|oclasrv|taboola|outbrain|mgid|revcontent|zedo|criteo|moatads|adnxs|4rabet|1xbet|mostbet|1win|melbet|parimatch|linebet|betwinner)/i;
var bad=/(welcome pack|bonus up to|\d{2,4}\s?% bonus|casino|jackpot|you(?:'|\u2019)?ve won|you have won|congratulations.{0,40}(prize|won|winner)|click allow|press allow|allow notifications|your (phone|device) (is|has been) (infected|hacked)|virus detected)/i;
var fakeHuman=/(verify you.?re human|i.?m human|i am human)/i;
function kill(e){try{e.style.setProperty('display','none','important');e.style.setProperty('pointer-events','none','important');}catch(x){}}
function rect(e){return e.getBoundingClientRect();}
var pending=0;
function scan(){
 pending=0;
 try{
  var killed=0;
  document.querySelectorAll('iframe').forEach(function(f){var s=f.src||'';if(s&&adHost.test(s)){kill(f);killed++;}});
  document.querySelectorAll('ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[class*="pop-under"],[id*="popunder"],[class*="ad-overlay"],[id*="ad-overlay"],a[href*="exoclick"],a[href*="juicyads"],a[href*="clickadu"],a[href*="adsterra"],a[href*="hilltopads"]').forEach(function(e){kill(e);});
  if(!document.body)return;
  var all=document.body.querySelectorAll('div,section,aside,a,iframe,ins,span');
  var lim=Math.min(all.length,1800);
  for(var i=0;i<lim;i++){
   var e=all[i];
   if(e.style&&e.style.display==='none')continue;
   var cs=getComputedStyle(e);
   var pos=cs.position;
   if(pos!=='fixed'&&pos!=='absolute'&&pos!=='sticky')continue;
   var z=parseInt(cs.zIndex)||0;
   if(z<100)continue;
   var r=rect(e);
   if(r.width<40||r.height<20)continue;
   var t=(e.innerText||'').slice(0,800);
   if(t){
     if(bad.test(t)){kill(e);killed++;continue;}
     if(fakeHuman.test(t)&&e.querySelector('input[type=password]')){kill(e);killed++;continue;}
   }else if(pos==='fixed'||pos==='absolute'){
     var full=r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9;
     var clear=parseFloat(cs.opacity)<=0.05||cs.backgroundColor==='rgba(0, 0, 0, 0)'||cs.backgroundColor==='transparent';
     if(full&&z>=1000&&clear&&(e.tagName==='A'||e.tagName==='DIV'||e.tagName==='IFRAME')&&!e.querySelector('video,canvas')){kill(e);killed++;}
   }
  }
  if(killed>0){
   for(var j=0;j<lim;j++){
    var b=all[j];var c2=getComputedStyle(b);
    if(c2.position==='fixed'&&!(b.innerText||'').trim()&&(parseInt(c2.zIndex)||0)>=100){
     var rr=rect(b);
     if(rr.width>=innerWidth*0.9&&rr.height>=innerHeight*0.9&&!b.querySelector('video,canvas,img')) kill(b);
    }
   }
   document.body.style.setProperty('overflow','auto','important');
   document.documentElement.style.setProperty('overflow','auto','important');
  }
 }catch(x){}
}
function later(){if(!pending){pending=1;setTimeout(scan,700);}}
document.addEventListener('click',function(ev){
 try{var a=ev.target&&ev.target.closest&&ev.target.closest('a[href]');
  if(a&&a.target==='_blank'&&adHost.test(a.href)){ev.preventDefault();ev.stopPropagation();}}catch(e){}
},true);
try{new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
var n=0,iv=setInterval(function(){scan();if(++n>20)clearInterval(iv);},1500);
scan();
})();
