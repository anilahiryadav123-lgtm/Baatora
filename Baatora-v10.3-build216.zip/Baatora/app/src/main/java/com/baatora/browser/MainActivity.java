package com.baatora.browser;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.database.Cursor;
import android.graphics.drawable.Icon;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;
import androidx.webkit.WebViewCompat;
import java.io.OutputStream;
import java.util.Locale;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Baatora Browser — Made in India 🇮🇳
 * Created by Anil Yadav, Thane.
 */
public class MainActivity extends Activity {

    static class Tab {
        WebView web;
        boolean incognito;
        String title = "Home";
        Bitmap thumb;
        volatile String pageHost;
        String httpTried;
        boolean popup, popupDecided;
        String openerHost;
        final ArrayList<String> media = new ArrayList<>();
        final java.util.concurrent.ConcurrentHashMap<String, long[]> info = new java.util.concurrent.ConcurrentHashMap<>();
        volatile String pageUrl;
        String pendingUrl;
        volatile String pwNonce;
    }

    long lastPopup = 0;
    long lastTouchUp = 0;

    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        if (ev.getActionMasked() == android.view.MotionEvent.ACTION_UP) lastTouchUp = System.currentTimeMillis();
        return super.dispatchTouchEvent(ev);
    }
    String blobToken;

    static final String HOME = "file:///android_asset/home.html";
    static final String INCOG_HOME = HOME + "#incog";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
            "adsterra.com", "exoclick.com", "mgid.com", "revcontent.com", "zedo.com", "adcolony.com",
            "advertising.com", "adform.net", "criteo.com", "moatads.com", "scorecardresearch.com",
            "onclickads.net", "trafficjunky.net", "inmobi.com", "applovin.com", "unityads.unity3d.com",
            "exosrv.com", "exdynsrv.com", "juicyads.com", "trafficstars.com", "clickadu.com", "hilltopads.net",
            "adcash.com", "a-ads.com", "adskeeper.com", "richpush.co", "admaven.com", "ad-maven.com",
            "bidvertiser.com", "clickaine.com", "realsrv.com", "magsrv.com", "tsyndicate.com", "plugrush.com",
            "ero-advertising.com", "yllix.com", "monetag.com", "profitableratecpm.com", "highperformanceformat.com",
            "effectivegatecpm.com", "oclasrv.com", "onclkds.com", "adspyglass.com", "adxpansion.com", "popunderjs.com",
            "pushwhy.com", "notix.io", "pemsrv.com", "adtng.com", "trafficjunky.com", "juicyads.rocks", "adsco.re", "bidgear.com",
            "traffichaus.com", "rtbsystem.com", "creativecdn.com", "hilltopads.com", "nsfwads.com", "faphouse.com", "ptrfc.com", "pushnami.com", "cloudfront-ads.com", "o333o.com", "tapad.com"
    };
    static final String[] AD_PATHS = {"/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info", "/aclk",
            "/pcs/activeview", "/adview", "/ad_break", "/generate_204?ad"};
    static final String YT_ADBLOCK_JS =
            "(function(){if(window.__btab)return;window.__btab=1;" +
            "var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer," +
            "ad-slot-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer," +
            "ytm-promoted-sparkles-text-search-renderer,ytm-statement-banner-renderer,ytd-statement-banner-renderer," +
            "ytm-paid-content-overlay-renderer,ytm-mealbar-promo-renderer,.ytp-ad-overlay-container,.ytp-ad-image-overlay," +
            "#player-ads,#masthead-ad,#tads,#tadsb,#bottomads,[data-text-ad],.commercial-unit-mobile-top,.uEierd{display:none!important}';" +
            "var s=document.createElement('style');s.textContent=css;(document.head||document.documentElement).appendChild(s);" +
            "var muted=false;setInterval(function(){try{" +
            "var ad=document.querySelector('.ad-showing,.ad-interrupting');var v=document.querySelector('video');" +
            "if(ad&&v){muted=true;v.muted=true;try{v.playbackRate=16;}catch(e){}}" +
            "else if(muted&&v){muted=false;v.muted=false;v.playbackRate=1;}" +
            "var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button," +
            ".ytp-ad-skip-button-slot button,.ytm-skip-ad-button,button[class*=skip-ad]');if(b)b.click();" +
            "}catch(e){}},250);})();";
    static final String[] MEDIA_EXT = {".mp4", ".webm", ".mkv", ".3gp", ".mov", ".m4v",
            ".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac", ".opus", ".m3u8"};
    /** Stream ke tukde (init-v1-a1.mp4, seg-1.m4s ...) alag file nahi hote, inhe list me nahi dikhate. */
    static final java.util.regex.Pattern SEGMENT = java.util.regex.Pattern.compile(
            "(^|/)(init|seg|segment|chunk|frag|fragment)([-_.]?\\d+)?([-_][^/]*)?\\.(mp4|m4s|m4a|m4v|aac|ts)$|\\.(m4s|ts)$",
            java.util.regex.Pattern.CASE_INSENSITIVE);
    static final String NIGHT_JS =
            "(function(on){var id='baatora-night';var s=document.getElementById(id);" +
            "if(on){if(!s){s=document.createElement('style');s.id=id;" +
            "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}" +
            "img,video,picture,canvas,iframe,svg image,[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s);}}else if(s){s.remove();}})(%s);";
    static final String MEDIA_JS =
            "(function(){var o=[];function a(u){if(u&&/^https?:/i.test(u)&&o.indexOf(u)<0)o.push(u);}" +
            "document.querySelectorAll('video,audio,source').forEach(function(e){a(e.currentSrc);a(e.src);});" +
            "document.querySelectorAll('a[href]').forEach(function(e){" +
            "if(/\\.(mp4|webm|mkv|3gp|mov|m4v|mp3|m4a|aac|ogg|wav|flac|opus|m3u8)(\\?|$)/i.test(e.href))a(e.href);});" +
            "return JSON.stringify(o.slice(0,30));})()";

    static final int REQ_FILE = 1, REQ_VOICE = 2, REQ_WEB_PERM = 10, REQ_GEO = 11, REQ_STORAGE = 12, REQ_VPN = 13, REQ_AIVOICE = 14, REQ_MIC = 15, REQ_TONE = 16;

    final ArrayList<Tab> tabs = new ArrayList<>();
    int current = -1;
    SharedPreferences prefs;
    String mobileUA;
    volatile boolean adBlock = false; // Ad Block: default OFF, Settings se ON (Pop-up blocker nahi hai)
    boolean loading, appFull;
    long lastBack;
    Screens screens;

    View topBar, bottomBar, findBar;
    FrameLayout webContainer, fullscreenContainer, splash;
    SwipeRefreshLayout swipe;
    EditText urlBar, findInput;
    ImageView lockIcon, btnRefresh, btnBack, btnForward;
    ProgressBar progress;
    TextView tabCount, findCount, mediaFab;

    View customView;
    WebChromeClient.CustomViewCallback customCallback;
    ValueCallback<Uri[]> fileCallback;
    PermissionRequest pendingPermission;
    GeolocationPermissions.Callback geoCallback;
    String geoOrigin;
    TextToSpeech tts;
    final java.util.concurrent.atomic.AtomicInteger blockedPending = new java.util.concurrent.atomic.AtomicInteger();
    boolean barHidden;
    BroadcastReceiver dlReceiver;

    // ───────────────────────── LIFECYCLE ─────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installCrashLogger();
        Ui.density = getResources().getDisplayMetrics().density;
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("baatora", MODE_PRIVATE);
        // Purani galti: "turbo" naam me download list (text) bhi save hoti thi aur setting (on/off) bhi → Settings kholte hi crash
        try {
            Object old = prefs.getAll().get("turbo");
            if (old instanceof String) prefs.edit().putString("turbo_jobs", (String) old).remove("turbo").apply();
        } catch (Exception ignored) {}
        Ui.applyMode(prefs.getString("mode", "default"), prefs.getString("theme", "original"));
        applyDynamic();
        L.set(prefs.getString("lang", "english"));
        screens = new Screens(this);
        ai = new AiChat(this, screens);
        pw = new Passwords(this);


        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        findBar = findViewById(R.id.findBar);
        splash = findViewById(R.id.splash);
        webContainer = findViewById(R.id.webContainer);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);
        swipe = findViewById(R.id.swipe);
        urlBar = findViewById(R.id.urlBar);
        findInput = findViewById(R.id.findInput);
        lockIcon = findViewById(R.id.lockIcon);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);
        progress = findViewById(R.id.progress);
        tabCount = findViewById(R.id.tabCount);
        findCount = findViewById(R.id.findCount);
        mediaFab = findViewById(R.id.mediaFab);
        addAiEdge();

        adBlock = prefs.getBoolean("adblockOn", false);
        CookieManager.getInstance().setAcceptCookie(true);
        setupControls();
        setupSuggestions();
        applyBarPosition();
        applyThemeToViews();
        applyNavBar();

        String start = HOME;
        Intent in = getIntent();
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            start = in.getDataString();
        }
        final boolean viewIntent = !HOME.equals(start);
        final String startUrl = start;
        // Pehle intro screen turant dikhao; bhaari WebView kaam pehla frame ban jaane ke baad (startup me atak na aaye)
        splash.postDelayed(() -> {
            String ua = WebSettings.getDefaultUserAgent(this);
            mobileUA = ua.replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");
            if (viewIntent || !restoreSession()) createTab(startUrl, false, true);
            // WebView taiyaar hone ke BAAD intro animation — ab animation beech me nahi atakti
            playIntro();
        }, 40);
        // Bhaari kaam splash ke baad (startup me atak na aaye)
        splash.postDelayed(() -> {
            String proxy = prefs.getString("proxy", null);
            if (proxy != null) setProxy(proxy, true);
            registerDownloadWatcher();
            showLastCrash();
            versionNotes();
        }, 1500);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && "baatora.DOWNLOADS".equals(intent.getAction())) { screens.downloads(); return; }
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            createTab(intent.getDataString(), false, true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        WebView w = web();
        // Chhoti khidki (PiP) me video chalta rahe — tab page ko mat roko
        boolean pipNow = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode();
        if (w != null && !pipNow && !(videoPlaying && Build.VERSION.SDK_INT >= 26)) w.onPause();
        CookieManager.getInstance().flush();
        saveSession();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // PiP khidki band ki ya app peeche gaya → video rok do
        try { WebView w = web(); if (w != null) { w.onPause(); w.evaluateJavascript("document.querySelectorAll('video').forEach(function(v){v.pause()})", null); } } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebView w = web();
        if (w != null) w.onResume();
        Store.dataToday(this);
        refreshHomes();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing() && prefs.getBoolean("clearOnExit", false)) {
            save("history", new JSONArray());
            save("closed", new JSONArray());
            for (Tab t : tabs) t.web.clearCache(true);
            CookieManager.getInstance().removeSessionCookies(null);
        }
        try { if (dlReceiver != null) unregisterReceiver(dlReceiver); } catch (Exception ignored) {}
        if (tts != null) tts.shutdown();
        webContainer.removeAllViews();
        for (Tab t : tabs) t.web.destroy();
        tabs.clear();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (findBar.getVisibility() == View.VISIBLE) { closeFind(); return; }
        if (appFull) { setAppFull(false); return; }
        if (urlBar.hasFocus()) { urlBar.clearFocus(); hideKeyboard(); return; }
        WebView w = web();
        if (w != null && w.canGoBack()) { w.goBack(); return; }
        if (tabs.size() > 1) { closeTab(current); return; }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { super.onBackPressed(); return; }
        lastBack = now;
        toast("Press Back again to exit");
    }

    // ───────────────────────── 3D INTRO ─────────────────────────

    void playIntro() {
        float d = Ui.density;
        GradientDrawable bg = new GradientDrawable();
        bg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        bg.setGradientRadius(Ui.dp(480));
        bg.setColors(new int[]{0xFF2456E0, 0xFF0B1B66, 0xFF030820});
        splash.setBackground(bg);
        splash.setClipChildren(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        colLp.bottomMargin = Ui.dp(70);
        splash.addView(col, colLp);

        // 3D stage: do ghoomti rings + logo
        FrameLayout stage = new FrameLayout(this);
        stage.setClipChildren(false);
        col.addView(stage, new LinearLayout.LayoutParams(Ui.dp(300), Ui.dp(280)));
        RingView ringA = new RingView(this, 0xFFFF8A00, 0xFFFFC107, Ui.dp(5));
        RingView ringB = new RingView(this, 0xFF00E5FF, 0xFF2979FF, Ui.dp(4));
        ringA.setRotationX(68);
        ringB.setRotationX(68);
        ringB.setRotation(58);
        ringA.setCameraDistance(9000 * d);
        ringB.setCameraDistance(9000 * d);
        stage.addView(ringB, new FrameLayout.LayoutParams(Ui.dp(296), Ui.dp(296), Gravity.CENTER));
        stage.addView(ringA, new FrameLayout.LayoutParams(Ui.dp(244), Ui.dp(244), Gravity.CENTER));

        View glow = new View(this);
        GradientDrawable gl = new GradientDrawable();
        gl.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        gl.setGradientRadius(Ui.dp(110));
        gl.setColors(new int[]{0x8800E5FF, 0x00000000});
        glow.setBackground(gl);
        stage.addView(glow, new FrameLayout.LayoutParams(Ui.dp(240), Ui.dp(240), Gravity.CENTER));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setBackground(Ui.round(0x00000000, 40));
        logo.setClipToOutline(true);
        logo.setElevation(Ui.dp(22));
        stage.addView(logo, new FrameLayout.LayoutParams(Ui.dp(138), Ui.dp(138), Gravity.CENTER));

        // Naam: har akshar alag rang me, 3D palat kar aata hai
        final LinearLayout title = new LinearLayout(this);
        title.setOrientation(LinearLayout.HORIZONTAL);
        title.setGravity(Gravity.CENTER);
        title.setPadding(Ui.dp(10), 0, Ui.dp(16), 0);
        final String word = "Baatora";
        final int[] letterCols = {0xFFFFE082, 0xFFFFC107, 0xFFFFA000, 0xFFFF7A00, 0xFF80D8FF, 0xFF40C4FF, 0xFFFFFFFF};
        android.graphics.Typeface tf = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD_ITALIC);
        final ArrayList<TextView> letters = new ArrayList<>();
        for (int i = 0; i < word.length(); i++) {
            TextView ch = new TextView(this);
            ch.setText(String.valueOf(word.charAt(i)));
            ch.setTextSize(i == 0 ? 60 : 54);
            ch.setTypeface(tf);
            ch.setTextColor(letterCols[i]);
            ch.setIncludeFontPadding(false);
                        ch.setCameraDistance(9000 * d);
            title.addView(ch, new LinearLayout.LayoutParams(-2, -2));
            letters.add(ch);
        }
        col.addView(title, new LinearLayout.LayoutParams(-2, -2));

        // Tirange wali chamakti line
        final View bar = new View(this);
        GradientDrawable tri = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFF138808});
        tri.setCornerRadius(Ui.dp(3));
        bar.setBackground(tri);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(Ui.dp(190), Ui.dp(5));
        barLp.topMargin = Ui.dp(2);
        col.addView(bar, barLp);

        TextView tag = new TextView(this);
        tag.setText(L.t("tagline"));
        tag.setTextSize(16);
        tag.setTextColor(0xFFE3EBFF);
        tag.setGravity(Gravity.CENTER);
        tag.setLetterSpacing(0.03f);
        tag.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(6));
        col.addView(tag, new LinearLayout.LayoutParams(-1, -2));

        TextView made = new TextView(this);
        made.setText("Made in India 🇮🇳");
        made.setTextSize(15);
        made.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        made.setTextColor(Ui.INK);
        made.setGravity(Gravity.CENTER);
        made.setPadding(Ui.dp(22), Ui.dp(10), Ui.dp(22), Ui.dp(10));
        GradientDrawable mb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF138808});
        mb.setCornerRadius(Ui.dp(24));
        made.setBackground(mb);
        made.setElevation(Ui.dp(8));
        FrameLayout.LayoutParams madeLp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        madeLp.bottomMargin = Ui.dp(78);
        splash.addView(made, madeLp);

        TextView credit = new TextView(this);
        credit.setText(L.t("created") + " Anil Yadav");
        credit.setTextSize(12.5f);
        credit.setTextColor(0xFFC5D0F5);
        FrameLayout.LayoutParams crLp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        crLp.bottomMargin = Ui.dp(46);
        splash.addView(credit, crLp);


        // ── Animation ──
        logo.setCameraDistance(9000 * d);
        logo.setRotationY(-540);
        logo.setScaleX(0.15f);
        logo.setScaleY(0.15f);
        logo.setAlpha(0f);
        logo.animate().rotationY(0).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(900).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        glow.setAlpha(0f);
        glow.animate().alpha(1f).setStartDelay(400).setDuration(500).start();

        ringA.setAlpha(0f); ringB.setAlpha(0f);
        ringA.setScaleX(0.4f); ringA.setScaleY(0.4f);
        ringB.setScaleX(0.4f); ringB.setScaleY(0.4f);
        ringA.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(900)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
        ringB.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(400).setDuration(900)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();

        final ValueAnimator spin = ValueAnimator.ofFloat(0f, 360f);
        spin.setDuration(1700);
        spin.setRepeatCount(ValueAnimator.INFINITE);
        spin.setInterpolator(new LinearInterpolator());
        spin.addUpdateListener(an -> {
            float v = (float) an.getAnimatedValue();
            ringA.setPhase(v);
            ringB.setPhase(-v * 1.4f);
        });
        spin.start();

        for (int i = 0; i < letters.size(); i++) {
            TextView ch = letters.get(i);
            ch.setAlpha(0f);
            ch.setTranslationY(Ui.dp(46));
            ch.setRotationX(-95);
            ch.setScaleX(0.6f);
            ch.setScaleY(0.6f);
            ch.animate().alpha(1f).translationY(0).rotationX(0).scaleX(1f).scaleY(1f)
                    .setStartDelay(450 + i * 60L).setDuration(450)
                    .setInterpolator(new OvershootInterpolator(1.8f)).start();
        }
        // Akshar aane ke baad halki chamak (ek baar)
        title.postDelayed(() -> {
            for (int i = 0; i < letters.size(); i++) {
                final TextView ch = letters.get(i);
                ch.animate().scaleX(1.18f).scaleY(1.18f).setStartDelay(i * 40L).setDuration(110)
                        .withEndAction(() -> ch.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
            }
        }, 1100);
        bar.setPivotX(0);
        bar.setScaleX(0f);
        bar.animate().scaleX(1f).setStartDelay(800).setDuration(400).setInterpolator(new DecelerateInterpolator()).start();
        tag.setAlpha(0f);
        tag.animate().alpha(1f).setStartDelay(950).setDuration(400).start();
        made.setAlpha(0f);
        made.setTranslationY(Ui.dp(40));
        made.animate().alpha(1f).translationY(0).setStartDelay(1050).setDuration(400)
                .setInterpolator(new OvershootInterpolator()).start();
        credit.setAlpha(0f);
        credit.animate().alpha(1f).setStartDelay(1200).setDuration(300).start();

        splash.postDelayed(() -> splash.animate().alpha(0f).scaleX(1.2f).scaleY(1.2f).setDuration(300)
                .withEndAction(() -> {
                    spin.cancel();
                    splash.removeAllViews();
                    splash.setVisibility(View.GONE);
                }).start(), 1900);
    }

    // ───────────────────────── CONTROLS ─────────────────────────

    void setupControls() {
        btnBack.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoBack()) w.goBack(); });
        btnForward.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoForward()) w.goForward(); });
        findViewById(R.id.btnHome).setOnClickListener(v -> {
            Tab t = cur();
            if (t != null) t.web.loadUrl(t.incognito ? INCOG_HOME : HOME);
        });
        findViewById(R.id.btnTabs).setOnClickListener(v -> screens.tabs());
        findViewById(R.id.btnMenu).setOnClickListener(v -> screens.menu());
        findViewById(R.id.btnMic).setOnClickListener(v -> voiceSearch());
        findViewById(R.id.topLogo).setOnClickListener(v -> screens.about());
        lockIcon.setOnClickListener(v -> screens.siteInfo());
        findViewById(R.id.btnTabsTop).setOnClickListener(v -> screens.tabs());
        findViewById(R.id.btnMenuTop).setOnClickListener(v -> screens.menu());
        btnRefresh.setOnClickListener(v -> runShortcut());

        mediaFab.setOnClickListener(v -> {
            if ("simplified".equals(mediaFab.getTag())) { mediaFab.setTag(null); mediaFab.setVisibility(View.GONE); readerMode(); return; }
            Tab t = cur(); if (t != null) screens.mediaSheet(t);
        });

        swipe.setColorSchemeColors(0xFFFF8A00, 0xFF00E5FF, 0xFFFFC107);
        swipe.setProgressBackgroundColorSchemeColor(0xFF0D2A8A);
        View logo = findViewById(R.id.topLogo);
        logo.setClipToOutline(true);
        swipe.setOnRefreshListener(() -> {
            WebView w = web();
            if (w == null) { swipe.setRefreshing(false); return; }
            String u = w.getUrl();
            w.reload();
            if (u != null && u.startsWith(HOME)) swipe.postDelayed(() -> { swipe.setRefreshing(false); refreshHomes(); toast("✨ Home refreshed"); }, 700);
        });
        swipe.setOnChildScrollUpCallback((parent, child) -> { WebView w = web(); return w != null && w.getScrollY() > 0; });
        swipe.setEnabled(on("pull", true));
        swipe.setSize(androidx.swiperefreshlayout.widget.SwipeRefreshLayout.LARGE);
        swipe.setProgressViewOffset(false, Ui.dp(10), Ui.dp(90));

        urlBar.setOnFocusChangeListener((v, has) -> {
            WebView w = web();
            if (has) {
                String u = w == null ? null : w.getUrl();
                if (isRealUrl(u)) urlBar.setText(u);
                urlBar.post(urlBar::selectAll);
                urlBar.postDelayed(() -> requestSuggestions(isRealUrl(u) ? "" : urlBar.getText().toString().trim()), 250);
            } else {
                hideSuggestions();
                if (w != null) updateUrlBar(w.getUrl());
            }
        });
        urlBar.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (id == EditorInfo.IME_ACTION_GO || enter) {
                hideSuggestions();
                navigate(urlBar.getText().toString());
                hideKeyboard();
                urlBar.clearFocus();
                return true;
            }
            return false;
        });

        findInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { WebView w = web(); if (w != null) w.findAllAsync(s.toString()); }
        });
        findViewById(R.id.findNext).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(true); });
        findViewById(R.id.findPrev).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(false); });
        findViewById(R.id.findClose).setOnClickListener(v -> closeFind());
    }

    // ───────────────────────── TABS ─────────────────────────

    void openIncognito() {
        createTab(INCOG_HOME, true, true);
        toast("🕶 Incognito tab");
    }

    Tab cur() { return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null; }
    WebView web() { Tab t = cur(); return t == null ? null : t.web; }
    boolean isCurrent(Tab t) { return cur() == t; }

    Tab createTab(String url, boolean incognito, boolean show) {
        Tab t = new Tab();
        t.incognito = incognito;
        t.web = buildWebView(t);
        tabs.add(t);
        if (show) switchTab(tabs.size() - 1); else updateUi();
        if (url != null) t.web.loadUrl(url);
        tabCount.setText(String.valueOf(tabs.size()));
        return t;
    }

    void switchTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab old = cur();
        Tab t = tabs.get(i);
        if (old != null && old != t) { captureThumb(old); old.web.onPause(); }
        webContainer.removeAllViews();
        current = i;
        if (t.web.getParent() != null) ((ViewGroup) t.web.getParent()).removeView(t.web);
        webContainer.addView(t.web);
        t.web.onResume();
        int p = t.web.getProgress();
        setLoadingState(p < 100);
        progress.setProgress(p);
        updateUi();
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        if (!t.incognito && isRealUrl(t.web.getUrl())) pushClosed(t.title, t.web.getUrl());
        webContainer.removeView(t.web);
        if (t.incognito) { t.web.clearHistory(); t.web.clearCache(true); t.web.clearFormData(); }
        t.web.destroy();
        if (tabs.isEmpty()) { current = -1; createTab(HOME, false, true); return; }
        int ni = (i == current) ? Math.min(i, tabs.size() - 1) : (current > i ? current - 1 : current);
        current = -1;
        switchTab(ni);
    }

    /** Tab ki chhoti photo (Chrome jaisi tab list ke liye). */
    void captureThumb(Tab t) {
        if (t == null) return;
        try {
            WebView w = t.web;
            int W = w.getWidth(), H = w.getHeight();
            if (W <= 0 || H <= 0) return;
            float s = 0.4f;
            Bitmap b = Bitmap.createBitmap((int) (W * s), (int) (H * s), Bitmap.Config.RGB_565);
            Canvas c = new Canvas(b);
            c.scale(s, s);
            c.translate(-w.getScrollX(), -w.getScrollY());
            w.draw(c);
            t.thumb = b;
        } catch (Throwable ignored) {}
    }

    // ───────── Crash log (app band hone ki wajah dekhne ke liye) ─────────
    void installCrashLogger() {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, e) -> {
            logCrash(e);
            if (old != null) old.uncaughtException(th, e);
        });
    }

    void logCrash(Throwable e) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            e.printStackTrace(new java.io.PrintWriter(sw));
            getSharedPreferences("baatora", MODE_PRIVATE).edit()
                    .putString("lastCrash", new java.util.Date() + "\n" + sw).commit();
        } catch (Throwable ignored) {}
    }

    void showLastCrash() {
        final String c = prefs.getString("lastCrash", null);
        if (c == null) return;
        prefs.edit().remove("lastCrash").apply();
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("The app closed last time")
                    .setMessage(c.length() > 1800 ? c.substring(0, 1800) : c)
                    .setPositiveButton("Copy", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("crash", c));
                        toast("Copied, send it to Claude");
                    })
                    .setNegativeButton("Close", null).show();
        } catch (Exception ignored) {}
    }

    /** Passkey (fingerprint / screen lock se login) — phone ka WebView support kare to chalu. */
    static void enablePasskeys(WebSettings s) {
        try {
            if (!androidx.webkit.WebViewFeature.isFeatureSupported("WEB_AUTHENTICATION")) return;
            java.lang.reflect.Method m = androidx.webkit.WebSettingsCompat.class.getMethod("setWebAuthenticationSupport", WebSettings.class, int.class);
            m.invoke(null, s, 2);   // 2 = browser ki tarah (har website ke liye)
        } catch (Throwable ignored) {}
    }

    static boolean passkeysSupported() {
        try {
            return androidx.webkit.WebViewFeature.isFeatureSupported("WEB_AUTHENTICATION")
                    && androidx.webkit.WebSettingsCompat.class.getMethod("setWebAuthenticationSupport", WebSettings.class, int.class) != null;
        } catch (Throwable e) { return false; }
    }

    WebView buildWebView(Tab t) {
        final WebView w = new WebView(this);
        w.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        w.setBackgroundColor(Color.WHITE);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(prefs.getInt("textZoom", 100));
        s.setLoadsImagesAutomatically(true);
        s.setUserAgentString(prefs.getBoolean("desktop", false) ? DESKTOP_UA : mobileUA);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        Tab tmp = new Tab();
        tmp.web = w;
        tmp.incognito = t.incognito;
        applyWebPrefs(tmp);

        w.addJavascriptInterface(new BlobBridge(), "BaatoraBlob");
        w.addJavascriptInterface(new CfgBridge(), "BaatoraCfg");
        if (!t.incognito) w.addJavascriptInterface(pw.new Bridge(t), "BaatoraPw");
        // Android Autofill (Google / Samsung Pass) bhi login form bhar sake
        if (Build.VERSION.SDK_INT >= 26) w.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_YES);
        enablePasskeys(s);
        addStartScripts(w);
        w.setWebViewClient(new BClient(t));
        w.setWebChromeClient(new BChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> onDownload(url, ua, cd, mime, len));
        w.setOnLongClickListener(v -> onLongPress(w));
        w.setOnScrollChangeListener((v, x, y, ox, oy) -> onWebScroll(w, y - oy));
        w.setFindListener((active, num, done) ->
                findCount.setText(num == 0 ? "0/0" : (active + 1) + "/" + num));
        return w;
    }

    // ───────────────────────── WEB CLIENTS ─────────────────────────

    class BClient extends WebViewClient {
        final Tab t;
        BClient(Tab t) { this.t = t; }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            String u = r.getUrl().toString();
            if (adBlock && u.startsWith("http") && isAd(hostOf(u))) {
                if (t.popup) { t.popupDecided = true; closePopupTab(t); }
                return true;
            }
            boolean special = handleSpecialUrl(v, u, r.hasGesture());
            if (special) {
                // Naya window sirf kisi app (intent/tel/mailto) ke liye khula tha → khaali tab band
                if (t.popup && !t.popupDecided) { t.popupDecided = true; closePopupTab(t); }
                return true;
            }
            decidePopup(t, u);
            return false;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap fav) {
            t.pageHost = url == null ? null : Uri.parse(url).getHost();
            t.pageUrl = url;
            try { v.getSettings().setTextZoom(zoomFor(t.pageHost)); } catch (Exception ignored) {}
            if (decidePopup(t, url)) return;
            injectGen(v, url);
            if (adBlock && url != null && isYouTube(url)) injectAdBlock(v, url);
            synchronized (t.media) { t.media.clear(); }
            t.info.clear();
            if (isCurrent(t)) { setLoadingState(true); updateUi(); }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (isCurrent(t)) { setLoadingState(false); swipe.setRefreshing(false); updateUi(); }
            if (url == null) return;
            if (url.startsWith(HOME)) {
                v.evaluateJavascript("window.applyUi&&applyUi(" + homeJson(t.incognito) + ")", null);
            } else {
                applyNight(v, url);
                injectAdBlock(v, url);
                injectGen(v, url);
                injectGesture(v, url);
                Store.addAds(MainActivity.this, blockedPending.getAndSet(0));
                scanMedia(t, null);
                grabIcon(v, url);
                pw.inject(t, v, url);
                if (on("forceZoom", false)) v.evaluateJavascript(FORCE_ZOOM_JS, null);
                if (on("simplified", false) && isCurrent(t)) checkSimplified(v);
                if (pendingFind != null && isCurrent(t)) { final String pf = pendingFind; pendingFind = null; v.postDelayed(() -> highlight(pf), 600); }
                String title = v.getTitle();
                if (!t.incognito && url.startsWith("http") && (title == null || !title.startsWith("Baatora Error"))) {
                    addHistory(title, url);
                }
            }
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean reload) {
            t.pageHost = url == null ? null : Uri.parse(url).getHost();
            injectAdBlock(v, url);
            if (isCurrent(t)) updateUi();
            // YouTube/Google jaisi sites page reload kiye bina naya video/search kholti hain — unhe bhi History me daalo
            if (!t.incognito && url != null && url.startsWith("http")) {
                final String hu = url;
                v.postDelayed(() -> {
                    try {
                        String now = v.getUrl();
                        if (hu.equals(now)) {
                            String title = v.getTitle();
                            if (title == null || !title.startsWith("Baatora Error")) addHistory(title, hu);
                        }
                    } catch (Throwable ignored) {}
                }, 2000);
            }
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String ph = t.pageHost;
            boolean ytPage = ph != null && (ph.endsWith("youtube.com") || ph.equals("youtu.be"));
            // YouTube par koi request nahi rokte (warna video loading me atak jata hai); ad ko page ke andar skip karte hain
            if (adBlock && !ytPage && isAdRequest(u)) {
                blockedPending.incrementAndGet();
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            String s = u.toString();
            if (isMediaUrl(s)) addMedia(t, s);
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) return;
            String failing = r.getUrl().toString();
            String d = String.valueOf(e.getDescription());
            // Redirect/download/app-link se aane wale nakli errors ko ignore karo
            if (d.contains("ERR_ABORTED") || d.contains("ERR_UNKNOWN_URL_SCHEME") || d.contains("ERR_CACHE_MISS")) return;
            // Jis site par https nahi hai, wahan http par dobara try karo
            if (failing.startsWith("https://") && !failing.equals(t.httpTried)
                    && (d.contains("SSL_PROTOCOL") || d.contains("CONNECTION_REFUSED"))) {
                t.httpTried = failing;
                v.loadUrl("http://" + failing.substring(8));
                return;
            }
            v.loadDataWithBaseURL(null, errorPage(failing, d), "text/html", "UTF-8", failing);
        }

        @Override
        public boolean onRenderProcessGone(WebView v, android.webkit.RenderProcessGoneDetail d) {
            // Page ka renderer crash/memory-kill hua: poori app band hone ki jagah sirf yeh tab dobara banao
            final String url = v.getUrl();
            runOnUiThread(() -> {
                try {
                    int i = tabs.indexOf(t);
                    webContainer.removeView(v);
                    try { v.destroy(); } catch (Throwable ignored) {}
                    if (i < 0) return;
                    t.web = buildWebView(t);
                    if (i == current) { current = -1; switchTab(i); }
                    if (isRealUrl(url)) t.web.loadUrl(url);
                    toast("The page crashed and was reloaded");
                } catch (Throwable e) {
                    logCrash(e);
                }
            });
            return true;
        }

        @Override
        public void onReceivedSslError(WebView v, final android.webkit.SslErrorHandler h, android.net.http.SslError err) {
            try {
                new AlertDialog.Builder(MainActivity.this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("⚠ Security chetavni")
                        .setMessage("This site's security certificate is not trusted. Continuing may not be safe.")
                        .setPositiveButton("Go back", (dl, w) -> h.cancel())
                        .setNegativeButton("Open anyway", (dl, w) -> h.proceed())
                        .setOnCancelListener(dl -> h.cancel())
                        .show();
            } catch (Exception ex) { h.cancel(); }
        }
    }

    class BChrome extends WebChromeClient {
        final Tab t;
        BChrome(Tab t) { this.t = t; }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (isCurrent(t)) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
        }

        @Override
        public void onReceivedTitle(WebView v, String title) { t.title = title; }

        @Override
        public void onReceivedIcon(WebView v, Bitmap icon) {
            try { String u = v.getUrl(); if (u != null && u.startsWith("http")) Ui.putIcon(Uri.parse(u).getHost(), icon); } catch (Exception ignored) {}
        }

        /** Video shuru hone se pehle wala gray "play" dabba na dikhe. */
        @Override
        public Bitmap getDefaultVideoPoster() {
            try {
                Bitmap b = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.BLACK);
                return b;
            } catch (Throwable e) { return null; }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) { showCustom(view, cb); }

        @Override
        public void onHideCustomView() { hideCustom(); }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            try {
                Intent i = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                startActivityForResult(Intent.createChooser(i, "Choose file"), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                toast("Could not open file chooser");
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> askSitePerm(request.getOrigin() == null ? "" : request.getOrigin().toString(),
                    permKind(request.getResources()), allow -> {
                        if (allow) grantWebPerm(request); else { try { request.deny(); } catch (Exception ignored) {} }
                    }));
        }

        void grantWebPerm(PermissionRequest request) {
            ArrayList<String> missing = new ArrayList<>();
            for (String r : request.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !granted(Manifest.permission.CAMERA))
                    missing.add(Manifest.permission.CAMERA);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !granted(Manifest.permission.RECORD_AUDIO))
                    missing.add(Manifest.permission.RECORD_AUDIO);
            }
            if (missing.isEmpty()) {
                request.grant(request.getResources());
            } else {
                pendingPermission = request;
                requestPermissions(missing.toArray(new String[0]), REQ_WEB_PERM);
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            askSitePerm(origin, "location", allow -> {
                if (allow) grantGeo(origin, cb); else cb.invoke(origin, false, false);
            });
        }

        void grantGeo(String origin, GeolocationPermissions.Callback cb) {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                cb.invoke(origin, true, false);
            } else {
                geoOrigin = origin;
                geoCallback = cb;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            long now = System.currentTimeMillis();
            lastPopup = now;
            // Naya tab hamesha TURANT samne dikhao (peeche chhupa na rahe)
            Tab nt = createTab(null, t.incognito, true);
            nt.popup = true;
            nt.openerHost = hostOf(view.getUrl());
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nt.web);
            resultMsg.sendToTarget();
            bringToFront(nt, t);
            return true;
        }

        @Override
        public void onRequestFocus(WebView view) {
            // Pop-under trick (opener window.focus()) ko ignore karo — naya tab hi samne rahe
        }

        @Override
        public void onCloseWindow(WebView w) {
            for (int i = 0; i < tabs.size(); i++) {
                if (tabs.get(i).web == w) { closeTab(i); break; }
            }
        }
    }

    // ───────────────────────── MEDIA (video/audio files) ─────────────────────────

    static boolean isMediaUrl(String url) {
        try {
            String path = Uri.parse(url).getPath();
            if (path == null) return false;
            path = path.toLowerCase();
            if (SEGMENT.matcher(path).find()) return false;
            for (String e : MEDIA_EXT) if (path.endsWith(e)) return true;
        } catch (Exception ignored) {}
        return false;
    }

    /** YouTube ne khud file "download" ke roop me di ho (jaise YouTube Studio me apne video ka Download) — wahi allowed. */
    boolean officialYtDownload(String cd) {
        WebView w = web();
        String page = w == null ? null : w.getUrl();
        String ph = page == null ? "" : String.valueOf(Uri.parse(page).getHost()).toLowerCase();
        return ph.endsWith("studio.youtube.com") || ph.endsWith("takeout.google.com")
                || (cd != null && cd.toLowerCase().contains("attachment"));
    }

    /** YouTube video ka ID (watch, youtu.be, shorts, live, music). Nahi to null. */
    static String ytVideoId(String url) {
        if (url == null) return null;
        try {
            Uri u = Uri.parse(url);
            String h = String.valueOf(u.getHost()).toLowerCase(), path = u.getPath() == null ? "" : u.getPath();
            if (h.equals("youtu.be")) return path.length() > 1 ? path.substring(1).split("/")[0] : null;
            if (!h.endsWith("youtube.com") || h.startsWith("studio.")) return null;
            String v = u.getQueryParameter("v");
            if (v != null && !v.isEmpty()) return v;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^/(shorts|live|embed)/([A-Za-z0-9_-]{6,})").matcher(path);
            if (m.find()) return m.group(2);
        } catch (Exception ignored) {}
        return null;
    }

    static boolean isYouTube(String url) {
        if (url == null) return false;
        String h = Uri.parse(url).getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        return h.endsWith("youtube.com") || h.equals("youtu.be") || h.endsWith("googlevideo.com")
                || h.endsWith("ytimg.com") || h.endsWith("youtube-nocookie.com");
    }

    static final java.util.concurrent.ExecutorService PROBE = java.util.concurrent.Executors.newFixedThreadPool(3);
    static final String[] AD_MEDIA_WORDS = {"/vast", "vast.xml", "preroll", "pre-roll", "midroll", "/adserver", "/ads/", "/ad/",
            "/adv/", "advert", "creative", "/banner", "/promo/", "/sponsor", "popunder", "/click?"};

    boolean looksAd(String url) {
        String low = url.toLowerCase();
        for (String w : AD_MEDIA_WORDS) if (low.contains(w)) return true;
        String h = hostOf(url);
        if (isAd(h)) return true;
        for (String lab : h.split("\\.")) if (lab.equals("ads") || lab.equals("adserver") || lab.equals("adserv")) return true;
        return false;
    }

    /** 30 second se chhota clip (ya bahut chhoti file) = ad maana jata hai. */
    static boolean isShortClip(long[] r) {
        if (r == null) return false;
        if (r[0] >= 0) return r[0] < 30;
        return r[1] >= 0 && r[1] < 3L * 1024 * 1024;
    }

    /** Sirf asli video/audio links (ads aur chhote clips hata kar). */
    ArrayList<String> visibleMedia(Tab t) {
        ArrayList<String> out = new ArrayList<>();
        synchronized (t.media) {
            for (String u : t.media) if (!isShortClip(t.info.get(u))) out.add(u);
        }
        return out;
    }

    void addMedia(final Tab t, final String url) {
        if (isYouTube(url) || looksAd(url)) return;
        synchronized (t.media) {
            if (t.media.contains(url) || t.media.size() >= 30) return;
            t.media.add(url);
        }
        final String ck = CookieManager.getInstance().getCookie(url);
        final String ref = t.pageUrl;
        PROBE.execute(() -> {
            long[] r = MediaProbe.probe(url, mobileUA, ck, ref);
            t.info.put(url, r);
            runOnUiThread(() -> { if (isCurrent(t)) updateMediaFab(); });
        });
        runOnUiThread(() -> { if (isCurrent(t)) updateMediaFab(); });
    }

    void scanMedia(Tab t, Runnable after) {
        t.web.evaluateJavascript(MEDIA_JS, val -> {
            try {
                Object o = new JSONTokener(val).nextValue();
                JSONArray a = new JSONArray(String.valueOf(o));
                for (int i = 0; i < a.length(); i++) {
                    String u = a.optString(i);
                    if (isMediaUrl(u)) addMedia(t, u);
                }
            } catch (Exception ignored) {}
            if (after != null) after.run();
        });
    }

    /** Sundar Download button: gradient pill, safed gol icon, do line (Download + quality), halki chamak. */
    String fabKey = "";
    void styleFab(boolean yt, String sub) {
        String key = yt + "|" + sub;
        if (key.equals(fabKey)) return;
        fabKey = key;
        int c1 = yt ? 0xFFFF1744 : 0xFF2979FF, c2 = yt ? 0xFFFF6D00 : 0xFF7C4DFF;
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        bg.setCornerRadius(Ui.dp(30));
        bg.setStroke(Ui.dp(1.2f), 0x55FFFFFF);
        mediaFab.setBackground(bg);
        mediaFab.setElevation(Ui.dp(12));
        if (Build.VERSION.SDK_INT >= 28) { mediaFab.setOutlineSpotShadowColor(c1); mediaFab.setOutlineAmbientShadowColor(c2); }
        android.graphics.drawable.Drawable ic = getDrawable(R.drawable.ic_download);
        if (ic != null) {
            ic = ic.mutate();
            ic.setTint(c1);
            GradientDrawable disc = new GradientDrawable();
            disc.setShape(GradientDrawable.OVAL);
            disc.setColor(Color.WHITE);
            android.graphics.drawable.LayerDrawable badge = new android.graphics.drawable.LayerDrawable(
                    new android.graphics.drawable.Drawable[]{disc, ic});
            badge.setLayerInset(1, Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
            badge.setBounds(0, 0, Ui.dp(40), Ui.dp(40));
            mediaFab.setCompoundDrawablesRelative(badge, null, null, null);
        }
        mediaFab.setCompoundDrawablePadding(Ui.dp(11));
        mediaFab.setPaddingRelative(Ui.dp(7), Ui.dp(7), Ui.dp(22), Ui.dp(7));
        mediaFab.setGravity(Gravity.CENTER_VERTICAL);
        mediaFab.setTextColor(Color.WHITE);
        mediaFab.setLineSpacing(0, 0.95f);
        mediaFab.setShadowLayer(4, 0, 1, 0x40000000);
        String title = "Download";
        android.text.SpannableString sp = new android.text.SpannableString(title + "\n" + sub);
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(16, true), 0, title.length(), 0);
        sp.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, title.length(), 0);
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(11, true), title.length() + 1, sp.length(), 0);
        sp.setSpan(new android.text.style.ForegroundColorSpan(0xE6FFFFFF), title.length() + 1, sp.length(), 0);
        mediaFab.setText(sp);
        // ek baar halka "dhadkan" — dhyan khinche, pareshan na kare
        mediaFab.animate().cancel();
        mediaFab.setScaleX(0.85f); mediaFab.setScaleY(0.85f);
        mediaFab.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new OvershootInterpolator(2.2f)).start();
    }

    void updateMediaFab() {
        if ("simplified".equals(mediaFab.getTag())) return;
        Tab t = cur();
        if (t == null) { mediaFab.setVisibility(View.GONE); return; }
        int n = visibleMedia(t).size();
        String fh = hostOf(String.valueOf(t.web.getUrl()));
        // Google/search pages par Download button kaam ka nahi — wahan nahi dikhate
        boolean searchSite = fh.contains("google.") || fh.contains("gstatic.") || fh.contains("bing.com")
                || fh.contains("duckduckgo.") || fh.contains("yahoo.");
        boolean yt = false;                                  // YouTube par Download button nahi dikhate
        boolean show = false;   // Download button screen par nahi dikhate (menu → Video download se milega)
        boolean was = mediaFab.getVisibility() == View.VISIBLE;
        mediaFab.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            String sub;
            if (yt) sub = "Official options";
            else {
                int best = 0;
                for (String m : visibleMedia(t)) best = Math.max(best, Screens.quality(m));
                sub = n + (n == 1 ? " file" : " files") + (best > 0 ? "  •  " + best + "p" + (best >= 720 ? " HD" : "") : "");
            }
            styleFab(yt, sub);
        }
        if (show && !was) {
            mediaFab.setScaleX(0.6f);
            mediaFab.setScaleY(0.6f);
            mediaFab.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(2f)).start();
        }
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    boolean handleSpecialUrl(WebView v, String url, boolean gesture) {
        String low = url.toLowerCase();
        if (low.startsWith("baatora://")) {
            String cmd = low.substring(10);
            if (cmd.startsWith("voice")) voiceSearch();
            else if (cmd.startsWith("downloads")) screens.downloads();
            else if (cmd.startsWith("history")) screens.list("history");
            else if (cmd.startsWith("bookmarks")) screens.list("bookmarks");
            else if (cmd.startsWith("incognito")) openIncognito();
            else if (cmd.startsWith("clip")) {
                String cu = Uri.parse(url).getQueryParameter("u");
                if (cu != null) {
                    prefs.edit().putString("clipSeen", cu).apply();
                    if (cmd.startsWith("clipx")) refreshHomes(); else navigate(cu);
                }
            }
            else if (cmd.startsWith("tabs")) screens.tabs();
            else if (cmd.startsWith("about")) screens.about();
            else if (cmd.startsWith("notifications")) screens.notifications();
            else if (cmd.startsWith("vpn")) toggleMyVpn(this::refreshHomes);
            else if (cmd.startsWith("settings")) screens.settings();
            return true;
        }
        if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("file://")
                || low.startsWith("about:") || low.startsWith("javascript:") || low.startsWith("data:")
                || low.startsWith("blob:")) {
            return false;
        }
        // Doosri app/Play Store kholne wale links: bina click ke kabhi nahi (ads yahi karte hain)
        if (!gesture) return true;
        if (low.startsWith("tel:") || low.startsWith("mailto:") || low.startsWith("sms:") || low.startsWith("smsto:") || low.startsWith("geo:")) {
            openExternal(v, url);
            return true;
        }
        if (low.startsWith("market:") || low.contains("play.google.com/store")) return true;
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Open another app?")
                    .setMessage("This link wants to open another app.")
                    .setPositiveButton("Open", (d, w) -> openExternal(v, url))
                    .setNegativeButton("No", null)
                    .show();
        } catch (Exception ignored) {}
        return true;
    }

    void openExternal(WebView v, String url) {
        try {
            if (url.toLowerCase().startsWith("intent:")) {
                Intent it = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                it.addCategory(Intent.CATEGORY_BROWSABLE);
                it.setComponent(null);
                it.setSelector(null);
                try {
                    startActivity(it);
                } catch (ActivityNotFoundException e) {
                    String fb = it.getStringExtra("browser_fallback_url");
                    if (fb != null && fb.startsWith("http")) v.loadUrl(fb);
                    else toast("No app found for this link");
                }
                return;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("No app found for this link");
        }
    }

    void navigate(String input) {
        String q = input.trim();
        if (q.isEmpty()) return;
        String url;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || q.startsWith("about:")) url = q;
        else if (!q.contains(" ") && (q.matches("^[^\\s]+\\.[a-zA-Z]{2,}(/.*)?(:\\d+)?.*$") || q.startsWith("localhost")))
            url = "https://" + q;
        else url = searchUrl(q);
        WebView w = web();
        if (w != null) w.loadUrl(url);
    }

    String engine() { return prefs.getString("engine", "google"); }

    String searchUrl(String q) {
        String enc;
        try { enc = URLEncoder.encode(q, "UTF-8"); } catch (Exception e) { enc = q; }
        switch (engine()) {
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "duckduckgo": return "https://duckduckgo.com/?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://www.google.com/search?q=" + enc;
        }
    }

    boolean isAdRequest(Uri u) {
        String host = u.getHost();
        if (isAd(host)) return true;
        if (host == null) return false;
        String lowUrl = u.toString().toLowerCase();
        if (lowUrl.contains("/vast") || lowUrl.contains("vast.xml") || lowUrl.contains("/preroll") || lowUrl.contains("/midroll")
                || lowUrl.contains("/adserver/")) return true;
        for (String lab : host.split("\\.")) if (lab.equals("ads") || lab.equals("adserver") || lab.equals("adserv")) return true;
        if (host.contains("google.") && !host.contains("youtube")) {
            String path = u.getEncodedPath();
            String full = path + (u.getEncodedQuery() == null ? "" : "?" + u.getEncodedQuery());
            for (String p : AD_PATHS) if (full.contains(p)) return true;
        }
        return false;
    }

    /** Page ka sabse achha logo (apple-touch-icon / bada icon) dhoondo — tabs me Chrome jaisa logo dikhe. */
    void grabIcon(WebView v, String url) {
        if (url == null || !url.startsWith("http")) return;
        final String host = Uri.parse(url).getHost();
        if (host == null) return;
        String js = "(function(){var b='',bs=-1;var l=document.querySelectorAll('link[rel~=icon],link[rel~=apple-touch-icon],link[rel~=apple-touch-icon-precomposed],link[rel=\\'shortcut icon\\']');"
                + "for(var i=0;i<l.length;i++){var h=l[i].href;if(!h||/\\.svg(\\?|$)/i.test(h))continue;var s=0,z=(l[i].getAttribute('sizes')||'').match(/(\\d+)/);"
                + "if(z)s=+z[1];else if(/apple/.test(l[i].rel))s=180;else s=32;if(s>bs){bs=s;b=h;}}return b;})()";
        try {
            v.evaluateJavascript(js, r -> {
                if (r == null || r.length() < 4) return;
                String href = r.substring(1, r.length() - 1).replace("\\/", "/");
                Ui.fetchIconUrl(host, href);
            });
        } catch (Exception ignored) {}
    }

    void injectAdBlock(WebView v, String url) {
        if (!adBlock || url == null) return;
        String h = Uri.parse(url).getHost();
        if (h == null) return;
        if (h.endsWith("youtube.com") || h.endsWith("youtube-nocookie.com")) v.evaluateJavascript(asset("ytblock.js"), null);
        else if (h.contains("google.")) v.evaluateJavascript(YT_ADBLOCK_JS, null);
    }

    /** Video par ungli se aage/peeche (agar page-start script na chal saka ho). */
    void injectGesture(WebView v, String url) {
        if (url == null || !url.startsWith("http")) return;
        String js = asset("vgesture.js");
        if (!js.isEmpty()) v.evaluateJavascript(js, null);
    }

    boolean isAd(String host) {
        if (host == null) return false;
        for (String a : AD_HOSTS) if (host.equals(a) || host.endsWith("." + a)) return true;
        String h = host.toLowerCase();
        for (String k : BET_WORDS) if (h.contains(k)) return true;
        return false;
    }

    static final String[] BET_WORDS = {"4rabet", "1xbet", "mostbet", "1win", "melbet", "parimatch", "linebet",
            "betwinner", "rajbet", "babu88", "dafabet", "betway", "fairplay", "lotus365"};
    static final String[] AUTH_HOSTS = {"accounts.google.com", "facebook.com", "appleid.apple.com", "login.microsoftonline.com",
            "login.live.com", "github.com", "twitter.com", "x.com", "paypal.com", "razorpay.com", "paytm.com", "phonepe.com",
            "instagram.com", "discord.com", "api.razorpay.com"};

    String genJs;
    String genJs() {
        if (genJs == null) {
            try {
                java.io.InputStream is = getAssets().open("adblock.js");
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                is.close();
                genJs = bo.toString("UTF-8");
            } catch (Exception e) { genJs = ""; }
        }
        return genJs;
    }

    void injectGen(WebView v, String url) {
        if (!adBlock || url == null || !url.startsWith("http")) return;
        String js = genJs();
        if (!js.isEmpty()) v.evaluateJavascript(js, null);
    }

    static String hostOf(String u) {
        try { String h = Uri.parse(u).getHost(); return h == null ? "" : h.toLowerCase().replaceFirst("^www\\.", ""); }
        catch (Exception e) { return ""; }
    }

    static boolean sameSite(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b) || a.endsWith("." + b) || b.endsWith("." + a)) return true;
        String[] x = a.split("\\."), y = b.split("\\.");
        if (x.length < 2 || y.length < 2) return false;
        return x[x.length - 1].equals(y[y.length - 1]) && x[x.length - 2].equals(y[y.length - 2]);
    }

    /** Naya window maangne wale link ka URL pakad kar usi WebView me load karo (naya tab nahi). */
    void openInSameTab(final WebView target, Message resultMsg) {
        final WebView tmp = new WebView(MainActivity.this);
        tmp.getSettings().setJavaScriptEnabled(true);
        final boolean[] done = {false};
        tmp.setWebViewClient(new WebViewClient() {
            void grab(String u) {
                if (done[0] || u == null || u.isEmpty() || u.equals("about:blank")) return;
                done[0] = true;
                final String url = u;
                target.post(() -> {
                    String h = hostOf(url);
                    boolean block = adBlock && url.startsWith("http") && isAd(h);
                    if (!block && !handleSpecialUrl(target, url, true)) target.loadUrl(url);
                    tmp.stopLoading();
                    tmp.destroy();
                });
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                grab(r.getUrl().toString());
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap fav) { grab(url); }
        });
        WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
        tr.setWebView(tmp);
        resultMsg.sendToTarget();
        // 10 sec me URL na mile to temp WebView hata do
        target.postDelayed(() -> { if (!done[0]) { done[0] = true; tmp.destroy(); } }, 10000);
    }

    /** Naya tab samne lao, aur agar site turant purane tab ko wapas aage kare to phir se naya tab dikhao. */
    void bringToFront(final Tab nt, final Tab opener) {
        final long[] delays = {0, 150, 400, 900, 1600};
        for (long d : delays) {
            nt.web.postDelayed(() -> {
                int i = tabs.indexOf(nt);
                if (i < 0 || isCurrent(nt)) return;
                Tab c = cur();
                if (d == 0 || c == opener || c == null) switchTab(i);
            }, d);
        }
    }

    void closePopupTab(final Tab t) {
        t.web.post(() -> { int i = tabs.indexOf(t); if (i >= 0) closeTab(i); });
    }

    /** Naye popup window ka pehla URL dekh kar faisla: asli (login/same site) ho to dikhao, warna band. */
    boolean decidePopup(final Tab t, String url) {
        if (!t.popup || t.popupDecided || url == null) return false;
        if (url.equals("about:blank") || url.isEmpty()) return false;
        t.popupDecided = true;
        // Naya tab hamesha samne dikhao, kabhi band nahi karte
        t.web.post(() -> {
            int i = tabs.indexOf(t);
            if (i >= 0 && !isCurrent(t)) switchTab(i);
        });
        return false;
    }

    static boolean isRealUrl(String u) {
        return u != null && !u.startsWith("file:///android_asset") && !u.startsWith("data:") && !u.equals("about:blank");
    }

    // ───────────────────────── UI STATE ─────────────────────────

    void updateUi() {
        Tab t = cur();
        if (t == null) return;
        updateUrlBar(t.web.getUrl());
        btnBack.setAlpha(t.web.canGoBack() ? 1f : 0.35f);
        btnForward.setAlpha(t.web.canGoForward() ? 1f : 0.35f);
        tabCount.setText(String.valueOf(tabs.size()));
        int[] colors = t.incognito
                ? new int[]{0xFF1A0B2E, 0xFF3D1670, 0xFF6A1FB0}
                : new int[]{Ui.BAR1, Ui.NAVY2, Ui.BLUE};
        topBar.setBackground(topBg(t.incognito));
        getWindow().setStatusBarColor(t.incognito ? 0xFF1A0B2E : Ui.NAVY);
        if (Ui.LIGHT) lightBars(getWindow());
        ((TextView) findViewById(R.id.tabCountTop)).setText(String.valueOf(tabs.size()));
        urlBar.setHint(t.incognito ? "🕶 " + L.t("incognito") : L.t("url_hint"));
        String cu = t.web.getUrl();
        boolean home = cu == null || cu.startsWith(HOME);
        swipe.setEnabled(on("pull", true));   // Home par bhi ungli se neeche kheencho → refresh
        if (home && !t.incognito && homeSkin >= 0) applyHomeSkin(); else clearHomeSkin();
        updateMediaFab();
    }

    void updateUrlBar(String url) {
        if (urlBar.hasFocus()) return;
        if (!isRealUrl(url)) {
            urlBar.setText("");
            lockIcon.setImageResource(R.drawable.ic_search);
            lockIcon.setColorFilter(0xFF1E5BFF);
            return;
        }
        boolean secure = url.startsWith("https://");
        lockIcon.setImageResource(secure ? R.drawable.ic_lock : R.drawable.ic_info);
        lockIcon.setColorFilter(secure ? 0xFF1B9E4B : 0xFFD32F2F);
        urlBar.setText(url.replaceFirst("^https?://(www\\.)?", ""));
    }

    void setLoadingState(boolean l) {
        loading = l;
        btnRefresh.setImageResource(shortcutIcon(l));
        progress.setVisibility(l ? View.VISIBLE : View.GONE);
    }

    void applyNight(WebView w, String url) {
        if (w == null || !isRealUrl(url)) return;
        w.evaluateJavascript(String.format(NIGHT_JS, prefs.getBoolean("night", false) ? "true" : "false"), null);
    }

    // ───────────────────────── FULL SCREEN ─────────────────────────

    void showCustom(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) { cb.onCustomViewHidden(); return; }
        customView = v;
        customCallback = cb;
        fullscreenContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullscreenContainer.setVisibility(View.VISIBLE);
        hideSystemUi();
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    void hideCustom() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        if (!appFull) showSystemUi();
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    void setAppFull(boolean f) {
        appFull = f;
        topBar.setVisibility(f ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(f ? View.GONE : View.VISIBLE);
        if (f) { hideSystemUi(); toast("Press Back to exit full screen"); }
        else { showSystemUi(); applyNavBar(); }
    }

    @SuppressWarnings("deprecation")
    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressWarnings("deprecation")
    void showSystemUi() {
        lightBars(getWindow());
    }

    // ───────────────────────── MENU ACTIONS ─────────────────────────

    /** Setting padho — galat type ho (purani setting) to app band na ho, default lo. */
    boolean on(String key, boolean def) {
        try { return prefs.getBoolean(key, def); } catch (ClassCastException e) { return def; }
    }

    void toggleDesktop() {
        boolean d = !on("desktop", false);
        prefs.edit().putBoolean("desktop", d).apply();
        for (Tab t : tabs) t.web.getSettings().setUserAgentString(d ? DESKTOP_UA : mobileUA);
        WebView w = web(); if (w != null) w.reload();
        toast(d ? "Desktop site ON" : "Mobile site ON");
    }

    void toggleNight() {
        boolean n = !on("night", false);
        prefs.edit().putBoolean("night", n).apply();
        for (Tab t : tabs) applyNight(t.web, t.web.getUrl());
        toast(n ? "Night mode ON 🌙" : "Night mode OFF");
    }

    void toggleDataSaver() {
        boolean d = !on("datasaver", false);
        prefs.edit().putBoolean("datasaver", d).apply();
        for (Tab t : tabs) applyWebPrefs(t);
        toast(d ? "📉 Data Saver ON" : "Data Saver OFF");
    }

    void togglePull() {
        boolean p = !on("pull", true);
        prefs.edit().putBoolean("pull", p).apply();
        updateUi();
    }

    void chooseTextSize() { chooseTextSize(null); }

    void chooseTextSize(Runnable done) {
        final int[] sizes = {75, 90, 100, 115, 130, 150};
        String[] names = {"75%  Aa", "90%  Aa", "100%  Aa  (Normal)", "115%  Aa", "130%  Aa", "150%  Aa"};
        int now = prefs.getInt("textZoom", 100), sel = 2;
        for (int i = 0; i < sizes.length; i++) if (sizes[i] == now) sel = i;
        screens.choiceSheet("🔠  " + L.t("textsize"), names, sel, w -> {
            prefs.edit().putInt("textZoom", sizes[w]).apply();
            for (Tab t : tabs) t.web.getSettings().setTextZoom(sizes[w]);
            if (done != null) done.run();
        });
    }

    void chooseEngine() { chooseEngine(null); }

    void chooseEngine(Runnable done) {
        final String[] keys = {"google", "bing", "duckduckgo", "yahoo"};
        String[] names = {"Google", "Bing", "DuckDuckGo", "Yahoo"};
        int sel = 0;
        for (int i = 0; i < keys.length; i++) if (keys[i].equals(engine())) sel = i;
        screens.choiceSheet("🔎  " + L.t("engine"), names, sel, w -> {
            prefs.edit().putString("engine", keys[w]).apply();
            refreshHomes();
            if (done != null) done.run();
        });
    }

    // ───────────── THEME / LANGUAGE ─────────────

    void setThemeKey(String key) {
        prefs.edit().putString("theme", key).putString("mode", "default").apply();
        Ui.applyMode("default", key);
        applyDynamic();
        applyThemeToViews();
        updateUi();
        refreshHomes();
    }

    /** Light / Dark / System default */
    void setMode(String mode) {
        prefs.edit().putString("mode", mode).apply();
        Ui.applyMode(mode, prefs.getString("theme", "original"));
        applyDynamic();
        applyThemeToViews();
        updateUi();
        refreshHomes();
        toast(mode.equals("light") ? "☀ " + L.t("mode_light") : mode.equals("dark") ? "🌙 " + L.t("mode_dark") : "📱 " + L.t("mode_default"));
    }

    static void lightBars(android.view.Window w) {
        if (w == null) return;
        int f = 0;
        if (Ui.LIGHT) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(f);
    }

    void setLang(String key) {
        prefs.edit().putString("lang", key).apply();
        L.set(key);
        updateUi();
        refreshHomes();
    }

    android.graphics.drawable.Drawable topBg(boolean inc) {
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                inc ? new int[]{0xFF1A0B2E, 0xFF2E1150, 0xFF4A1A80} : new int[]{Ui.NAVY, Ui.PAGE1, Ui.NAVY2});
        GradientDrawable line = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                inc ? new int[]{0xFFB388FF, 0xFFE040FB} : new int[]{Ui.ORANGE, Ui.GOLD, Ui.CYAN});
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{line, base});
        boolean bottom = prefs.getBoolean("barBottom", false);
        if (bottom) ld.setLayerInset(1, 0, Ui.dp(2), 0, 0); else ld.setLayerInset(1, 0, 0, 0, Ui.dp(2));
        return ld;
    }

    void applyNavBar() {
        boolean show = prefs.getBoolean("bottomNav", true);
        barHidden = false;
        bottomBar.setTranslationY(0);
        bottomBar.setVisibility(show && !appFull ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnTabsTop).setVisibility(show ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnMenuTop).setVisibility(show ? View.GONE : View.VISIBLE);
    }

    void toggleBottomNav() { togglePref("bottomNav", true); applyNavBar(); }

    void onWebScroll(WebView w, int dy) {
        if (w != web() || appFull || !prefs.getBoolean("autoHide", false) || !prefs.getBoolean("bottomNav", true)) return;
        if (dy > 14 && !barHidden) {
            barHidden = true;
            bottomBar.animate().translationY(bottomBar.getHeight()).setDuration(160)
                    .withEndAction(() -> { if (barHidden) bottomBar.setVisibility(View.GONE); }).start();
        } else if (dy < -14 && barHidden) {
            barHidden = false;
            bottomBar.setVisibility(View.VISIBLE);
            bottomBar.animate().translationY(0).setDuration(160).start();
        }
    }

    void applyThemeToViews() {
        getWindow().setStatusBarColor(Ui.NAVY);
        getWindow().setNavigationBarColor(Ui.DEEP);
        getWindow().getDecorView().setBackgroundColor(Ui.NAVY);
        GradientDrawable line = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Ui.ORANGE, Ui.GOLD, Ui.CYAN});
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.NAVY, Ui.DEEP});
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{line, fill});
        ld.setLayerInset(1, 0, Ui.dp(2), 0, 0);
        bottomBar.setBackground(ld);
        defaultBottomBg = ld;
        skinOn = false;
        styleHome(0xFFFF8A00, 0xFF7C4DFF, 0xFF1E5BFF);
        // ── Top bar: theme ke rang ka gradient + neeche rangeen line ──
        GradientDrawable tline = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Ui.ORANGE, Ui.GOLD, Ui.CYAN});
        android.graphics.drawable.LayerDrawable tbg = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{tline, Ui.barBg()});
        tbg.setLayerInset(1, 0, 0, 0, Ui.dp(2));
        topBar.setBackground(tbg);
        // ── Address bar: chuna hua style + rang (Appearance → Search bar style) ──
        styleAddressBar();
        GradientDrawable lk = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{(Ui.BLUE & 0xFFFFFF) | 0x33000000, (Ui.ORANGE & 0xFFFFFF) | 0x33000000});
        lk.setShape(GradientDrawable.OVAL);
        findViewById(R.id.lockIcon).setBackground(lk);
        GradientDrawable logoRing = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.ORANGE, Ui.GOLD, Ui.CYAN});
        logoRing.setShape(GradientDrawable.OVAL);
        findViewById(R.id.topLogo).setBackground(logoRing);
        swipe.setProgressBackgroundColorSchemeColor(Ui.LIGHT ? 0xFFFFFFFF : Ui.NAVY2);
        android.content.res.ColorStateList ic = android.content.res.ColorStateList.valueOf(Ui.ICON);
        int[] tinted = {R.id.btnBack, R.id.btnForward, R.id.btnMenu, R.id.btnRefresh, R.id.btnMenuTop,
                R.id.findPrev, R.id.findNext, R.id.findClose};
        for (int id : tinted) ((ImageView) findViewById(id)).setImageTintList(ic);
        int[] glass = {R.id.btnRefresh, R.id.btnTabsTop, R.id.btnMenuTop};
        for (int id : glass) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.gl(0x26));
            g.setStroke(Ui.dp(1), Ui.gl(0x33));
            findViewById(id).setBackground(g);
        }
        for (int id : new int[]{R.id.tabCount, R.id.tabCountTop}) {
            TextView tc = findViewById(id);
            tc.setTextColor(Ui.ICON);
            tc.setBackground(Ui.stroke(Ui.round(0x00000000, 7), Ui.ICON, 2));
        }
        // Refresh button: rangeen gradient circle
        GradientDrawable rf = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.ORANGE, Ui.BLUE});
        rf.setShape(GradientDrawable.OVAL);
        rf.setStroke(Ui.dp(1.5f), 0x66FFFFFF);
        findViewById(R.id.btnRefresh).setBackground(rf);
        ((ImageView) findViewById(R.id.btnRefresh)).setImageTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        ImageView mic = findViewById(R.id.btnMic);
        GradientDrawable mg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFF7A00, 0xFF1E5BFF});
        mg.setShape(GradientDrawable.OVAL);
        mic.setBackground(mg);
        mic.setImageTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        mic.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        findInput.setTextColor(Ui.TEXT);
        findInput.setHintTextColor(Ui.MUTED);
        findInput.setBackground(Ui.round(Ui.gl(0x1F), 18));
        lightBars(getWindow());
        fabKey = "";   // theme badle to button dobara banao
        styleAddressBar();
        findBar.setBackgroundColor(Ui.NAVY2);
    }

    /** Home page ko theme, bhasha aur search engine bhejta hai. */
    String homeJson(boolean incognito) {
        try {
            JSONObject o = new JSONObject();
            JSONObject th = new JSONObject();
            th.put("b1", Ui.hex(Ui.BAR1)); th.put("b2", Ui.hex(Ui.NAVY2)); th.put("b3", Ui.hex(Ui.BLUE));
            th.put("p1", Ui.hex(Ui.PAGE1)); th.put("p2", Ui.hex(Ui.NAVY)); th.put("p3", Ui.hex(Ui.DEEP));
            th.put("a1", Ui.hex(Ui.ORANGE)); th.put("a2", Ui.hex(Ui.CYAN)); th.put("g", Ui.hex(Ui.GOLD));
            o.put("theme", th);
            JSONObject st = new JSONObject();
            String[] keys = {"most_visited", "copied_link", "tagline", "home_search", "quick", "trending", "gm", "gd", "ge", "gn", "add", "edit",
                    "done", "created", "incog_note", "downloads", "history", "bookmarks", "incognito", "engine",
                    "vpn", "notifications", "settings", "khabar", "reader"};
            for (String k : keys) st.put(k, L.t(k));
            o.put("s", st);
            o.put("engine", engine());
            o.put("incog", incognito);
            o.put("light", Ui.LIGHT);
            // Clipboard apne aap nahi padhte — warna Android neeche "pasted from clipboard" likh deta hai
            o.put("unread", unreadNotifs());
            String lk = L.key();
            o.put("lang", lk.equals("english") ? "en-IN" : lk.equals("marathi") ? "mr-IN" : lk.equals("bengali") ? "bn-IN"
                    : lk.equals("punjabi") ? "pa-IN" : lk.equals("hinglish") ? "en-IN" : "hi-IN");
            o.put("vpn", vpnActive());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    void refreshHomes() {
        for (Tab t : tabs) {
            String u = t.web.getUrl();
            if (u != null && u.startsWith(HOME))
                t.web.evaluateJavascript("window.applyUi&&applyUi(" + homeJson(t.incognito) + ")", null);
        }
    }

    /** Address bar upar ya neeche (Settings se). */
    void applyBarPosition() {
        boolean bottom = prefs.getBoolean("barBottom", false);
        ViewGroup main = (ViewGroup) topBar.getParent();
        main.removeView(topBar);
        main.removeView(progress);
        Tab ct = cur();
        topBar.setBackground(topBg(ct != null && ct.incognito));
        if (bottom) {
            int idx = main.indexOfChild(bottomBar);
            main.addView(progress, idx);
            main.addView(topBar, idx + 1);
        } else {
            main.addView(topBar, 0);
            main.addView(progress, 1);
        }
    }

    void toggleBarBottom() {
        boolean b = !prefs.getBoolean("barBottom", false);
        prefs.edit().putBoolean("barBottom", b).apply();
        applyBarPosition();
        toast(b ? "Address bar is now at the bottom" : "Address bar is now at the top");
    }

    boolean googleSignedIn() {
        try {
            String c = CookieManager.getInstance().getCookie("https://accounts.google.com");
            return c != null && (c.contains("SID=") || c.contains("PSID="));
        } catch (Exception e) { return false; }
    }

    void openInNewTab(String url) { createTab(url, false, true); }

    void googleSignIn() { openInNewTab("https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fwww.google.com%2F"); }

    void googleSignUp() { openInNewTab("https://accounts.google.com/signup"); }

    void googleSignOut() {
        screens.confirm(R.drawable.ic_exit, new int[]{0xFFFF8A80, 0xFFD32F2F}, L.t("sign_out_t"), L.t("sign_out_m"),
                L.t("sign_out"), () -> openInNewTab("https://accounts.google.com/Logout"));
    }

    void savePdf() {
        // Chrome jaisa: jo page screen par dikh raha hai wahi print ho
        WebView w = null;
        for (int k = webContainer.getChildCount() - 1; k >= 0; k--) {
            View c = webContainer.getChildAt(k);
            if (c instanceof WebView) { w = (WebView) c; break; }
        }
        if (w == null) w = web();
        if (w == null || !isRealUrl(w.getUrl())) { toast("Open a website first"); return; }
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            String title = w.getTitle();
            if (title == null || title.trim().isEmpty()) title = hostOf(w.getUrl());
            if (title == null || title.trim().isEmpty()) title = "Baatora page";
            String name = title.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
            if (name.length() > 80) name = name.substring(0, 80);
            PrintDocumentAdapter a = w.createPrintDocumentAdapter(name);
            PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
            pm.print(name, a, attrs);
        } catch (Exception e) {
            toast("Could not print");
        }
    }

    void clearData() {
        screens.confirm(R.drawable.ic_broom, new int[]{0xFFFFB74D, 0xFFE65100}, L.t("clear_data_t"), L.t("clear_data_m"),
                L.t("clear_btn"), () -> {
                    for (Tab t : tabs) { t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData(); }
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    save("history", new JSONArray());
                    toast("✅");
                    updateUi();
                });
    }

    // ── Autofill, passwords aur site settings (Chrome jaisa) ──
    void openAutofillSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            }
        } catch (Exception ignored) {}
        try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
    }

    void openInTab(String url) { createTab(url, false, true); }

    void clearCookiesOnly() {
        screens.confirm(R.drawable.ic_cookie, new int[]{0xFFFFB74D, 0xFFE65100}, "Clear cookies?",
                "You will be logged out of all websites and their saved data will be removed.", "Clear", () -> {
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    toast("🍪 Cookies and site data cleared");
                });
    }

    // ── Site permissions (Chrome jaisa: har website pehli baar poochhe, jawab yaad rahe) ──
    static String permKind(String[] res) {
        boolean cam = false, mic = false, drm = false;
        if (res != null) for (String r : res) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true;
            else if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) drm = true;
        }
        return cam && mic ? "camera+mic" : cam ? "camera" : mic ? "mic" : drm ? "media" : "other";
    }

    static String permLabel(String k) {
        switch (k) {
            case "camera+mic": return "📷🎤 Camera and Microphone";
            case "camera": return "📷 Camera";
            case "mic": return "🎤 Microphone";
            case "location": return "📍 Location";
            case "media": return "🎬 Protected video (DRM)";
            default: return "🔐 Permission";
        }
    }

    JSONObject sitePerms() {
        try { return new JSONObject(prefs.getString("sitePerms", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    void askSitePerm(String origin, String kind, java.util.function.Consumer<Boolean> done) {
        String host = Uri.parse(origin).getHost();
        if (host == null) host = origin;
        if ("media".equals(kind)) { done.accept(!permDefault("media").equals("block")); return; }   // protected video (DRM)
        final String key = host + "|" + kind;
        JSONObject sp = sitePerms();
        if (sp.has(key)) { done.accept(sp.optBoolean(key)); return; }
        // Settings → Site settings ka default (Ask first / Allowed / Blocked)
        String def = permDefault(kind);
        if (def.equals("allow")) { done.accept(true); return; }
        if (def.equals("block")) { done.accept(false); return; }
        final String fh = host;
        final boolean[] answered = {false};
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(fh)
                .setMessage("This site wants to use your " + permLabel(kind) + ".")
                .setPositiveButton("Allow", (d, w) -> { answered[0] = true; saveSitePerm(key, true); done.accept(true); })
                .setNegativeButton("Block", (d, w) -> { answered[0] = true; saveSitePerm(key, false); done.accept(false); })
                .setNeutralButton("Only this time", (d, w) -> { answered[0] = true; done.accept(true); })
                .create();
        dlg.setOnDismissListener(d -> { if (!answered[0]) done.accept(false); });
        dlg.show();
    }

    void saveSitePerm(String key, boolean allow) {
        try { JSONObject sp = sitePerms(); sp.put(key, allow); prefs.edit().putString("sitePerms", sp.toString()).apply(); } catch (Exception ignored) {}
    }

    /** Settings → Site permissions: kis website ko kya diya — hatao ya badlo. */
    void sitePermissionsScreen() {
        final JSONObject sp = sitePerms();
        final ArrayList<String> keys = new ArrayList<>();
        java.util.Iterator<String> it = sp.keys();
        while (it.hasNext()) keys.add(it.next());
        java.util.Collections.sort(keys);
        if (keys.isEmpty()) { toast("No site has been given any permission yet"); return; }
        String[] rows = new String[keys.size()];
        for (int i = 0; i < keys.size(); i++) {
            String[] p = keys.get(i).split("\\|", 2);
            rows[i] = (sp.optBoolean(keys.get(i)) ? "✅ " : "⛔ ") + p[0] + "\n      " + permLabel(p.length > 1 ? p[1] : "");
        }
        new AlertDialog.Builder(this).setTitle("🔐 Site permissions (tap to remove)")
                .setItems(rows, (d, w) -> {
                    sp.remove(keys.get(w));
                    prefs.edit().putString("sitePerms", sp.toString()).apply();
                    try { android.webkit.GeolocationPermissions.getInstance().clearAll(); } catch (Exception ignored) {}
                    toast("Removed — the site will ask again next time");
                    sitePermissionsScreen();
                })
                .setPositiveButton("Remove all", (d, w) -> { prefs.edit().remove("sitePerms").apply();
                    try { android.webkit.GeolocationPermissions.getInstance().clearAll(); } catch (Exception ignored) {}
                    toast("🔐 Saari site permissions hata di"); })
                .setNegativeButton("Close", null).show();
    }

    void clearSitePermissions() {
        screens.confirm(R.drawable.ic_location, new int[]{0xFF69F0AE, 0xFF00A152}, "Site permissions reset?",
                "Camera, microphone and location permissions given to sites will be removed. Sites will ask again next time.", "Reset", () -> {
                    try { android.webkit.GeolocationPermissions.getInstance().clearAll(); } catch (Exception ignored) {}
                    prefs.edit().remove("sitePerms").apply();
                    toast("🔐 Site permissions reset");
                });
    }

    /** EK BUTTON: history, cache, cookies, site data, form data, site permissions — sab saaf. */
    void clearEverything() {
        screens.confirm(R.drawable.ic_broom, new int[]{0xFFFF5252, 0xFFB71C1C}, "Clear everything?",
                "History, cache, cookies (you will be signed out), site data, form data and all site permissions will be removed. Saved passwords and bookmarks are kept.",
                "Clear all", () -> {
                    for (Tab t : tabs) { t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData(); }
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    try { android.webkit.GeolocationPermissions.getInstance().clearAll(); } catch (Exception ignored) {}
                    try { android.webkit.WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword(); } catch (Exception ignored) {}
                    prefs.edit().remove("sitePerms").apply();
                    save("history", new JSONArray());
                    save("closed", new JSONArray());
                    toast("✅ Browsing data and site permissions cleared");
                    updateUi();
                });
    }

    /** AI ke source link: wahi page kholo (ya us tab par jao) aur vaakya ko page par chamkao. */
    String pendingFind;
    void openOrSwitch(String url, String quote) {
        String base = url.replaceFirst("#.*$", "");
        int idx = -1;
        for (int i = 0; i < tabs.size(); i++) {
            String u = tabs.get(i).web.getUrl();
            if (u != null && u.replaceFirst("#.*$", "").equals(base)) { idx = i; break; }
        }
        if (idx >= 0) {
            switchTab(idx);
            if (quote != null) highlight(quote);
        } else {
            pendingFind = quote;
            createTab(url, false, true);
        }
    }

    void highlight(String quote) {
        final WebView w = web();
        if (w == null || quote == null) return;
        // pehle poora vaakya, na mile to shuru ke kuch shabd
        final String q = quote.trim();
        w.setFindListener((ord, n, done) -> {
            findCount.setText(n == 0 ? "0/0" : (ord + 1) + "/" + n);
            if (!done) return;
            w.setFindListener((active, num, dn) -> findCount.setText(num == 0 ? "0/0" : (active + 1) + "/" + num));
            if (n == 0) {
                String[] ws = q.split("\\s+");
                if (ws.length > 4) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < 4; i++) sb.append(i > 0 ? " " : "").append(ws[i]);
                    w.findAllAsync(sb.toString());
                }
            }
        });
        findBar.setVisibility(View.VISIBLE);
        w.findAllAsync(q);
        toast("🔎 Showing the source on the page");
    }

    // ───────────── Search bar ke style aur rang ─────────────
    static final String[] BAR_STYLES = {"Classic", "Glass", "Neon", "Gradient", "Minimal", "Rainbow"};
    static final String[] BAR_COLOR_NAMES = {"Baatora", "Pink", "Green", "Blue", "Sunset", "Gold", "Purple"};
    static final int[][] BAR_COLORS = {{0, 0, 0}, {0xFFFF4081, 0xFFE040FB, 0xFF7C4DFF}, {0xFF00E676, 0xFF1DE9B6, 0xFF00B0FF},
            {0xFF2979FF, 0xFF00B0FF, 0xFF18FFFF}, {0xFFFF1744, 0xFFFF9100, 0xFFFFEA00}, {0xFFFFD740, 0xFFFFAB00, 0xFFFF6D00},
            {0xFFAA00FF, 0xFF651FFF, 0xFFD500F9}};

    int[] barColors(int ci) {
        if (ci <= 0 || ci >= BAR_COLORS.length) return new int[]{Ui.GOLD, Ui.ORANGE, Ui.CYAN};
        return BAR_COLORS[ci];
    }

    /** Search bar ka background; textOut[0] = text ka rang. */
    android.graphics.drawable.Drawable addressBg(int style, int ci, int[] textOut) {
        int[] c = barColors(ci);
        float r = Ui.dp(25);
        textOut[0] = 0xFF1A1F3D;
        switch (style) {
            case 1: {   // Glass
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x40FFFFFF, 0x1AFFFFFF});
                g.setCornerRadius(r);
                g.setStroke(Ui.dp(1.5f), (c[1] & 0xFFFFFF) | 0xAA000000);
                textOut[0] = Color.WHITE;
                return g;
            }
            case 2: {   // Neon
                GradientDrawable outer = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c[0], c[2]});
                outer.setCornerRadius(r);
                GradientDrawable inner = Ui.round(0xFF0A0F2E, 23);
                android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer, inner});
                ld.setLayerInset(1, Ui.dp(2.5f), Ui.dp(2.5f), Ui.dp(2.5f), Ui.dp(2.5f));
                textOut[0] = Color.WHITE;
                return ld;
            }
            case 3: {   // Gradient
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, c);
                g.setCornerRadius(r);
                g.setStroke(Ui.dp(1), 0x55FFFFFF);
                textOut[0] = Color.WHITE;
                return g;
            }
            case 4: {   // Minimal
                GradientDrawable g = Ui.round(0xFFF1F3F8, 14);
                g.setStroke(Ui.dp(1), (c[1] & 0xFFFFFF) | 0x66000000);
                return g;
            }
            case 5: {   // Rainbow
                GradientDrawable outer = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[]{0xFFFF1744, 0xFFFF9100, 0xFFFFEA00, 0xFF00E676, 0xFF2979FF, 0xFFD500F9});
                outer.setCornerRadius(r);
                GradientDrawable inner = Ui.round(Color.WHITE, 22);
                android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer, inner});
                ld.setLayerInset(1, Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
                return ld;
            }
            default: {  // Classic
                GradientDrawable outer = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, c);
                outer.setCornerRadius(r);
                GradientDrawable inner = Ui.round(Color.WHITE, 23);
                android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer, inner});
                ld.setLayerInset(1, Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2));
                return ld;
            }
        }
    }

    void styleAddressBar() {
        int[] tc = new int[1];
        int st = prefs.getInt("barStyle", 0), ci = prefs.getInt("barColor", 0);
        View box = findViewById(R.id.addressBox);
        box.setBackground(addressBg(st, ci, tc));
        box.setElevation(st == 2 ? Ui.dp(8) : 0);
        if (Build.VERSION.SDK_INT >= 28 && st == 2) { box.setOutlineSpotShadowColor(barColors(ci)[0]); box.setOutlineAmbientShadowColor(barColors(ci)[2]); }
        urlBar.setTextColor(tc[0]);
        urlBar.setHintTextColor((tc[0] & 0xFFFFFF) | 0x99000000);
        int[] c = barColors(ci);
        ImageView mic = findViewById(R.id.btnMic);
        GradientDrawable mg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c[0], c[2]});
        mg.setShape(GradientDrawable.OVAL);
        if (mic != null && ci > 0) mic.setBackground(mg);
    }

    void setBarStyle(int st, int ci) {
        prefs.edit().putInt("barStyle", st).putInt("barColor", ci).apply();
        styleAddressBar();
    }

    // ───────────── Toolbar shortcut (upar wala gol button) ─────────────
    static final String[] SC_KEYS = {"refresh", "newtab", "share", "voice", "ai", "bookmarks", "downloads", "read"};
    static final String[] SC_NAMES = {"Refresh", "New tab", "Share", "Voice search", "Baatora AI", "Bookmarks", "Downloads", "Read aloud"};
    static final int[] SC_ICONS = {R.drawable.ic_refresh, R.drawable.ic_add, R.drawable.ic_share, R.drawable.ic_mic, R.drawable.ic_star,
            R.drawable.ic_bookmark, R.drawable.ic_download, R.drawable.ic_speaker};

    String shortcut() { return prefs.getString("tbShortcut", "refresh"); }

    int shortcutIcon(boolean loadingNow) {
        String k = shortcut();
        if (k.equals("refresh")) return loadingNow ? R.drawable.ic_close : R.drawable.ic_refresh;
        for (int i = 0; i < SC_KEYS.length; i++) if (SC_KEYS[i].equals(k)) return SC_ICONS[i];
        return R.drawable.ic_refresh;
    }

    void runShortcut() {
        WebView w = web();
        switch (shortcut()) {
            case "newtab": createTab(HOME, false, true); break;
            case "share": if (w != null && isRealUrl(w.getUrl())) share(w.getUrl()); else toast("Open a website first"); break;
            case "voice": voiceSearch(); break;
            case "ai": ai.open(); break;
            case "bookmarks": screens.list("bookmarks"); break;
            case "downloads": screens.downloads(); break;
            case "read": readAloud(); break;
            default: if (w != null) { if (loading) w.stopLoading(); else w.reload(); }
        }
    }

    void setShortcut(String k) {
        prefs.edit().putString("tbShortcut", k).apply();
        btnRefresh.setImageResource(shortcutIcon(loading));
    }

    // ───────────── Dynamic colors (wallpaper ke rang, Android 12+) ─────────────
    void applyDynamic() {
        if (!on("dynamic", false) || Build.VERSION.SDK_INT < 31) return;
        try {
            if (Ui.LIGHT) {
                Ui.BAR1 = getColor(android.R.color.system_neutral1_10); Ui.NAVY2 = getColor(android.R.color.system_accent1_50);
                Ui.BLUE = getColor(android.R.color.system_accent1_100); Ui.PAGE1 = getColor(android.R.color.system_neutral1_10);
                Ui.NAVY = getColor(android.R.color.system_neutral1_0); Ui.DEEP = getColor(android.R.color.system_accent1_50);
                Ui.ORANGE = getColor(android.R.color.system_accent1_600); Ui.CYAN = getColor(android.R.color.system_accent2_600);
                Ui.GOLD = getColor(android.R.color.system_accent3_600); Ui.ACC = getColor(android.R.color.system_accent1_600);
            } else {
                Ui.BAR1 = getColor(android.R.color.system_accent1_900); Ui.NAVY2 = getColor(android.R.color.system_accent1_700);
                Ui.BLUE = getColor(android.R.color.system_accent1_500); Ui.PAGE1 = getColor(android.R.color.system_accent1_800);
                Ui.NAVY = getColor(android.R.color.system_accent1_900); Ui.DEEP = getColor(android.R.color.system_neutral1_1000);
                Ui.ORANGE = getColor(android.R.color.system_accent3_300); Ui.CYAN = getColor(android.R.color.system_accent2_200);
                Ui.GOLD = getColor(android.R.color.system_accent3_100); Ui.ACC = getColor(android.R.color.system_accent1_400);
            }
        } catch (Exception ignored) {}
    }

    void toggleDynamic() {
        if (Build.VERSION.SDK_INT < 31) { toast("Dynamic colors need Android 12 or newer"); return; }
        togglePref("dynamic", false);
        Ui.applyMode(prefs.getString("mode", "default"), prefs.getString("theme", "original"));
        applyDynamic();
        applyThemeToViews();
        updateUi();
        refreshHomes();
    }

    // ───────────── Site settings defaults ─────────────
    static final String[] PERM_KINDS = {"location", "camera", "mic", "motion", "clipboard", "media"};
    String permDefault(String kind) {
        if (kind.equals("camera+mic")) {
            String c = permDefault("camera"), m = permDefault("mic");
            if (c.equals("block") || m.equals("block")) return "block";
            return c.equals("allow") && m.equals("allow") ? "allow" : "ask";
        }
        String d = kind.equals("motion") || kind.equals("media") ? "allow" : "ask";
        try { return prefs.getString("permDef_" + kind, d); } catch (Exception e) { return d; }
    }

    void setPermDefault(String kind, String v) {
        prefs.edit().putString("permDef_" + kind, v).apply();
        WebView w = web();
        if ((kind.equals("motion") || kind.equals("clipboard")) && w != null && isRealUrl(w.getUrl())) w.reload();
    }

    /** Motion sensor aur clipboard padhna — Site settings me Block ho to website ko na mile. */
    static final String PERM_JS = "(function(){try{var C=window.BaatoraCfg;if(!C)return;"
            + "if(!C.motion()){var ae=window.addEventListener;window.addEventListener=function(t,f,o){if(t==='deviceorientation'||t==='devicemotion'||t==='deviceorientationabsolute')return;return ae.call(this,t,f,o);};"
            + "try{Object.defineProperty(window,'ondeviceorientation',{set:function(){},get:function(){return null}});Object.defineProperty(window,'ondevicemotion',{set:function(){},get:function(){return null}});}catch(e){}}"
            + "if(!C.clip()&&navigator.clipboard){var no=function(){return Promise.reject(new DOMException('Blocked by Baatora','NotAllowedError'));};"
            + "try{navigator.clipboard.readText=no;navigator.clipboard.read=no;}catch(e){}}"
            + "}catch(e){}})();";

    // ───────────── Zoom (Accessibility) ─────────────
    JSONObject siteZooms() { try { return new JSONObject(prefs.getString("siteZoom", "{}")); } catch (Exception e) { return new JSONObject(); } }

    int zoomFor(String host) {
        int def = prefs.getInt("textZoom", 100);
        if (host == null) return def;
        return siteZooms().optInt(host.replaceFirst("^(www|m)\\.", ""), def);
    }

    void setDefaultZoom(int z) {
        prefs.edit().putInt("textZoom", z).apply();
        for (Tab t : tabs) t.web.getSettings().setTextZoom(zoomFor(t.pageHost));
    }

    void setSiteZoom(String host, int z) {
        if (host == null) return;
        try {
            JSONObject o = siteZooms();
            String k = host.replaceFirst("^(www|m)\\.", "");
            if (z == prefs.getInt("textZoom", 100)) o.remove(k); else o.put(k, z);
            prefs.edit().putString("siteZoom", o.toString()).apply();
        } catch (Exception ignored) {}
        WebView w = web();
        if (w != null) w.getSettings().setTextZoom(z);
    }

    static final String FORCE_ZOOM_JS = "(function(){var m=document.querySelector('meta[name=viewport]');"
            + "if(m){m.setAttribute('content','width=device-width, initial-scale=1, minimum-scale=0.25, maximum-scale=10, user-scalable=yes');}})();";

    /** Simplified view: lamba article mile to neeche "📖 Simplified view" button dikhao. */
    void checkSimplified(WebView v) {
        v.evaluateJavascript("(function(){var a=document.querySelector('article');var t=(a||document.body).innerText||'';"
                + "var p=document.querySelectorAll('p').length;return (a&&t.length>1500)||(p>8&&t.length>2500);})()", r -> {
            if (!"true".equals(r)) return;
            mediaFab.setVisibility(View.VISIBLE);
            styleFabText("📖  Simplified view", "Tap to read without clutter");
            mediaFab.setTag("simplified");
            mediaFab.postDelayed(() -> { if ("simplified".equals(mediaFab.getTag())) { mediaFab.setVisibility(View.GONE); mediaFab.setTag(null); } }, 8000);
        });
    }

    void styleFabText(String title, String sub) {
        fabKey = "";
        styleFab(false, sub);
        android.text.SpannableString sp = new android.text.SpannableString(title + "\n" + sub);
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(15, true), 0, title.length(), 0);
        sp.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, title.length(), 0);
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(11, true), title.length() + 1, sp.length(), 0);
        mediaFab.setText(sp);
        mediaFab.setCompoundDrawablesRelative(null, null, null, null);
        mediaFab.setPaddingRelative(Ui.dp(20), Ui.dp(9), Ui.dp(20), Ui.dp(9));
    }

    // ───────────── Multiple windows ─────────────
    void openNewWindow(String url) {
        try {
            Intent i = new Intent(this, WebAppActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(url))
                    .putExtra(WebAppActivity.EXTRA_NAME, Uri.parse(url).getHost())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK | Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
            if (Build.VERSION.SDK_INT >= 24 && isInMultiWindowMode()) i.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);
            startActivity(i);
        } catch (Exception e) { toast("Could not open a new window"); }
    }

    void openFind() {
        findBar.setVisibility(View.VISIBLE);
        findInput.setText("");
        findInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
    }

    void closeFind() {
        findBar.setVisibility(View.GONE);
        WebView w = web(); if (w != null) w.clearMatches();
        hideKeyboard();
    }

    void voiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, L.t("voice_prompt"));
        String vl;
        switch (L.key()) {
            case "english": vl = "en-IN"; break;
            case "marathi": vl = "mr-IN"; break;
            case "bengali": vl = "bn-IN"; break;
            case "punjabi": vl = "pa-IN"; break;
            default: vl = "hi-IN";
        }
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, vl);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, vl);
        // Hindi + English mila-jula bolo to bhi samjhe
        i.putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", new String[]{"en-IN", "hi-IN"});
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { startActivityForResult(i, REQ_VOICE); }
        catch (ActivityNotFoundException e) { toast("Voice search is not available on this phone"); }
    }

    boolean onLongPress(WebView w) {
        WebView.HitTestResult h = w.getHitTestResult();
        final String extra = h.getExtra();
        int type = h.getType();
        if (extra == null) return false;
        final boolean isImg = type == WebView.HitTestResult.IMAGE_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE;
        boolean isLink = type == WebView.HitTestResult.SRC_ANCHOR_TYPE;
        if (!isImg && !isLink) return false;
        Tab owner = cur();
        final boolean inc = owner != null && owner.incognito;
        String[] opts = isImg
                ? new String[]{"Open image in new tab", "Download image", "Copy image link", "Share"}
                : (on("multiWin", false) ? new String[]{"Open in new tab", "Open in Incognito tab", "Copy link", "Share", "Open in new window"}
                    : new String[]{"Open in new tab", "Open in Incognito tab", "Copy link", "Share"});
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(extra.length() > 80 ? extra.substring(0, 80) + "…" : extra)
                .setItems(opts, (d, which) -> {
                    switch (which) {
                        case 0: createTab(extra, inc, true); break;
                        case 1:
                            if (isImg) onDownload(extra, w.getSettings().getUserAgentString(), null, null, 0);
                            else createTab(extra, true, true);
                            break;
                        case 2: copy(extra); break;
                        case 3: share(extra); break;
                        case 4: openNewWindow(extra); break;
                    }
                }).show();
        return true;
    }

    // ───────────────────────── DOWNLOADS ─────────────────────────

    void onDownload(String url, String ua, String cd, String mime, long len) {
        if (url.startsWith("blob:")) {
            downloadBlob(url, URLUtil.guessFileName(url, cd, mime), mime);
            return;
        }
        if (url.startsWith("data:")) {
            toast("This type of download is not supported yet");
            return;
        }
        if (isYouTube(url) && !officialYtDownload(cd)) { screens.youtubeInfo(); return; }
        String name = URLUtil.guessFileName(url, cd, mime);
        if (isHls(url, mime)) {
            WebView cw = web();
            String title = cw == null ? null : cw.getTitle();
            title = title == null ? "" : title.replaceAll("[\\\\/:*?\"<>|\\r\\n]", " ").replaceAll("\\s+", " ").trim();
            if (title.length() > 80) title = title.substring(0, 80).trim();
            name = (title.isEmpty() ? "Baatora_video_" + (System.currentTimeMillis() / 1000) : title) + ".mp4";
            mime = "video/mp4";
        }
        if (!prefs.getBoolean("askDl", true)) { startDownload(url, ua, mime, name); return; }
        screens.downloadSheet(url, ua, mime, name, len);
    }

    static boolean isHls(String url, String mime) {
        try {
            String p = Uri.parse(url).getPath();
            if (p != null && p.toLowerCase().endsWith(".m3u8")) return true;
        } catch (Exception ignored) {}
        return mime != null && mime.toLowerCase().contains("mpegurl");
    }

    void downloadBlob(String url, String name, String mime) {
        WebView w = web();
        if (w == null) return;
        blobToken = Long.toHexString(System.nanoTime());
        blobName = name;
        toast("Download started ⬇ " + name);
        String js = "(function(u,k,n){fetch(u).then(function(r){return r.blob()}).then(function(b){var rd=new FileReader();"
                + "rd.onloadend=function(){var d=rd.result,s=d.substring(d.indexOf(',')+1),z=262144;"
                + "if(!s.length){BaatoraBlob.chunk(k,'',true,b.type,n);return;}"
                + "for(var p=0;p<s.length;p+=z){BaatoraBlob.chunk(k,s.substring(p,p+z),p+z>=s.length,b.type,n);}};"
                + "rd.readAsDataURL(b);}).catch(function(e){BaatoraBlob.fail(k);});})("
                + JSONObject.quote(url) + ",'" + blobToken + "'," + JSONObject.quote(name) + ")";
        w.evaluateJavascript(js, null);
    }

    String blobName;
    java.io.OutputStream blobOs;

    /** Page ke scripts ko batata hai ki Ad Block chalu hai ya nahi. */
    // ── Video chhota karein (Picture-in-Picture), YouTube app jaisa ──
    volatile boolean videoPlaying;
    volatile int vidW = 16, vidH = 9;
    boolean inPip;

    android.app.PictureInPictureParams pipParams() {
        int w = Math.max(1, vidW), h = Math.max(1, vidH);
        float r = w / (float) h;
        if (r > 2.39f) { w = 239; h = 100; } else if (r < 0.42f) { w = 42; h = 100; }
        android.app.PictureInPictureParams.Builder b = new android.app.PictureInPictureParams.Builder()
                .setAspectRatio(new android.util.Rational(w, h));
        if (Build.VERSION.SDK_INT >= 31) { b.setAutoEnterEnabled(videoPlaying); b.setSeamlessResizeEnabled(true); }
        return b.build();
    }

    void updatePip() {
        if (Build.VERSION.SDK_INT < 26) return;
        try { setPictureInPictureParams(pipParams()); } catch (Exception ignored) {}
    }

    /** Menu / button se: abhi video chhota karo. */
    void enterPip() {
        if (Build.VERSION.SDK_INT < 26) { toast("Picture-in-picture is not supported on this phone"); return; }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) { toast("Picture-in-picture is turned off on this phone"); return; }
        try { enterPictureInPictureMode(pipParams()); } catch (Exception e) { toast("Could not start picture-in-picture"); }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        // Home dabaya aur video chal raha tha → video chhoti khidki me chalta rahe
        if (Build.VERSION.SDK_INT >= 26 && Build.VERSION.SDK_INT < 31 && videoPlaying && !inPip) {
            try { enterPictureInPictureMode(pipParams()); } catch (Exception ignored) {}
        }
    }

    static final String PIP_ON = "(function(){var vs=document.querySelectorAll('video'),v=null;for(var i=0;i<vs.length;i++){if(!vs[i].paused){v=vs[i];break;}}" +
            "if(!v)v=vs[0];if(!v)return;var s=document.getElementById('bt-pip-css');if(!s){s=document.createElement('style');s.id='bt-pip-css';" +
            "s.textContent='.bt-pip-v{position:fixed!important;left:0!important;top:0!important;width:100vw!important;height:100vh!important;" +
            "z-index:2147483647!important;background:#000!important;object-fit:contain!important;transform:none!important}" +
            "html.bt-pip,html.bt-pip body{overflow:hidden!important}';document.documentElement.appendChild(s);}" +
            "document.documentElement.classList.add('bt-pip');v.classList.add('bt-pip-v');})()";
    static final String PIP_OFF = "(function(){document.documentElement.classList.remove('bt-pip');" +
            "document.querySelectorAll('.bt-pip-v').forEach(function(v){v.classList.remove('bt-pip-v');});})()";

    @Override
    public void onPictureInPictureModeChanged(boolean pip, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(pip, cfg);
        inPip = pip;
        try {
            topBar.setVisibility(pip ? View.GONE : View.VISIBLE);
            if (pip) bottomBar.setVisibility(View.GONE); else applyNavBar();
            if (aiBtn != null) aiBtn.setVisibility(pip ? View.GONE : (prefs.getBoolean("aiBtn", true) ? View.VISIBLE : View.GONE));
            mediaFab.setVisibility(View.GONE);
            WebView w = web();
            if (customView == null && w != null) w.evaluateJavascript(pip ? PIP_ON : PIP_OFF, null);
            if (!pip) updateUi();
        } catch (Exception ignored) {}
    }

    class CfgBridge {
        @android.webkit.JavascriptInterface
        public boolean motion() { return !permDefault("motion").equals("block"); }

        @android.webkit.JavascriptInterface
        public boolean clip() { return !permDefault("clipboard").equals("block"); }

        @android.webkit.JavascriptInterface
        public boolean ad() { return adBlock; }

        /** Page batata hai ki video chal raha hai ya ruka — Home dabane par chhota video (PiP) ke liye. */
        @android.webkit.JavascriptInterface
        public void video(final boolean playing, final int w, final int h) {
            runOnUiThread(() -> {
                videoPlaying = playing;
                if (w > 0 && h > 0) { vidW = w; vidH = h; }
                updatePip();
            });
        }

        /** Home page ka design (page number) aur scroll — upar/neeche ki patti bhi usi rang me. */
        @android.webkit.JavascriptInterface
        public void homeSkin(final int page, final float scroll) {
            runOnUiThread(() -> {
                homeSkin = page;
                homeScroll = Math.max(0f, Math.min(1f, scroll));
                Tab t = cur();
                String u = t == null ? null : t.web.getUrl();
                if (t != null && !t.incognito && (u == null || u.startsWith(HOME))) applyHomeSkin();
            });
        }

        @android.webkit.JavascriptInterface
        public void blocked(int n) { try { Store.addAds(MainActivity.this, Math.max(1, Math.min(n, 20))); } catch (Throwable ignored) {} }
    }

    static final java.util.Set<String> YT_ORIGINS = new java.util.HashSet<>(java.util.Arrays.asList(
            "https://*.youtube.com", "https://youtube.com", "https://*.youtube-nocookie.com"));
    final java.util.HashMap<String, String> assetCache = new java.util.HashMap<>();

    String asset(String name) {
        String c = assetCache.get(name);
        if (c != null) return c;
        try {
            java.io.InputStream is = getAssets().open(name);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            is.close();
            c = bo.toString("UTF-8");
        } catch (Exception e) { c = ""; }
        assetCache.put(name, c);
        return c;
    }

    /** YouTube ad-block aur video gesture ko page ke bilkul shuru me chalao (ad load hone se pehle). */
    boolean startScripts;
    void addStartScripts(WebView w) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
            String yt = asset("ytblock.js"), vg = asset("vgesture.js");
            if (!yt.isEmpty()) WebViewCompat.addDocumentStartJavaScript(w, yt, YT_ORIGINS);
            if (!vg.isEmpty()) WebViewCompat.addDocumentStartJavaScript(w, vg, java.util.Collections.singleton("*"));
            WebViewCompat.addDocumentStartJavaScript(w, PERM_JS, java.util.Collections.singleton("*"));
            startScripts = true;
        } catch (Throwable ignored) {}
    }

    static boolean isYtAd(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        if (h.endsWith("doubleclick.net") || h.endsWith("googlesyndication.com") || h.endsWith("googleadservices.com")
                || h.equals("adservice.google.com") || h.endsWith("imasdk.googleapis.com")) return true;
        if (!(h.endsWith("youtube.com") || h.endsWith("google.com"))) return false;
        String p = u.getEncodedPath();
        if (p == null) return false;
        return p.startsWith("/pagead/") || p.startsWith("/api/stats/ads") || p.startsWith("/get_midroll_info")
                || p.startsWith("/youtubei/v1/player/ad_break") || p.startsWith("/pcs/activeview")
                || p.startsWith("/ptracking") || p.contains("/ad_data_204") || p.startsWith("/api/stats/atr");
    }

    // ── Home page ke har design ke saath upar/neeche ki patti ka rang ──
    int homeSkin = -1;
    float homeScroll = 0f;
    boolean skinOn;
    android.graphics.drawable.Drawable defaultBottomBg;
    // [page] = {upar ke 3 rang (scroll se pehle)}, {scroll ke baad}, {chamakti line}
    static final int[][] SKIN_A = {
            {0xFF0B1A5E, 0xFF2A1C7C, 0xFF5B1FA0}, {0xFF120E07, 0xFF231B0C, 0xFF3A2C12},
            {0xFF05090C, 0xFF0A1B22, 0xFF12343B}, {0xFF14061F, 0xFF2B0A3D, 0xFF4A1060}, {0xFF0B0B1E, 0xFF221650, 0xFF3D1F8A}};
    static final int[][] SKIN_B = {
            {0xFF3A0F6E, 0xFF6A1FB0, 0xFFB0247A}, {0xFF2A1F08, 0xFF5C4512, 0xFF8A6418},
            {0xFF06262B, 0xFF0D4A50, 0xFF138A7E}, {0xFF3D0A2E, 0xFF7A0F4A, 0xFFB3123F}, {0xFF1B0B3E, 0xFF5B2BB0, 0xFFB0247A}};
    static final int[][] SKIN_LINE = {
            {0xFFFF8A00, 0xFFFFC107, 0xFF00E5FF}, {0xFF8A6418, 0xFFF9E29C, 0xFF8A6418},
            {0xFF00BFA5, 0xFF7FFFE6, 0xFF1DE9B6}, {0xFFFF1744, 0xFFFF9100, 0xFFD500F9}, {0xFF7C4DFF, 0xFF00E5FF, 0xFFFF4081}};

    static int mix(int a, int b, float f) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return 0xFF000000 | ((int) (ar + (br - ar) * f) << 16) | ((int) (ag + (bg - ag) * f) << 8) | (int) (ab + (bb - ab) * f);
    }

    void applyHomeSkin() {
        if (homeSkin < 0) return;
        int p = Math.min(homeSkin, SKIN_A.length - 1);
        float f = homeScroll;
        int c1 = mix(SKIN_A[p][0], SKIN_B[p][0], f), c2 = mix(SKIN_A[p][1], SKIN_B[p][1], f), c3 = mix(SKIN_A[p][2], SKIN_B[p][2], f);
        GradientDrawable tl = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, SKIN_LINE[p]);
        GradientDrawable tf = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2, c3});
        android.graphics.drawable.LayerDrawable top = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{tl, tf});
        top.setLayerInset(1, 0, 0, 0, Ui.dp(2));
        topBar.setBackground(top);
        GradientDrawable bl = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, SKIN_LINE[p]);
        GradientDrawable bf = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c3, c2, c1});
        android.graphics.drawable.LayerDrawable bot = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{bl, bf});
        bot.setLayerInset(1, 0, Ui.dp(2), 0, 0);
        bottomBar.setBackground(bot);
        styleHome(SKIN_LINE[p][0], SKIN_LINE[p][1], SKIN_LINE[p][2]);
        getWindow().setStatusBarColor(c1);
        getWindow().setNavigationBarColor(c1);
        skinOn = true;
    }

    /** Home button: 3 rang ka chamakta gol button, safed patli kinari, andar chamak — premium look. */
    void styleHome(int c1, int c2, int c3) {
        View hbtn = findViewById(R.id.btnHome);
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2, c3});
        fill.setShape(GradientDrawable.OVAL);
        fill.setStroke(Ui.dp(2), 0xCCFFFFFF);
        GradientDrawable shine = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x55FFFFFF, 0x00FFFFFF});
        shine.setShape(GradientDrawable.OVAL);
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{fill, shine});
        ld.setLayerInset(1, Ui.dp(5), Ui.dp(3), Ui.dp(5), Ui.dp(22));
        hbtn.setBackground(ld);
        hbtn.setElevation(Ui.dp(10));
        if (Build.VERSION.SDK_INT >= 28) { hbtn.setOutlineSpotShadowColor(c2); hbtn.setOutlineAmbientShadowColor(c3); }
    }

    void clearHomeSkin() {
        if (!skinOn) return;
        skinOn = false;
        if (defaultBottomBg != null) bottomBar.setBackground(defaultBottomBg);
        styleHome(0xFFFF8A00, 0xFF7C4DFF, 0xFF1E5BFF);
        getWindow().setNavigationBarColor(Ui.DEEP);
    }

    class BlobBridge {
        @android.webkit.JavascriptInterface
        public synchronized void chunk(String key, String b64, boolean last, String mime, String name) {
            if (blobToken == null || !blobToken.equals(key)) return;
            try {
                if (blobOs == null) {
                    String n = (name == null || name.isEmpty() ? "download" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
                    String mt = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME, n);
                        cv.put(MediaStore.Downloads.MIME_TYPE, mt);
                        cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        blobOs = getContentResolver().openOutputStream(u);
                    } else {
                        java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        dir.mkdirs();
                        blobOs = new java.io.FileOutputStream(new java.io.File(dir, n));
                    }
                    blobName = n;
                }
                if (b64 != null && !b64.isEmpty()) blobOs.write(android.util.Base64.decode(b64, android.util.Base64.DEFAULT));
                if (last) {
                    blobOs.close();
                    blobOs = null;
                    blobToken = null;
                    final String nm = blobName;
                    runOnUiThread(() -> toast("Download complete ✅ " + nm));
                }
            } catch (Exception e) {
                try { if (blobOs != null) blobOs.close(); } catch (Exception ignored) {}
                blobOs = null;
                blobToken = null;
                runOnUiThread(() -> toast("Download fail"));
            }
        }

        @android.webkit.JavascriptInterface
        public void fail(String key) {
            if (blobToken != null && blobToken.equals(key)) {
                blobToken = null;
                runOnUiThread(() -> toast("Download fail"));
            }
        }
    }

    void startDownload(String url, String ua, String mime, String name) {
        if (Build.VERSION.SDK_INT < 29 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("Grant storage permission, then download again");
            return;
        }
        if (TurboService.isRunning(url)) { toast("⏳ This file is already downloading — see Downloads"); return; }
        if (on("turboOn", true) || isHls(url, mime)) {
            if (Build.VERSION.SDK_INT >= 33 && !granted("android.permission.POST_NOTIFICATIONS")
                    && !prefs.getBoolean("askedNotif", false)) {
                prefs.edit().putBoolean("askedNotif", true).apply();
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 40);
            }
            WebView cw = web();
            String ref = (cw != null && isRealUrl(cw.getUrl())) ? cw.getUrl() : null;
            try {
                TurboService.start(this, url, ua != null ? ua : mobileUA, CookieManager.getInstance().getCookie(url), ref, mime, name);
                toast("⚡ Turbo download started: " + name);
                return;
            } catch (Exception e) {
                // agar service na chale to normal download
                if (isHls(url, mime)) { toast("Could not start video download"); return; }
            }
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", ua != null ? ua : mobileUA);
            WebView w = web();
            if (w != null && isRealUrl(w.getUrl())) r.addRequestHeader("Referer", w.getUrl());
            r.setTitle(name);
            r.setDescription("Baatora Browser");
            r.setAllowedOverMetered(true);
            r.setAllowedOverRoaming(true);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = dm.enqueue(r);
            JSONArray ids = load("dl_ids");
            ids.put(id);
            save("dl_ids", ids);
            toast("Download started ⬇ " + name);
        } catch (Exception e) {
            toast("Download fail: " + e.getMessage());
        }
    }

    // ───────────────────────── BOOKMARKS / HISTORY ─────────────────────────

    JSONArray load(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void save(String key, JSONArray arr) { prefs.edit().putString(key, arr.toString()).apply(); }

    void addHistory(String title, String url) {
        try {
            JSONArray old = load("history");
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(title) ? url : title);
            o.put("u", url);
            o.put("time", System.currentTimeMillis());
            arr.put(o);
            countVisit(title, url);
            for (int i = 0; i < old.length() && arr.length() < 2000; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !url.equals(x.optString("u"))) arr.put(x);
            }
            save("history", arr);
        } catch (Exception ignored) {}
    }

    /** Sabse zyada khuli sites (Home par "Most visited"). */
    void countVisit(String title, String url) {
        try {
            String host = Uri.parse(url).getHost();
            if (host == null) return;
            JSONObject v = new JSONObject(prefs.getString("visits", "{}"));
            JSONObject e = v.optJSONObject(host);
            if (e == null) { e = new JSONObject(); e.put("c", 0); }
            e.put("c", e.optInt("c") + 1);
            e.put("u", Uri.parse(url).getScheme() + "://" + host);
            e.put("t", TextUtils.isEmpty(title) ? host : title);
            e.put("time", System.currentTimeMillis());
            v.put(host, e);
            prefs.edit().putString("visits", v.toString()).apply();
        } catch (Exception ignored) {}
    }

    JSONArray topSites() {
        JSONArray out = new JSONArray();
        try {
            JSONObject v = new JSONObject(prefs.getString("visits", "{}"));
            ArrayList<JSONObject> list = new ArrayList<>();
            java.util.Iterator<String> it = v.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject e = v.getJSONObject(k);
                e.put("h", k);
                if (e.optInt("c") >= 2) list.add(e);
            }
            java.util.Collections.sort(list, (x, y) -> y.optInt("c") - x.optInt("c"));
            for (int i = 0; i < list.size() && i < 8; i++) out.put(list.get(i));
        } catch (Exception ignored) {}
        return out;
    }

    void addBookmark() {
        WebView w = web();
        String u = w == null ? null : w.getUrl();
        if (!isRealUrl(u)) { toast("Open a website first"); return; }
        try {
            JSONArray arr = load("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.optJSONObject(i);
                if (x != null && u.equals(x.optString("u"))) { toast("Already bookmarked ⭐"); return; }
            }
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(w.getTitle()) ? u : w.getTitle());
            o.put("u", u);
            o.put("time", System.currentTimeMillis());
            JSONArray out = new JSONArray();
            out.put(o);
            for (int i = 0; i < arr.length(); i++) out.put(arr.get(i));
            save("bookmarks", out);
            toast("Bookmarked ⭐");
        } catch (Exception e) {
            toast("Could not add bookmark");
        }
    }

    // ═════════════════════ NAYE FEATURES (v5) ═════════════════════

    static final String CF_PKG = "com.cloudflare.onedotonedotonedotone";
    static final String READER_JS =
            "(function(){var a=document.querySelector('article')||document.querySelector('main')||document.body;" +
            "var out=[],last='';a.querySelectorAll('h1,h2,h3,p,li,blockquote,img').forEach(function(e){" +
            "if(out.length>600)return;if(e.tagName=='IMG'){if(e.src&&/^https?:/.test(e.src)&&e.naturalWidth>180)out.push({g:'IMG',x:e.src});return;}" +
            "var x=(e.innerText||'').trim();if(x.length>1&&x!==last&&last.indexOf(x)<0){out.push({g:e.tagName,x:x});last=x;}});" +
            "return JSON.stringify({t:document.title,p:out});})()";

    // ── Session (tabs yaad rakhna) ──
    void saveSession() {
        if (tabs.isEmpty()) return; // startup ke turant baad khaali session save na ho
        try {
            JSONArray arr = new JSONArray();
            int idx = 0, n = 0;
            for (int i = 0; i < tabs.size(); i++) {
                Tab t = tabs.get(i);
                if (t.incognito) continue;
                String u = t.web.getUrl();
                if (u == null && t.pendingUrl != null) u = t.pendingUrl;
                if (u == null || u.startsWith("data:") || u.equals("about:blank")) u = HOME;
                if (i == current) idx = n;
                arr.put(u);
                n++;
            }
            prefs.edit().putString("session", arr.toString()).putInt("sessionIdx", idx).apply();
        } catch (Exception ignored) {}
    }

    boolean restoreSession() {
        if (!prefs.getBoolean("restore", true)) return false;
        JSONArray arr = load("session");
        if (arr.length() == 0) return false;
        final int want = Math.min(prefs.getInt("sessionIdx", 0), arr.length() - 1);
        // Sirf abhi dikhne wala tab turant load hota hai; baaki tabs splash ke baad (startup halka rahe)
        final ArrayList<Tab> later = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            String u = arr.optString(i, HOME);
            Tab t = createTab(i == want ? u : null, false, false);
            if (i != want) { t.pendingUrl = u; later.add(t); }
        }
        current = -1;
        switchTab(Math.max(0, want));
        webContainer.postDelayed(() -> {
            for (Tab t : later) {
                if (tabs.contains(t) && t.pendingUrl != null) { String u = t.pendingUrl; t.pendingUrl = null; t.web.loadUrl(u); }
            }
        }, 2600);
        return true;
    }

    // ── Band kiye gaye tabs ──
    void pushClosed(String title, String url) {
        try {
            JSONArray old = load("closed"), arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(title) ? url : title);
            o.put("u", url);
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 15; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !url.equals(x.optString("u"))) arr.put(x);
            }
            save("closed", arr);
        } catch (Exception ignored) {}
    }

    // ── Notifications ──
    void addNotif(String type, String title, String msg) {
        Store.addNotif(this, type, title, msg);
        refreshHomes();
    }

    int unreadNotifs() {
        JSONArray arr = load("notifs");
        int n = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && !o.optBoolean("read")) n++;
        }
        return n;
    }

    void markNotifsRead() {
        try {
            JSONArray arr = load("notifs");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) o.put("read", true);
            }
            save("notifs", arr);
            refreshHomes();
        } catch (Exception ignored) {}
    }

    void registerDownloadWatcher() {
        dlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                JSONArray ids = load("dl_ids");
                boolean ours = false;
                for (int k = 0; k < ids.length(); k++) if (ids.optLong(k) == id) ours = true;
                if (!ours || !prefs.getBoolean("notif", true)) return;
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                Cursor cur = null;
                try {
                    cur = dm.query(new DownloadManager.Query().setFilterById(id));
                    if (cur != null && cur.moveToFirst()) {
                        String title = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                        int st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                        boolean ok = st == DownloadManager.STATUS_SUCCESSFUL;
                        addNotif(ok ? "dl" : "dlfail", ok ? "Download complete ✅" : "Download failed ❌", title);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (cur != null) cur.close();
                }
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlReceiver, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(dlReceiver, f);
    }

    void versionNotes() {
        if (!on("newsPopups", true)) return;   // Settings → Notification → Receive pop-ups
        int last = prefs.getInt("lastVersion", 0);
        if (last == 0) addNotif("welcome", "Welcome to Baatora 🎉", "Made in India browser — fast, secure and truly yours.");
        if (last < 5) addNotif("new", "New in Version 5.0 ✨",
                "Free VPN, Notifications, Reader mode, Read aloud, Translate, Screenshot, Home screen shortcut and a new design!");
        if (last < 8) addNotif("new", "Version 6.2 ✨",
                "Light Google look, Search suggestions, Most visited, " +
                "one-tap copied link, instant Incognito, a new intro and a new mic.");
        if (last < 6) addNotif("new", "New in Version 6.0 ⚡",
                "Turbo download, today's data, History filters (Today/7 days/1 year), VPN countries and a new design!");
        prefs.edit().putInt("lastVersion", 8).apply();
    }

    // ── Web settings jo Settings se badalte hain ──
    void applyWebPrefs(Tab t) {
        WebSettings s = t.web.getSettings();
        s.setJavaScriptEnabled(prefs.getBoolean("js", true));
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        boolean saver = prefs.getBoolean("datasaver", false);
        s.setMediaPlaybackRequiresUserGesture(saver || !prefs.getBoolean("autoplay", true));
        if (!t.incognito) s.setCacheMode(saver ? WebSettings.LOAD_CACHE_ELSE_NETWORK : WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(prefs.getBoolean("safe", true));
        CookieManager.getInstance().setAcceptThirdPartyCookies(t.web, prefs.getBoolean("tpc", true));
        boolean img = on("images", true);
        s.setLoadsImagesAutomatically(img);
        s.setBlockNetworkImage(!img);
    }

    void toggleWebPref(String key, boolean def) {
        boolean v = !prefs.getBoolean(key, def);
        prefs.edit().putBoolean(key, v).apply();
        for (Tab t : tabs) applyWebPrefs(t);
        WebView w = web();
        if (w != null && isRealUrl(w.getUrl())) w.reload();
    }

    /** Sirf Ads Block (pop-up nahi rokta). Default band. */
    void toggleAdBlock() {
        adBlock = !adBlock;
        prefs.edit().putBoolean("adblockOn", adBlock).apply();
        toast(adBlock ? "🛡 Ad Block ON" : "Ad Block OFF");
        WebView w = web();
        if (w != null && isRealUrl(w.getUrl())) w.reload();
    }

    void togglePref(String key, boolean def) {
        prefs.edit().putBoolean(key, !on(key, def)).apply();
    }

    // ── Default browser ──
    boolean isDefaultBrowser() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_BROWSER);
        }
        return false;
    }

    void setDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = getSystemService(RoleManager.class);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_BROWSER) && !rm.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_BROWSER), 30);
                    return;
                }
            }
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            toast("Choose Baatora as the Browser app");
        } catch (Exception e) {
            toast("Phone Settings → Apps → Default apps → choose Baatora");
        }
    }

    // ── VPN ──
    boolean vpnActive() {
        try {
            ConnectivityManager cm = getSystemService(ConnectivityManager.class);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            return nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } catch (Exception e) {
            return false;
        }
    }

    /** Baatora ka apna VPN (Baatora Shield) chalu/band. */
    Runnable afterVpn;
    boolean myVpnOn() { return BaatoraVpn.running; }

    void toggleMyVpn(Runnable after) {
        afterVpn = after;
        if (BaatoraVpn.running) {
            BaatoraVpn.stop(this);
            toast("VPN turned off");
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> { if (afterVpn != null) afterVpn.run(); }, 500);
            return;
        }
        try {
            Intent i = android.net.VpnService.prepare(this);
            if (i != null) { startActivityForResult(i, REQ_VPN); return; }
            startMyVpn();
        } catch (Exception e) { toast("Could not start VPN"); }
    }

    void startMyVpn() {
        try { BaatoraVpn.start(this); } catch (Exception e) { toast("Could not start VPN"); return; }
        toast("🛡 Baatora VPN is on");
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> { if (afterVpn != null) afterVpn.run(); }, 700);
    }

    static final String PROTON_PKG = "ch.protonvpn.android", WINDSCRIBE_PKG = "com.windscribe.vpn";

    boolean cloudflareInstalled() { return isInstalled(CF_PKG); }

    boolean isInstalled(String pkg) { return getPackageManager().getLaunchIntentForPackage(pkg) != null; }

    void openVpnApp(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) { startActivity(i); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg))); }
        catch (Exception e) { createTab("https://play.google.com/store/apps/details?id=" + pkg, false, true); }
    }

    void openFreeVpn() {
        Intent i = getPackageManager().getLaunchIntentForPackage(CF_PKG);
        if (i != null) { startActivity(i); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + CF_PKG))); }
        catch (Exception e) { createTab("https://play.google.com/store/apps/details?id=" + CF_PKG, false, true); }
    }

    void openVpnSettings() {
        try { startActivity(new Intent("android.settings.VPN_SETTINGS")); }
        catch (Exception e) { toast("Open phone Settings → Network → VPN"); }
    }

    boolean proxySupported() { return WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE); }

    void setProxy(String hostPort, boolean quiet) {
        if (!proxySupported()) { if (!quiet) toast("This phone's WebView does not support proxy"); return; }
        try {
            ProxyConfig pc = new ProxyConfig.Builder().addProxyRule(hostPort).build();
            ProxyController.getInstance().setProxyOverride(pc, Runnable::run, () -> runOnUiThread(() -> {
                if (!quiet) {
                    toast("Proxy on ✓ " + hostPort);
                    WebView w = web();
                    if (w != null) w.reload();
                }
            }));
            prefs.edit().putString("proxy", hostPort).apply();
        } catch (Exception e) {
            if (!quiet) toast("Invalid proxy address (e.g. 1.2.3.4:8080)");
        }
    }

    void clearProxy() {
        prefs.edit().remove("proxy").apply();
        if (!proxySupported()) return;
        ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> runOnUiThread(() -> {
            toast("Proxy off");
            WebView w = web();
            if (w != null) w.reload();
        }));
    }

    // ── Reader mode ──
    void readerMode() {
        final Tab t = cur();
        if (t == null || !isRealUrl(t.web.getUrl())) { toast("Open an article page first"); return; }
        final String base = t.web.getUrl();
        t.web.evaluateJavascript(READER_JS, v -> {
            try {
                JSONObject o = new JSONObject(String.valueOf(new JSONTokener(v).nextValue()));
                JSONArray ps = o.optJSONArray("p");
                StringBuilder b = new StringBuilder();
                b.append("<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>")
                        .append("<title>📖 ").append(esc(o.optString("t"))).append("</title><style>")
                        .append(":root{--bg:#FBF6EC;--fg:#24211C;--mu:#8A7F6E;--ac:").append(Ui.hex(Ui.ORANGE)).append("}")
                        .append("body.dark{--bg:#14161C;--fg:#E7E3DA;--mu:#8E95A3}")
                        .append("body{margin:0;background:var(--bg);color:var(--fg);font:19px/1.75 Georgia,'Noto Serif',serif;transition:.3s}")
                        .append(".bar{position:sticky;top:0;display:flex;gap:8px;justify-content:flex-end;padding:10px 14px;background:var(--bg);border-bottom:1px solid rgba(128,128,128,.2)}")
                        .append(".bar button{border:0;border-radius:18px;padding:8px 14px;font:600 14px sans-serif;background:var(--ac);color:#fff}")
                        .append("main{max-width:720px;margin:0 auto;padding:18px 20px 60px}")
                        .append("h1{font:800 28px/1.3 sans-serif;margin:8px 0 6px}.src{font:13px sans-serif;color:var(--mu);margin-bottom:22px}")
                        .append("h2{font:700 22px/1.35 sans-serif;margin:28px 0 8px}p{margin:0 0 16px}img{max-width:100%;border-radius:12px;margin:10px 0}")
                        .append("blockquote{margin:16px 0;padding:6px 16px;border-left:4px solid var(--ac);color:var(--mu)}")
                        .append("</style></head><body><div class='bar'>")
                        .append("<button onclick=\"z(-1)\">A−</button><button onclick=\"z(1)\">A+</button>")
                        .append("<button onclick=\"document.body.classList.toggle('dark')\">🌙</button></div><main>")
                        .append("<h1>").append(esc(o.optString("t"))).append("</h1><div class='src'>📖 Baatora Reader • ")
                        .append(esc(Uri.parse(base).getHost())).append("</div>");
                for (int i = 0; ps != null && i < ps.length(); i++) {
                    JSONObject e = ps.optJSONObject(i);
                    if (e == null) continue;
                    String g = e.optString("g"), x = esc(e.optString("x"));
                    if (g.equals("IMG")) b.append("<img src=\"").append(x).append("\">");
                    else if (g.startsWith("H")) b.append("<h2>").append(x).append("</h2>");
                    else if (g.equals("BLOCKQUOTE")) b.append("<blockquote>").append(x).append("</blockquote>");
                    else if (g.equals("LI")) b.append("<p>• ").append(x).append("</p>");
                    else b.append("<p>").append(x).append("</p>");
                }
                b.append("</main><script>var s=19;function z(d){s=Math.max(14,Math.min(30,s+d*2));document.body.style.fontSize=s+'px'}</script></body></html>");
                Tab nt = createTab(null, t.incognito, true);
                nt.web.loadDataWithBaseURL(base, b.toString(), "text/html", "UTF-8", null);
            } catch (Exception e) {
                toast("Reader mode is not available for this page");
            }
        });
    }

    // ── Bolkar padhna ──
    void readAloud() {
        WebView w = web();
        if (w == null || !isRealUrl(w.getUrl())) { toast("Open a page first"); return; }
        if (ttsBusy()) { stopTts(); toast("⏹ Stop reading"); return; }
        w.evaluateJavascript("(function(){var a=document.querySelector('article')||document.querySelector('main')||document.body;" +
                "return (a.innerText||'').substring(0,20000);})()", v -> {
            String text;
            try { text = (String) new JSONTokener(v).nextValue(); } catch (Exception e) { text = null; }
            if (text == null || text.trim().isEmpty()) { toast("No readable text found"); return; }
            final String body = text;
            // Page ki bhasha dekh kar sahi awaaz: Devanagari zyada → Hindi, warna English
            int dev = 0, lat = 0;
            for (int k = 0; k < Math.min(body.length(), 3000); k++) {
                char ch = body.charAt(k);
                if (ch >= 0x0900 && ch <= 0x097F) dev++; else if ((ch | 32) >= 'a' && (ch | 32) <= 'z') lat++;
            }
            final String lk = dev > lat / 3 ? (L.key().equals("marathi") ? "marathi" : "hindi") : "english";
            toast("🔊 Reading aloud… (tap again to stop)");
            ensureTts(() -> { speakKey = lk; speak(body); });
        });
    }

    AiChat ai;
    Passwords pw;

    /** AI ka jawab bol kar sunao (TTS taiyaar na ho to pehle taiyaar karo). */
    String speakKey;

    void say(final String text) {
        ensureTts(() -> { speakKey = AiChat.ttsKey(); quietSpeak = true; speak(text); });
    }

    /** Chamakta Baatora AI button — kahin bhi khiskao, lamba dabao to chhupao. */
    View aiBtn;
    android.animation.ValueAnimator aiBtnAnim;

    /** Chhupa/band ho to chamak ka animation rok do — browser halka chale. */
    void aiGlow(boolean on) {
        try { if (aiBtnAnim == null) return; if (on) { if (aiBtnAnim.isPaused()) aiBtnAnim.resume(); } else aiBtnAnim.pause(); } catch (Exception ignored) {}
    }

    void addAiEdge() {
        try {
            final ViewGroup parent = (ViewGroup) mediaFab.getParent();
            final android.animation.ValueAnimator[] fa = new android.animation.ValueAnimator[1];
            final View b = ai.glowLogo(58, fa);
            aiBtnAnim = fa[0];
            b.setElevation(Ui.dp(12));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(58), Ui.dp(58), Gravity.TOP | Gravity.START);
            parent.addView(b, lp);
            aiBtn = b;
            b.setVisibility(prefs.getBoolean("aiBtn", true) ? View.VISIBLE : View.GONE);
            // Button ko screen par KAHIN bhi rakho — left, right, upar, neeche. Jagah yaad rahti hai.
            final Runnable place = () -> {
                float W = parent.getWidth(), H = parent.getHeight(), bw = Ui.dp(58);
                if (W <= 0 || H <= 0) return;
                float fx = prefs.getFloat("aiFX", -1f), fy = prefs.getFloat("aiFY", -1f);
                if (fx < 0) fx = 1f;                                   // pehli baar: right side
                if (fy < 0) fy = 0.62f;                                // thoda neeche
                int tuck = prefs.getInt("aiTuck", 0);
                b.setTranslationX(tuck == 1 ? -bw + Ui.dp(15) : tuck == 2 ? W - Ui.dp(15) : Math.max(0, Math.min(W - bw, fx * (W - bw))));
                b.setTranslationY(Math.max(0, Math.min(H - bw, fy * (H - bw))));
                b.setAlpha(tuck == 0 ? 1f : 0.85f);
                aiGlow(tuck == 0 && b.getVisibility() == View.VISIBLE);
            };
            parent.post(place);
            parent.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
                if (r - l != or - ol || bt - t != ob - ot) place.run();
            });
            // Side me chhupana: sirf chamakti kinari dikhe (left = 1, right = 2), tap karo to bahar aaye
            final java.util.function.IntConsumer tuckTo = side -> {
                prefs.edit().putInt("aiTuck", side).apply();
                if (side != 0) prefs.edit().putFloat("aiFX", side == 1 ? 0f : 1f).apply();
                float W = parent.getWidth(), bw = Ui.dp(58);
                float fx = prefs.getFloat("aiFX", 1f);
                b.animate().translationX(side == 1 ? -bw + Ui.dp(15) : side == 2 ? W - Ui.dp(15) : fx * (W - bw))
                        .alpha(side == 0 ? 1f : 0.85f).setInterpolator(new OvershootInterpolator(1.1f)).setDuration(280).start();
                aiGlow(side == 0);
            };
            final java.util.function.BiConsumer<Float, Float> moveTo = (fx, fy) -> {
                prefs.edit().putFloat("aiFX", fx).putFloat("aiFY", fy).putInt("aiTuck", 0).apply();
                b.animate().alpha(1f).setDuration(200).start();
                aiGlow(true);
                float W = parent.getWidth(), H = parent.getHeight(), bw = Ui.dp(58);
                b.animate().translationX(fx * (W - bw)).translationY(fy * (H - bw))
                        .setInterpolator(new OvershootInterpolator(1.1f)).setDuration(300).start();
            };
            final float[] st = new float[4];
            final boolean[] moved = {false}, longDone = {false};
            final Runnable longPress = () -> {
                if (moved[0]) return;
                longDone[0] = true;
                b.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                String[] opts = {"⬅ Move to left", "➡ Move to right", "⬆ Move to top", "⬇ Move to bottom", "🎯 Move to center",
                        "◀ Hide on left side", "▶ Hide on right side", "🙈 Hide button"};
                new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Baatora AI button")
                        .setItems(opts, (dl, w) -> {
                            float fx = prefs.getFloat("aiFX", 1f), fy = prefs.getFloat("aiFY", 0.62f);
                            switch (w) {
                                case 0: moveTo.accept(0f, fy); break;
                                case 1: moveTo.accept(1f, fy); break;
                                case 2: moveTo.accept(fx, 0.04f); break;
                                case 3: moveTo.accept(fx, 0.96f); break;
                                case 4: moveTo.accept(0.5f, 0.5f); break;
                                case 5: tuckTo.accept(1); break;
                                case 6: tuckTo.accept(2); break;
                                default: toggleAiButton();
                            }
                        })
                        .setNegativeButton("Cancel", null).show();
            };
            b.setOnTouchListener((v, e) -> {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        st[0] = e.getRawX(); st[1] = e.getRawY(); st[2] = v.getTranslationX(); st[3] = v.getTranslationY();
                        moved[0] = false; longDone[0] = false;
                        v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(110).start();
                        v.postDelayed(longPress, 600);
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - st[0], dy = e.getRawY() - st[1];
                        if (!moved[0] && Math.hypot(dx, dy) > Ui.dp(8)) { moved[0] = true; v.removeCallbacks(longPress); }
                        if (moved[0]) {
                            float W = parent.getWidth(), H = parent.getHeight(), bw = v.getWidth();
                            v.setTranslationX(Math.max(-bw * 0.6f, Math.min(W - bw * 0.4f, st[2] + dx)));
                            v.setTranslationY(Math.max(0, Math.min(H - bw, st[3] + dy)));
                        }
                        return true;
                    }
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL: {
                        v.removeCallbacks(longPress);
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                        if (longDone[0]) return true;
                        if (moved[0]) {
                            float W = parent.getWidth(), H = parent.getHeight(), bw = v.getWidth();
                            float fy = H - bw > 0 ? v.getTranslationY() / (H - bw) : 0.5f;
                            prefs.edit().putFloat("aiFY", fy).apply();
                            float rawX = st[2] + (e.getRawX() - st[0]);
                            if (rawX < -bw * 0.3f) tuckTo.accept(1);                // kinare se bahar kheencha → side me chhupao
                            else if (rawX > W - bw * 0.7f) tuckTo.accept(2);
                            else {
                                float fx = W - bw > 0 ? v.getTranslationX() / (W - bw) : 1f;
                                prefs.edit().putFloat("aiFX", fx).putInt("aiTuck", 0).apply();   // jahan chhoda wahi rahega
                                v.setAlpha(1f);
                                aiGlow(true);
                            }
                        } else if (e.getActionMasked() == android.view.MotionEvent.ACTION_UP) {
                            if (prefs.getInt("aiTuck", 0) != 0) tuckTo.accept(0); else ai.open();   // chhupa ho to pehle bahar aaye
                        }
                        return true;
                    }
                }
                return false;
            });
        } catch (Exception ignored) {}
    }

    void toggleAiButton() {
        boolean on = !prefs.getBoolean("aiBtn", true);
        prefs.edit().putBoolean("aiBtn", on).apply();
        if (aiBtn != null) aiBtn.setVisibility(on ? View.VISIBLE : View.GONE);
        aiGlow(on);
        toast(on ? "✨ Baatora AI button is visible" : "AI button hidden — bring it back from Settings → Baatora AI");
    }

    // ── Bolne wala engine (TTS): ek hi jagah se, taaki atke nahi aur awaaz pakka aaye ──
    volatile boolean ttsReady;
    final java.util.concurrent.atomic.AtomicInteger ttsPending = new java.util.concurrent.atomic.AtomicInteger();
    final ArrayList<Runnable> ttsWaiting = new ArrayList<>();
    String ttsApplied = "";
    boolean quietSpeak;

    void ensureTts() { ensureTts(null); }

    /** TTS taiyaar karo; taiyaar hote hi `then` chalao. */
    void ensureTts(Runnable then) {
        if (tts != null && ttsReady) { if (then != null) then.run(); return; }
        if (then != null) ttsWaiting.add(then);
        if (tts != null) return; // ban raha hai
        try {
            tts = new TextToSpeech(this, status -> runOnUiThread(() -> {
                if (status != TextToSpeech.SUCCESS) {
                    ttsWaiting.clear();
                    try { tts.shutdown(); } catch (Exception ignored) {}
                    tts = null;
                    toast("Text-to-speech is not working on this phone");
                    return;
                }
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { if (ttsPending.decrementAndGet() < 0) ttsPending.set(0); }
                    @Override public void onError(String id) { if (ttsPending.decrementAndGet() < 0) ttsPending.set(0); }
                    @Override public void onStop(String id, boolean interrupted) { if (ttsPending.decrementAndGet() < 0) ttsPending.set(0); }
                });
                ArrayList<Runnable> w = new ArrayList<>(ttsWaiting);
                ttsWaiting.clear();
                for (Runnable r : w) { try { r.run(); } catch (Exception ignored) {} }
            }));
        } catch (Exception e) { tts = null; }
    }

    /** Kya abhi speaking? (bina phone ko baar-baar poochhe — atakta nahi) */
    boolean ttsBusy() { return ttsPending.get() > 0; }

    void stopTts() {
        ttsPending.set(0);
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    void setTtsLang() { setTtsLang(L.key()); }

    void setTtsLang(String key) {
        if (tts == null || !ttsReady) return;
        String want = key + "|" + voiceId();
        if (want.equals(ttsApplied)) return;   // pehle se laga hai — dobara nahi (yahi atakta tha)
        ttsApplied = want;
        Locale loc;
        switch (key) {
            case "english": loc = new Locale("en", "IN"); break;
            case "marathi": loc = new Locale("mr", "IN"); break;
            case "bengali": loc = new Locale("bn", "IN"); break;
            case "punjabi": loc = new Locale("pa", "IN"); break;
            default: loc = new Locale("hi", "IN");
        }
        try { if (tts.setLanguage(loc) < 0) tts.setLanguage(new Locale("hi", "IN")); } catch (Exception ignored) {}
        applyVoice(loc);
    }

    // 6 Indian awaazein: 3 Male + 3 Female  {id, naam, pitch, speed}
    static final String[][] VOICES = {
            {"m1", "Arjun", "0.88", "1.0"}, {"m2", "Vikram", "0.72", "0.95"}, {"m3", "Rohan", "0.98", "1.07"},
            {"f1", "Priya", "1.08", "1.0"}, {"f2", "Neha", "1.22", "1.03"}, {"f3", "Kavya", "0.97", "0.95"}};

    String voiceId() {
        String id = prefs.getString("aiVoiceId", null);
        if (id == null) id = "male".equals(prefs.getString("aiVoice", "female")) ? "m1" : "f1";
        return id;
    }

    String[] voicePreset() {
        String id = voiceId();
        for (String[] v : VOICES) if (v[0].equals(id)) return v;
        return VOICES[3];
    }

    boolean voiceMale() { return voiceId().startsWith("m"); }

    void setVoiceId(String id) {
        prefs.edit().putString("aiVoiceId", id).putString("aiVoice", id.startsWith("m") ? "male" : "female").apply();
        ttsApplied = "";
        setTtsLang();
        String[] p = voicePreset();
        toast((id.startsWith("m") ? "👨 " : "👩 ") + p[1] + " voice selected");
    }

    void setVoiceMale(boolean m) {
        if (m == voiceMale()) return;
        setVoiceId(m ? "m1" : "f1");
    }

    /** Phone me aur Hindi/Indian awaazein download karne ka page. */
    void installVoices() {
        try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); }
        catch (Exception e) {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); } catch (Exception e2) { toast("Could not open voice settings"); }
        }
    }

    /** Male/Female awaaz: phone ki TTS awaazon me se sahi chuno, saath me halka pitch. */
    void applyVoice(Locale loc) {
        if (tts == null) return;
        boolean male = voiceMale();
        String[] preset = voicePreset();
        int slot = preset[0].charAt(1) - '1';           // 0,1,2 — har naam ke liye alag phone-awaaz
        java.util.ArrayList<android.speech.tts.Voice> sameG = new java.util.ArrayList<>();
        try {
            java.util.Set<android.speech.tts.Voice> all = tts.getVoices();
            android.speech.tts.Voice best = null;
            int bestScore = -1;
            // bhasha ek hi baar nikalo (pehle har awaaz ke liye phone se poochh rahe the — isi se app atak kar band hoti thi)
            android.speech.tts.Voice curV = null;
            try { curV = tts.getVoice(); } catch (Exception ignored) {}
            String wantLang = curV != null && curV.getLocale() != null ? curV.getLocale().getLanguage() : loc.getLanguage();
            if (all != null) for (android.speech.tts.Voice v : all) {
                Locale vl = v.getLocale();
                if (vl == null || !vl.getLanguage().equals(wantLang)) continue;
                java.util.Set<String> ft = v.getFeatures();
                if (ft != null && ft.contains("notInstalled")) continue;   // download nahi hui awaaz = chup
                String n = v.getName().toLowerCase(Locale.ROOT);
                if (n.contains("legacy")) continue;
                Boolean isMale = null;
                if (n.contains("female")) isMale = false;
                else if (n.contains("male")) isMale = true;
                else {
                    // Google ki awaazein: ...-x-hia / hic = female, hid / hie = male
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("-x-[a-z]{2}([a-z])").matcher(n);
                    if (m.find()) {
                        char ch = m.group(1).charAt(0);
                        if (ch == 'd' || ch == 'e' || ch == 'g' || ch == 'j') isMale = true;
                        else if (ch == 'a' || ch == 'b' || ch == 'c' || ch == 'f') isMale = false;
                    }
                }
                int sc = 0;
                if (isMale != null && isMale == male) { sc += 10; if ("IN".equalsIgnoreCase(vl.getCountry())) sameG.add(v); }
                if ("IN".equalsIgnoreCase(vl.getCountry())) sc += 3;
                if (!v.isNetworkConnectionRequired()) sc += 4;
                if (sc > bestScore) { bestScore = sc; best = v; }
            }
            if (!sameG.isEmpty()) {
                java.util.Collections.sort(sameG, (x, y) -> {
                    int nx = x.isNetworkConnectionRequired() ? 1 : 0, ny = y.isNetworkConnectionRequired() ? 1 : 0;
                    if (nx != ny) return nx - ny;   // offline awaaz pehle (tez)
                    return x.getName().compareTo(y.getName());
                });
                best = sameG.get(slot % sameG.size());
                bestScore = 10;
            }
            if (best != null && bestScore >= 10) tts.setVoice(best);
        } catch (Exception ignored) {}
        try { tts.setPitch(Float.parseFloat(preset[2])); tts.setSpeechRate(Float.parseFloat(preset[3])); } catch (Exception ignored) {}
    }

    void voiceSample() {
        String[] p = voicePreset();
        String t = "english".equals(AiChat.ttsKey())
                ? "Hello, I am " + p[1] + ", your Baatora assistant."
                : "नमस्ते, मैं " + p[1] + " हूँ, आपका बातोरा असिस्टेंट। अब मैं इसी आवाज़ में " + (voiceMale() ? "बोलूँगा।" : "बोलूँगी।");
        ensureTts(() -> { ttsApplied = ""; setTtsLang(AiChat.ttsKey()); stopTts(); say(t); });
    }

    int sayN = 0;
    /** Ek tukda line me jodo (pichhla bolna nahi rokta) — voice assistant ke liye. */
    void sayAdd(final String chunk) {
        if (chunk == null || chunk.trim().isEmpty()) return;
        final String c = chunk.replace("•", "").replace("*", "").trim();
        if (c.isEmpty()) return;
        ttsPending.incrementAndGet();   // turant "speaking" maan lo, taaki mic beech me na sune
        ensureTts(() -> {
            try {
                setTtsLang(AiChat.ttsKey());
                if (tts.speak(c, TextToSpeech.QUEUE_ADD, null, "ai" + (sayN++)) != TextToSpeech.SUCCESS) ttsPending.decrementAndGet();
            } catch (Exception e) { ttsPending.decrementAndGet(); }
        });
    }

    void speak(String text) {
        if (tts == null || !ttsReady) { final String t = text; ensureTts(() -> speak(t)); return; }
        String sk = speakKey != null ? speakKey : L.key();
        speakKey = null;
        boolean quiet = quietSpeak;
        quietSpeak = false;
        try {
            setTtsLang(sk);
            stopTts();
            int max = Math.min(3800, TextToSpeech.getMaxSpeechInputLength() - 10);
            for (int i = 0; i < text.length(); i += max) {
                ttsPending.incrementAndGet();
                if (tts.speak(text.substring(i, Math.min(text.length(), i + max)), TextToSpeech.QUEUE_ADD, null, "bt" + i) != TextToSpeech.SUCCESS)
                    ttsPending.decrementAndGet();
            }
        } catch (Exception e) { ttsPending.set(0); }
        if (!quiet) toast("🔊 Reading aloud… tap again to stop");
    }

    // ── Anuvad ──
    void translatePage() {
        WebView w = web();
        String u = w == null ? null : w.getUrl();
        if (!isRealUrl(u)) { toast("Open a website first"); return; }
        String tl;
        switch (L.key()) {
            case "english": tl = "en"; break;
            case "marathi": tl = "mr"; break;
            case "bengali": tl = "bn"; break;
            case "punjabi": tl = "pa"; break;
            case "bhojpuri": tl = "bho"; break;
            default: tl = "hi";
        }
        try { w.loadUrl("https://translate.google.com/translate?sl=auto&tl=" + tl + "&u=" + URLEncoder.encode(u, "UTF-8")); }
        catch (Exception ignored) {}
    }

    // ── Screenshot ──
    void screenshot() {
        WebView w = web();
        if (w == null || w.getWidth() == 0) return;
        try {
            Bitmap b = Bitmap.createBitmap(w.getWidth(), w.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.translate(-w.getScrollX(), -w.getScrollY());
            w.draw(c);
            String name = "Baatora_" + System.currentTimeMillis() + ".png";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Baatora");
                Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("no uri");
                try (OutputStream os = getContentResolver().openOutputStream(u)) {
                    if (os == null) throw new Exception("no stream");
                    b.compress(Bitmap.CompressFormat.PNG, 100, os);
                }
            } else {
                if (!granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                    toast("Grant permission, then try again");
                    return;
                }
                MediaStore.Images.Media.insertImage(getContentResolver(), b, name, "Baatora");
            }
            toast("📸 Screenshot saved to Gallery");
            addNotif("shot", "Screenshot saved 📸", "Gallery → Pictures → Baatora");
        } catch (Exception e) {
            toast("Could not take screenshot");
        }
    }

    // ── Home screen shortcut ──
    void addToHome() {
        final WebView w = web();
        final String u = w == null ? null : w.getUrl();
        if (!isRealUrl(u) || !u.startsWith("http")) { toast("Open a website first"); return; }
        if (Build.VERSION.SDK_INT < 26) { toast("This feature needs Android 8 or above"); return; }
        toast("📲 Creating app…");
        final Bitmap pageFav = w.getFavicon();
        final String pageTitle = w.getTitle();
        String js = "(function(){function m(n){var e=document.querySelector('meta[name=\"'+n+'\"],meta[property=\"'+n+'\"]');return e&&e.content?e.content:'';}"
                + "var b='',bs=-1,l=document.querySelectorAll('link[rel~=icon],link[rel~=apple-touch-icon],link[rel~=apple-touch-icon-precomposed]');"
                + "for(var i=0;i<l.length;i++){var h=l[i].href;if(!h||/\\.svg(\\?|$)/i.test(h))continue;var s=0,z=(l[i].getAttribute('sizes')||'').match(/(\\d+)/);"
                + "if(z)s=+z[1];else if(/apple/.test(l[i].rel))s=180;else s=32;if(s>bs){bs=s;b=h;}}"
                + "var mf=document.querySelector('link[rel=manifest]');"
                + "return JSON.stringify({n:m('application-name')||m('apple-mobile-web-app-title')||m('og:site_name')||document.title||'',"
                + "c:m('theme-color'),i:b,mf:mf?mf.href:''});})()";
        w.evaluateJavascript(js, r -> {
            JSONObject info;
            try { info = new JSONObject((String) new JSONTokener(r).nextValue()); } catch (Exception e) { info = new JSONObject(); }
            final JSONObject fi = info;
            new Thread(() -> buildWebApp(u, fi, pageFav, pageTitle)).start();
        });
    }

    /** Website ki manifest / logo padh kar asli app jaisa naam, rang aur icon banao (background me). */
    void buildWebApp(String u, JSONObject info, Bitmap pageFav, String pageTitle) {
        String host = Uri.parse(u).getHost();
        String name = info.optString("n", "");
        String start = u;
        int color = parseCol(info.optString("c", ""), Color.WHITE);
        Bitmap icon = null;
        boolean maskable = false;
        String mfUrl = info.optString("mf", "");
        if (mfUrl.startsWith("http")) {
            try {
                java.net.HttpURLConnection con = (java.net.HttpURLConnection) new java.net.URL(mfUrl).openConnection();
                con.setConnectTimeout(5000); con.setReadTimeout(6000);
                String ck = CookieManager.getInstance().getCookie(mfUrl);
                if (ck != null) con.setRequestProperty("Cookie", ck);
                java.io.InputStream in = con.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                JSONObject mf = new JSONObject(bo.toString("UTF-8"));
                String sn = mf.optString("short_name", mf.optString("name", ""));
                if (!sn.isEmpty()) name = sn;
                String su = mf.optString("start_url", "");
                if (!su.isEmpty()) try { start = new java.net.URL(new java.net.URL(mfUrl), su).toString(); } catch (Exception ignored) {}
                color = parseCol(mf.optString("theme_color", ""), color);
                JSONArray ics = mf.optJSONArray("icons");
                String best = null; int bestSz = -1; boolean bestMask = false;
                if (ics != null) for (int k = 0; k < ics.length(); k++) {
                    JSONObject ic = ics.optJSONObject(k);
                    if (ic == null) continue;
                    String src = ic.optString("src", "");
                    if (src.isEmpty() || src.toLowerCase().contains(".svg")) continue;
                    java.util.regex.Matcher mm = java.util.regex.Pattern.compile("(\\d+)").matcher(ic.optString("sizes", ""));
                    int sz = mm.find() ? Integer.parseInt(mm.group(1)) : 48;
                    boolean msk = ic.optString("purpose", "").contains("maskable");
                    int score = sz + (msk ? 1000 : 0);
                    if (sz >= 96 && score > bestSz) { bestSz = score; best = src; bestMask = msk; }
                    else if (best == null && sz > bestSz) { bestSz = sz; best = src; bestMask = msk; }
                }
                if (best != null) {
                    String abs = new java.net.URL(new java.net.URL(mfUrl), best).toString();
                    Bitmap b = Ui.download(abs);
                    if (b != null && b.getWidth() >= 48) { icon = b; maskable = bestMask; }
                }
            } catch (Exception ignored) {}
        }
        if (icon == null) {
            String iu = info.optString("i", "");
            if (iu.startsWith("http")) { Bitmap b = Ui.download(iu); if (b != null && b.getWidth() >= 48) icon = b; }
        }
        if (icon == null) { Bitmap b = Ui.CACHE.get(Ui.key(host)); if (b != null && b.getWidth() >= 48) icon = b; }
        if (icon == null) { Bitmap b = Ui.download("https://www.google.com/s2/favicons?sz=256&domain=" + host); if (b != null && b.getWidth() > 16) icon = b; }
        if (icon == null) icon = pageFav;
        if (icon != null) Ui.putIcon(host, icon);
        if (name.trim().isEmpty()) name = pageTitle != null && !pageTitle.trim().isEmpty() ? pageTitle : host;
        name = name.trim();
        if (name.length() > 30) name = name.substring(0, 30);
        final Bitmap adaptive = adaptiveIcon(icon, maskable, host);
        final String fName = name, fStart = start; final int fColor = color;
        runOnUiThread(() -> confirmWebApp(fName, fStart, fColor, adaptive, host));
    }

    static int parseCol(String c, int def) {
        try {
            c = c.trim();
            if (c.matches("#[0-9a-fA-F]{3}")) c = "#" + c.charAt(1) + c.charAt(1) + c.charAt(2) + c.charAt(2) + c.charAt(3) + c.charAt(3);
            return c.isEmpty() ? def : Color.parseColor(c);
        } catch (Exception e) { return def; }
    }

    /** Android ka adaptive icon: website ka logo poore icon me, launcher ke shape (gol / chaukor) me fit. */
    Bitmap adaptiveIcon(Bitmap logo, boolean maskable, String host) {
        int S = 432;
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
        if (logo == null) {
            int[][] pal = {{0xFF1E5BFF, 0xFF00B0FF}, {0xFFFF4081, 0xFF7C4DFF}, {0xFF00BFA5, 0xFF00796B}, {0xFFFF8A00, 0xFFE65100}};
            int[] cc = pal[Math.abs(String.valueOf(host).hashCode()) % pal.length];
            p.setShader(new android.graphics.LinearGradient(0, 0, S, S, cc[0], cc[1], android.graphics.Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, S, S, p);
            p.setShader(null);
            p.setColor(Color.WHITE);
            p.setTextSize(S * 0.34f);
            p.setFakeBoldText(true);
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            String h = host == null ? "?" : host.replaceFirst("^www\\.", "");
            cv.drawText(h.substring(0, 1).toUpperCase(), S / 2f, S / 2f + S * 0.12f, p);
            return out;
        }
        if (maskable) {
            cv.drawBitmap(logo, null, new android.graphics.RectF(0, 0, S, S), p);
            return out;
        }
        // Logo ke kinare ka rang hi background (logo "bada" aur asli app jaisa lage)
        int bg = Color.WHITE;
        try {
            int px = logo.getPixel(1, 1);
            if (Color.alpha(px) > 200) bg = px | 0xFF000000;
        } catch (Exception ignored) {}
        cv.drawColor(bg);
        float inner = S * 0.62f;           // safe zone ke andar
        float off = (S - inner) / 2f;
        cv.drawBitmap(logo, null, new android.graphics.RectF(off, off, off + inner, off + inner), p);
        return out;
    }

    void confirmWebApp(String name, String start, int color, Bitmap icon, String host) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(22), Ui.dp(18), Ui.dp(22), Ui.dp(6));
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(icon);
        iv.setBackground(Ui.round(Color.WHITE, 22));
        iv.setClipToOutline(true);
        box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(84), Ui.dp(84)));
        final EditText et = new EditText(this);
        et.setText(name);
        et.setSingleLine(true);
        et.setSelectAllOnFocus(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(12);
        box.addView(et, lp);
        TextView hs = new TextView(this);
        hs.setText(host);
        hs.setTextColor(0xFF777777);
        box.addView(hs);
        new AlertDialog.Builder(this)
                .setTitle("Install app")
                .setView(box)
                .setPositiveButton("Install", (d, wch) -> pinWebApp(et.getText().toString().trim(), start, color, icon, host))
                .setNegativeButton("Cancel", null)
                .show();
    }

    void pinWebApp(String name, String start, int color, Bitmap icon, String host) {
        if (Build.VERSION.SDK_INT < 26) return;
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) { toast("Your launcher does not support shortcuts"); return; }
        if (name.isEmpty()) name = host;
        Intent i = new Intent(this, WebAppActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(start))
                .putExtra(WebAppActivity.EXTRA_NAME, name).putExtra(WebAppActivity.EXTRA_COLOR, color);
        Icon ic = icon != null ? Icon.createWithAdaptiveBitmap(icon) : Icon.createWithResource(this, R.mipmap.ic_launcher);
        ShortcutInfo si = new ShortcutInfo.Builder(this, "app_" + Ui.key(host))
                .setShortLabel(name.length() > 12 ? name.substring(0, 12) : name)
                .setLongLabel(name).setIcon(ic).setIntent(i).build();
        try {
            // Pehle se bana ho to naya icon/naam update karo
            sm.updateShortcuts(java.util.Collections.singletonList(si));
        } catch (Exception ignored) {}
        sm.requestPinShortcut(si, null);
        toast("✓ " + name + " added to Home screen");
    }

    // ── Page source ──
    void pageSource() {
        final Tab t = cur();
        if (t == null || !isRealUrl(t.web.getUrl())) { toast("Open a website first"); return; }
        t.web.evaluateJavascript("document.documentElement.outerHTML", v -> {
            String src;
            try { src = (String) new JSONTokener(v).nextValue(); } catch (Exception e) { src = ""; }
            String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Source: "
                    + esc(t.web.getTitle()) + "</title><style>body{margin:0;background:#0D1117;color:#C9D1D9;font:12px/1.5 monospace}" +
                    "pre{white-space:pre-wrap;word-break:break-all;padding:14px;margin:0}</style></head><body><pre>"
                    + esc(src) + "</pre></body></html>";
            Tab nt = createTab(null, t.incognito, true);
            nt.web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        });
    }

    // ── Site ki cookies hatana ──
    void clearSiteCookies(String url) {
        CookieManager cm = CookieManager.getInstance();
        String c = cm.getCookie(url);
        String host = Uri.parse(url).getHost();
        if (c != null && host != null) {
            for (String part : c.split(";")) {
                String name = part.split("=")[0].trim();
                if (name.isEmpty()) continue;
                cm.setCookie(url, name + "=; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
                cm.setCookie(url, name + "=; Domain=" + host + "; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
                cm.setCookie(url, name + "=; Domain=." + host.replaceFirst("^www\\.", "") + "; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
            }
            cm.flush();
        }
        toast("🍪 " + host + " cookies removed");
    }

    // ═════════════ SEARCH SUGGESTIONS + COPY KIYA LINK ═════════════

    android.widget.PopupWindow suggestPop;
    LinearLayout suggestBox;
    String suggestQuery = "";

    void setupSuggestions() {
        suggestBox = new LinearLayout(this);
        suggestBox.setOrientation(LinearLayout.VERTICAL);
        suggestBox.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        suggestPop = new android.widget.PopupWindow(suggestBox, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false);
        suggestPop.setInputMethodMode(android.widget.PopupWindow.INPUT_METHOD_NEEDED);
        suggestPop.setOutsideTouchable(true);
        suggestPop.setElevation(Ui.dp(12));
        urlBar.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { if (urlBar.hasFocus()) requestSuggestions(s.toString().trim()); }
        });
    }

    void requestSuggestions(final String q) {
        suggestQuery = q;
        if (!prefs.getBoolean("suggest", true)) { hideSuggestions(); return; }
        final ArrayList<String[]> items = new ArrayList<>();
        if (q.isEmpty()) {
            showSuggestions(items);
            return;
        }
        // History se
        JSONArray h = load("history");
        String lq = q.toLowerCase();
        for (int i = 0; i < h.length() && items.size() < 3; i++) {
            JSONObject o = h.optJSONObject(i);
            if (o == null) continue;
            String t = o.optString("t"), u = o.optString("u");
            if (on("personal", true) && (t + " " + u).toLowerCase().contains(lq)) items.add(new String[]{"hist", t, u});
        }
        showSuggestions(items);
        Tab ct = cur();
        if (ct != null && ct.incognito) return;
        Ui.POOL.execute(() -> {
            final ArrayList<String[]> remote = new ArrayList<>();
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                        "https://suggestqueries.google.com/complete/search?client=firefox&hl=" + (L.key().equals("english") ? "en" : "hi")
                                + "&q=" + URLEncoder.encode(q, "UTF-8")).openConnection();
                c.setConnectTimeout(3000);
                c.setReadTimeout(3000);
                java.io.InputStream in = c.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                JSONArray arr = new JSONArray(bo.toString("UTF-8")).optJSONArray(1);
                for (int i = 0; arr != null && i < arr.length() && remote.size() < 6; i++) {
                    String sgs = arr.optString(i);
                    if (!sgs.isEmpty()) remote.add(new String[]{"search", sgs, null});
                }
            } catch (Exception ignored) {}
            runOnUiThread(() -> {
                if (!q.equals(suggestQuery) || !urlBar.hasFocus()) return;
                ArrayList<String[]> all = new ArrayList<>(items);
                all.addAll(remote);
                showSuggestions(all);
            });
        });
    }

    String clipboardUrl() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) return null;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).getText();
            if (t == null) return null;
            String s = t.toString().trim();
            return (s.startsWith("http://") || s.startsWith("https://")) && !s.contains(" ") ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    void showSuggestions(ArrayList<String[]> items) {
        if (items.isEmpty() || !urlBar.hasFocus()) { hideSuggestions(); return; }
        suggestBox.removeAllViews();
        GradientDrawable bg = Ui.round(Ui.LIGHT ? 0xFFFFFFFF : Ui.PAGE1, 20);
        bg.setStroke(Ui.dp(1), Ui.gl(0x26));
        suggestBox.setBackground(bg);
        for (final String[] it : items) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(14), Ui.dp(11), Ui.dp(8), Ui.dp(11));
            int icon = it[0].equals("hist") ? R.drawable.ic_history : it[0].equals("clip") ? R.drawable.ic_copy : R.drawable.ic_search;
            ImageView iv = Ui.icon(this, icon, it[0].equals("clip") ? Ui.ORANGE : Ui.MUTED);
            r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(20), Ui.dp(20)));
            LinearLayout colv = new LinearLayout(this);
            colv.setOrientation(LinearLayout.VERTICAL);
            colv.setPadding(Ui.dp(14), 0, Ui.dp(6), 0);
            TextView t = Ui.text(this, it[1], 15, Color.WHITE, it[0].equals("clip"));
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            colv.addView(t);
            if (it[2] != null) {
                TextView u = Ui.text(this, it[2], 12, Ui.MUTED, false);
                u.setSingleLine(true);
                u.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                colv.addView(u);
            }
            r.addView(colv, new LinearLayout.LayoutParams(0, -2, 1f));
            if (it[0].equals("search")) {
                ImageView fill = Ui.icon(this, R.drawable.ic_up, Ui.MUTED);
                fill.setRotation(-45);
                fill.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
                fill.setOnClickListener(v -> { urlBar.setText(it[1] + " "); urlBar.setSelection(urlBar.getText().length()); });
                r.addView(fill, new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38)));
            }
            r.setOnClickListener(v -> {
                hideSuggestions();
                navigate(it[2] != null ? it[2] : it[1]);
                hideKeyboard();
                urlBar.clearFocus();
            });
            Ui.ripple(r, false);
            suggestBox.addView(r);
        }
        View anchor = findViewById(R.id.addressBox);
        suggestPop.setWidth(anchor.getWidth());
        if (!suggestPop.isShowing()) suggestPop.showAsDropDown(anchor, 0, Ui.dp(6));
        else suggestPop.update(anchor, anchor.getWidth(), ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    void hideSuggestions() {
        if (suggestPop != null && suggestPop.isShowing()) suggestPop.dismiss();
    }

    // ───────────────────────── RESULTS / PERMISSIONS ─────────────────────────

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_AIVOICE) {
            if (res == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) ai.onVoice(r.get(0));
            }
            return;
        }
        if (req == Passwords.REQ_UNLOCK) { pw.onUnlock(res == RESULT_OK); return; }
        if (req == REQ_TONE) {
            if (res == RESULT_OK && data != null) {
                Uri tu = data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (tu != null) { prefs.edit().putString("dlTone", tu.toString()).apply(); Screens.playTone(this, tu.toString()); toast("🎵 Tone set"); }
            }
            return;
        }
        if (req == REQ_VPN) {
            if (res == RESULT_OK) startMyVpn(); else toast("VPN permission was not granted");
            return;
        }
        if (req == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    results = new Uri[cd.getItemCount()];
                    for (int i = 0; i < cd.getItemCount(); i++) results[i] = cd.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (req == REQ_VOICE && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) navigate(r.get(0));
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        boolean all = results.length > 0, any = false;
        for (int r : results) { if (r == PackageManager.PERMISSION_GRANTED) any = true; else all = false; }
        if (req == REQ_MIC) {
            if (all) ai.voice(); else ai.listenIntent();
            return;
        }
        if (req == REQ_WEB_PERM && pendingPermission != null) {
            if (all) pendingPermission.grant(pendingPermission.getResources());
            else pendingPermission.deny();
            pendingPermission = null;
        } else if (req == REQ_GEO && geoCallback != null) {
            geoCallback.invoke(geoOrigin, any, false);
            geoCallback = null;
        }
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    // ───────────────────────── HELPERS ─────────────────────────

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void copy(String s) {
        if (s == null) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("link", s));
        toast("Copied 📋");
    }

    void share(String s) {
        if (!isRealUrl(s)) { toast("Open a page to share"); return; }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, s);
        startActivity(Intent.createChooser(i, "Share"));
    }

    static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    String errorPage(String url, String desc) {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<title>Baatora Error</title><style>" +
                "body{margin:0;font-family:sans-serif;background:linear-gradient(160deg,#06103A,#1E5BFF);color:#fff;" +
                "display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;" +
                "text-align:center;padding:24px;box-sizing:border-box}" +
                "h1{font-size:64px;margin:0}h2{margin:12px 0 6px}p{opacity:.85;font-size:14px;word-break:break-all;margin:6px 0}" +
                "a{display:inline-block;margin-top:22px;padding:14px 34px;border-radius:30px;" +
                "background:linear-gradient(90deg,#FF8A00,#FFC107);color:#06103A;font-weight:bold;text-decoration:none}" +
                "</style></head><body><h1>📡</h1><h2>Page could not load</h2>" +
                "<p>Check your internet connection and try again.</p>" +
                "<p style='opacity:.6'>" + esc(desc) + "</p>" +
                "<a href=\"" + esc(url) + "\">Try again</a>" +
                "<p style='margin-top:34px;color:#FFC107;opacity:1'>Made in India 🇮🇳</p></body></html>";
    }
}
