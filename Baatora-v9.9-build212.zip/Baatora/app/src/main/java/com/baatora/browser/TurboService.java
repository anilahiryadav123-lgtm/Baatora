package com.baatora.browser;

import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.media.MediaScannerConnection;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.webkit.MimeTypeMap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.ArrayList;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ⚡ Turbo Download — ek file ko 4-6 hisson me ek saath download karta hai
 * (jab server ijazat de), isliye aksar normal se tez hota hai.
 */
public class TurboService extends Service {

    static final int RUNNING = 0, DONE = 1, FAILED = 2, CANCELLED = 3;
    static final String CH = "bt_downloads";

    static class Job {
        long id, time;
        String url, ua, cookie, referer, mime, name, uri;
        volatile long total = -1, done, speed, lastDone;
        volatile int status = RUNNING, parts = 1;
        volatile boolean cancel, abort;
    }

    static final ConcurrentHashMap<Long, Job> JOBS = new ConcurrentHashMap<>();
    static final AtomicLong IDS = new AtomicLong(System.currentTimeMillis());

    static long start(Context c, String url, String ua, String cookie, String referer, String mime, String name) {
        Job j = new Job();
        j.id = IDS.incrementAndGet();
        j.url = url; j.ua = ua; j.cookie = cookie; j.referer = referer; j.mime = mime; j.name = name;
        j.time = System.currentTimeMillis();
        JOBS.put(j.id, j);
        Intent i = new Intent(c, TurboService.class).putExtra("id", j.id);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        return j.id;
    }

    static ArrayList<Job> running() {
        ArrayList<Job> out = new ArrayList<>();
        for (Job j : JOBS.values()) if (j.status == RUNNING) out.add(j);
        return out;
    }

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler main = new Handler(Looper.getMainLooper());
    private NotificationManager nm;
    private int active = 0;
    private boolean ticking;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Baatora Downloads", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification n = summary();
            if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(77, n);
        } catch (Throwable e) {
            // Foreground service na ban paye to bhi download chalne do, app band na ho
        }
        long id = intent == null ? -1 : intent.getLongExtra("id", -1);
        final Job j = JOBS.get(id);
        if (j != null) {
            active++;
            pool.execute(() -> work(j));
        } else if (active == 0) {
            stopSelf();
        }
        if (!ticking) { ticking = true; main.post(ticker); }
        return START_NOT_STICKY;
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            for (Job j : JOBS.values()) {
                if (j.status != RUNNING) continue;
                j.speed = j.done - j.lastDone;
                j.lastDone = j.done;
            }
            if (active > 0) {
                nm.notify(77, summary());
                main.postDelayed(this, 1000);
            } else {
                ticking = false;
            }
        }
    };

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class).setAction("baatora.DOWNLOADS")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification.Builder builder() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download).setContentIntent(openApp());
    }

    private Notification summary() {
        long total = 0, done = 0, speed = 0;
        int n = 0;
        boolean known = true;
        for (Job j : JOBS.values()) {
            if (j.status != RUNNING) continue;
            n++;
            done += j.done;
            speed += j.speed;
            if (j.total > 0) total += j.total; else known = false;
        }
        int pct = known && total > 0 ? (int) (done * 100 / total) : 0;
        String text = Formatter.formatFileSize(this, done) + (known && total > 0 ? " / " + Formatter.formatFileSize(this, total) : "")
                + "  •  " + Formatter.formatFileSize(this, speed) + "/s";
        return builder().setContentTitle("⚡ Turbo download (" + Math.max(n, 1) + ")")
                .setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
                .setProgress(100, pct, !known || total <= 0).build();
    }

    // ───────────── Download ka kaam ─────────────

    private void work(Job j) {
        File tmp = new File(getExternalFilesDir(null) != null ? getExternalFilesDir(null) : getCacheDir(), "bt_" + j.id + ".part");
        File fixed = new File(tmp.getParentFile(), "bt_" + j.id + ".mp4.part");
        try {
            boolean hls = MainActivity.isHls(j.url, j.mime);
            if (hls) downloadHls(j, tmp); else download(j, tmp);
            if (j.cancel) throw new IOException("cancel");
            // File sach me video/gaana hai? (kai sites video ki jagah web page / playlist de deti hain)
            String kind = sniff(tmp);
            if (!hls && kind.equals("m3u8")) {           // link asal me stream playlist tha
                tmp.delete(); j.done = 0; j.total = -1;
                downloadHls(j, tmp); hls = true; kind = sniff(tmp);
            }
            if (kind.equals("html")) throw new IOException("Website ne video ki jagah web page diya — video chala kar Download button se dobara try karo");
            // Har phone me chale: TS / fragmented stream ko normal MP4 me badlo
            if (kind.equals("ts") || (hls && kind.equals("mp4"))) {
                if (remux(tmp, fixed)) {
                    tmp.delete();
                    if (!fixed.renameTo(tmp)) throw new IOException("rename");
                    j.name = j.name.replaceAll("(?i)\\.(ts|m3u8|mp4|m4s)$", "") + ".mp4";
                    j.mime = "video/mp4";
                } else if (kind.equals("ts")) {
                    j.name = j.name.replaceAll("(?i)\\.(mp4|m3u8|ts)$", "") + ".ts";
                    j.mime = "video/mp2t";
                }
            } else if (kind.equals("webm") && !j.name.toLowerCase().matches(".*\\.(webm|mkv)$")) {
                j.name = j.name.replaceAll("(?i)\\.[a-z0-9]{2,4}$", "") + ".webm"; j.mime = "video/webm";
            } else if (kind.equals("mp4") && !j.name.toLowerCase().matches(".*\\.(mp4|m4v|m4a|mov|3gp)$")) {
                j.name = j.name.replaceAll("(?i)\\.(m3u8|ts|bin|php|html?)$", "") + ".mp4";
                if (j.mime == null || !j.mime.startsWith("video/")) j.mime = "video/mp4";
            } else if (kind.equals("mp3") && !j.name.toLowerCase().endsWith(".mp3")) {
                j.name = j.name.replaceAll("(?i)\\.[a-z0-9]{2,4}$", "") + ".mp3"; j.mime = "audio/mpeg";
            }
            publish(j, tmp);
            j.status = DONE;
            record(j);
            Store.addNotif(this, "dl", "Download complete ✅", j.name);
            finishedNotice(j, true);
        } catch (Throwable e) {
            j.status = j.cancel ? CANCELLED : FAILED;
            if (!j.cancel) {
                record(j);
                String why = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                Store.addNotif(this, "dlfail", "Download failed ❌", j.name + " — " + why);
                finishedNotice(j, false);
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            //noinspection ResultOfMethodCallIgnored
            fixed.delete();
            main.post(() -> {
                active--;
                if (active <= 0) {
                    active = 0;
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
                    stopSelf();
                }
            });
        }
    }

    private HttpURLConnection connect(Job j, String range) throws IOException {
        String[] fin = new String[1];
        HttpURLConnection c = openUrl(j, j.url, range, fin);
        j.url = fin[0];
        return c;
    }

    private HttpURLConnection openUrl(Job j, String start, String range, String[] fin) throws IOException {
        String url = start;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            if (j.ua != null) c.setRequestProperty("User-Agent", j.ua);
            if (j.cookie != null) c.setRequestProperty("Cookie", j.cookie);
            if (j.referer != null) c.setRequestProperty("Referer", j.referer);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (range != null) c.setRequestProperty("Range", range);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            fin[0] = url;
            return c;
        }
        throw new IOException("too many redirects");
    }

    private void download(Job j, File tmp) throws Exception {
        HttpURLConnection probe = connect(j, "bytes=0-0");
        int code = probe.getResponseCode();
        long total = -1;
        boolean ranges = false;
        if (code == 206) {
            String cr = probe.getHeaderField("Content-Range");
            if (cr != null && cr.contains("/")) {
                try { total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()); ranges = true; } catch (Exception ignored) {}
            }
        } else if (code == 200) {
            total = probe.getContentLengthLong();
        } else {
            probe.disconnect();
            throw new IOException("HTTP " + code);
        }
        if (j.mime == null) j.mime = probe.getContentType();
        probe.disconnect();
        j.total = total;

        if (ranges && total > 2 * 1024 * 1024) {
            int parts = total > 50L * 1024 * 1024 ? 6 : 4;
            j.parts = parts;
            try (RandomAccessFile pre = new RandomAccessFile(tmp, "rw")) { pre.setLength(total); }
            long chunk = total / parts;
            ArrayList<Future<?>> fs = new ArrayList<>();
            for (int p = 0; p < parts; p++) {
                final long s = p * chunk, e = (p == parts - 1) ? total - 1 : s + chunk - 1;
                fs.add(pool.submit(() -> { part(j, tmp, s, e); return null; }));
            }
            for (Future<?> f : fs) {
                try { f.get(); } catch (Exception ex) { j.abort = true; throw ex; }
            }
        } else {
            HttpURLConnection c = connect(j, null);
            if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
            if (j.total <= 0) j.total = c.getContentLengthLong();
            try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (j.cancel) throw new IOException("cancel");
                    out.write(buf, 0, n);
                    add(j, n);
                }
            }
        }
    }

    // ───────────── HLS (m3u8) stream ko ek asli video file me jodna ─────────────

    private static class Seg { String url, keyUri, iv; long seq; }

    private byte[] getBytes(Job j, String url, String[] fin) throws IOException {
        IOException last = null;
        for (int t = 0; t < 4; t++) {
            if (j.cancel || j.abort) throw new IOException("stop");
            try {
                HttpURLConnection c = openUrl(j, url, null, fin);
                int code = c.getResponseCode();
                if (code >= 400) throw new IOException("HTTP " + code);
                try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream(256 * 1024)) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (j.cancel || j.abort) throw new IOException("stop");
                        bo.write(buf, 0, n);
                    }
                    return bo.toByteArray();
                } finally { c.disconnect(); }
            } catch (IOException e) {
                last = e;
                try { Thread.sleep(800); } catch (InterruptedException ignored) {}
            }
        }
        throw last == null ? new IOException("fail") : last;
    }

    private static String attr(String line, String key) {
        int i = line.indexOf(key + "=");
        if (i < 0) return null;
        i += key.length() + 1;
        if (i < line.length() && line.charAt(i) == '"') {
            int e = line.indexOf('"', i + 1);
            return e < 0 ? line.substring(i + 1) : line.substring(i + 1, e);
        }
        int e = line.indexOf(',', i);
        return e < 0 ? line.substring(i) : line.substring(i, e);
    }

    private void downloadHls(Job j, File tmp) throws Exception {
        String[] fin = new String[1];
        String text = new String(getBytes(j, j.url, fin), "UTF-8");
        String base = fin[0];

        if (text.contains("#EXT-X-STREAM-INF")) {          // master playlist: sabse achhi quality chuno
            String[] lines = text.split("\\r?\\n");
            String best = null;
            long bw = -1;
            for (int i = 0; i < lines.length; i++) {
                String ln = lines[i].trim();
                if (!ln.startsWith("#EXT-X-STREAM-INF")) continue;
                long b = 0;
                try { b = Long.parseLong(attr(ln, "BANDWIDTH")); } catch (Exception ignored) {}
                for (int k = i + 1; k < lines.length; k++) {
                    String u = lines[k].trim();
                    if (u.isEmpty() || u.startsWith("#")) continue;
                    if (b >= bw) { bw = b; best = new URL(new URL(base), u).toString(); }
                    break;
                }
            }
            if (best == null) throw new IOException("no variant");
            text = new String(getBytes(j, best, fin), "UTF-8");
            base = fin[0];
        }

        ArrayList<Seg> segs = new ArrayList<>();
        String initUrl = null, keyUri = null, keyIv = null;
        long seq = 0;
        for (String raw : text.split("\\r?\\n")) {
            String ln = raw.trim();
            if (ln.isEmpty()) continue;
            if (ln.startsWith("#")) {
                if (ln.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                    try { seq = Long.parseLong(ln.substring(22).trim()); } catch (Exception ignored) {}
                } else if (ln.startsWith("#EXT-X-MAP")) {
                    String u = attr(ln, "URI");
                    if (u != null) initUrl = new URL(new URL(base), u).toString();
                    if (attr(ln, "BYTERANGE") != null) throw new IOException("byterange");
                } else if (ln.startsWith("#EXT-X-KEY")) {
                    String m = attr(ln, "METHOD");
                    if (m == null || m.equals("NONE")) { keyUri = null; keyIv = null; }
                    else if (m.equals("AES-128")) {
                        String u = attr(ln, "URI");
                        keyUri = u == null ? null : new URL(new URL(base), u).toString();
                        keyIv = attr(ln, "IV");
                    } else throw new IOException("drm " + m);
                } else if (ln.startsWith("#EXT-X-BYTERANGE")) {
                    throw new IOException("byterange");
                }
                continue;
            }
            Seg g = new Seg();
            g.url = new URL(new URL(base), ln).toString();
            g.keyUri = keyUri; g.iv = keyIv; g.seq = seq++;
            segs.add(g);
        }
        if (segs.isEmpty()) throw new IOException("no segments");

        boolean fmp4 = initUrl != null || segs.get(0).url.toLowerCase().matches(".*\\.(m4s|mp4|m4v)(\\?.*)?$");
        String nm = j.name == null || j.name.isEmpty() ? "Baatora_video" : j.name;
        nm = nm.replaceAll("(?i)\\.(m3u8|mp4|ts|m4s)$", "");
        j.name = nm + (fmp4 ? ".mp4" : ".ts");
        j.mime = fmp4 ? "video/mp4" : "video/mp2t";
        j.parts = 6;

        final java.util.concurrent.ConcurrentHashMap<String, byte[]> keys = new java.util.concurrent.ConcurrentHashMap<>();
        ArrayDeque<Future<byte[]>> window = new ArrayDeque<>();
        int written = 0;
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            if (initUrl != null) {
                byte[] ib = getBytes(j, initUrl, new String[1]);
                out.write(ib);
                add(j, ib.length);
            }
            for (int i = 0; i < segs.size(); i++) {
                if (j.cancel) throw new IOException("cancel");
                final Seg g = segs.get(i);
                window.add(pool.submit(() -> fetchSeg(j, g, keys)));
                if (window.size() >= 6 || i == segs.size() - 1) {
                    while (!window.isEmpty() && (window.size() >= 6 || i == segs.size() - 1)) {
                        byte[] b = window.poll().get();
                        out.write(b);
                        add(j, b.length);
                        written++;
                        j.total = Math.max(j.done, (long) ((double) j.done / written * segs.size()));
                    }
                }
            }
            j.total = j.done;
        } catch (Exception e) {
            j.abort = true;
            throw e;
        }
        if (j.done < 10 * 1024) throw new IOException("empty video");
    }

    private byte[] fetchSeg(Job j, Seg g, java.util.concurrent.ConcurrentHashMap<String, byte[]> keys) throws Exception {
        byte[] data = getBytes(j, g.url, new String[1]);
        if (g.keyUri == null) return data;
        byte[] key = keys.get(g.keyUri);
        if (key == null) { key = getBytes(j, g.keyUri, new String[1]); keys.put(g.keyUri, key); }
        byte[] iv = new byte[16];
        if (g.iv != null) {
            String h = g.iv.startsWith("0x") || g.iv.startsWith("0X") ? g.iv.substring(2) : g.iv;
            while (h.length() < 32) h = "0" + h;
            for (int i = 0; i < 16; i++) iv[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
        } else {
            long q = g.seq;
            for (int i = 15; i >= 8; i--) { iv[i] = (byte) (q & 0xff); q >>= 8; }
        }
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c.doFinal(data);
    }

    private void part(Job j, File tmp, long start, long end) throws IOException {
        long pos = start;
        int tries = 0;
        while (pos <= end) {
            try {
                HttpURLConnection c = connect(j, "bytes=" + pos + "-" + end);
                if (c.getResponseCode() != 206) throw new IOException("no range");
                try (InputStream in = c.getInputStream(); RandomAccessFile raf = new RandomAccessFile(tmp, "rw")) {
                    raf.seek(pos);
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (j.cancel || j.abort) throw new IOException("stop");
                        int w = (int) Math.min(n, end - pos + 1);
                        raf.write(buf, 0, w);
                        pos += w;
                        add(j, w);
                        if (pos > end) break;
                    }
                }
            } catch (IOException ex) {
                if (j.cancel || j.abort || ++tries > 4) throw ex;
                try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
            }
        }
    }

    /** File ke pehle bytes dekh kar batao asal me kya hai. */
    static String sniff(File f) {
        byte[] b = new byte[400];
        int n;
        try (FileInputStream in = new FileInputStream(f)) { n = in.read(b); } catch (Exception e) { return "?"; }
        if (n < 8) return "?";
        if (b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p') return "mp4";
        if ((b[4] == 'm' && b[5] == 'o' && b[6] == 'o' && b[7] == 'f') || (b[4] == 's' && b[5] == 't' && b[6] == 'y' && b[7] == 'p')) return "mp4";
        if ((b[0] & 0xff) == 0x47 && (n < 189 || (b[188] & 0xff) == 0x47)) return "ts";
        if ((b[0] & 0xff) == 0x1A && (b[1] & 0xff) == 0x45 && (b[2] & 0xff) == 0xDF && (b[3] & 0xff) == 0xA3) return "webm";
        if (b[0] == 'I' && b[1] == 'D' && b[2] == '3') return "mp3";
        if ((b[0] & 0xff) == 0xFF && ((b[1] & 0xff) & 0xE0) == 0xE0) return "mp3";
        if (b[0] == 'O' && b[1] == 'g' && b[2] == 'g' && b[3] == 'S') return "ogg";
        if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F') return "riff";
        String head = new String(b, 0, n, java.nio.charset.StandardCharsets.ISO_8859_1).trim().toLowerCase();
        if (head.startsWith("#extm3u")) return "m3u8";
        if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<?xml") || head.startsWith("<head")
                || head.startsWith("{\"") || head.startsWith("<body") || head.startsWith("<")) return "html";
        return "?";
    }

    /** TS / fragmented MP4 → normal MP4 (Android ka MediaMuxer; dobara encode nahi, isliye tez aur quality same). */
    static boolean remux(File in, File out) {
        android.media.MediaExtractor ex = new android.media.MediaExtractor();
        android.media.MediaMuxer mx = null;
        boolean started = false;
        try {
            ex.setDataSource(in.getAbsolutePath());
            int n = ex.getTrackCount();
            if (n == 0) return false;
            mx = new android.media.MediaMuxer(out.getAbsolutePath(), android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int[] map = new int[n];
            int maxSize = 2 * 1024 * 1024, used = 0;
            for (int i = 0; i < n; i++) {
                map[i] = -1;
                android.media.MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(android.media.MediaFormat.KEY_MIME);
                if (m == null) continue;
                boolean ok = m.equals("video/avc") || m.equals("video/hevc") || m.equals("video/mp4v-es")
                        || m.equals("audio/mp4a-latm") || (Build.VERSION.SDK_INT >= 29 && m.equals("audio/mpeg"));
                if (!ok) {
                    if (m.startsWith("video/") || m.startsWith("audio/")) return false;   // awaaz/video kho na jaye
                    continue;
                }
                map[i] = mx.addTrack(f);
                ex.selectTrack(i);
                used++;
                if (f.containsKey(android.media.MediaFormat.KEY_MAX_INPUT_SIZE))
                    maxSize = Math.max(maxSize, f.getInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE));
            }
            if (used == 0) return false;
            mx.start();
            started = true;
            java.nio.ByteBuffer buf = java.nio.ByteBuffer.allocate(maxSize);
            android.media.MediaCodec.BufferInfo bi = new android.media.MediaCodec.BufferInfo();
            long base = -1;
            long[] last = new long[n];
            java.util.Arrays.fill(last, -1);
            while (true) {
                int ti = ex.getSampleTrackIndex();
                if (ti < 0) break;
                int size = ex.readSampleData(buf, 0);
                if (size < 0) break;
                long pts = ex.getSampleTime();
                if (base < 0) base = pts;
                pts = Math.max(0, pts - base);
                if (pts < last[ti]) pts = last[ti];
                last[ti] = pts;
                if (map[ti] >= 0) {
                    bi.offset = 0;
                    bi.size = size;
                    bi.presentationTimeUs = pts;
                    bi.flags = (ex.getSampleFlags() & android.media.MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                            ? android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    mx.writeSampleData(map[ti], buf, bi);
                }
                ex.advance();
            }
            mx.stop();
            started = false;
            return out.length() > 10 * 1024;
        } catch (Throwable e) {
            return false;
        } finally {
            try { if (mx != null) { if (started) mx.stop(); mx.release(); } } catch (Throwable ignored) {}
            try { ex.release(); } catch (Throwable ignored) {}
        }
    }

    /** Ye link pehle se download ho raha hai? */
    static boolean isRunning(String url) {
        for (Job j : JOBS.values()) if (j.status == RUNNING && url != null && url.equals(j.url)) return true;
        return false;
    }

    private static void add(Job j, long n) { synchronized (j) { j.done += n; } }

    private String mimeOf(Job j) {
        String m = j.mime;
        if (m != null && m.contains(";")) m = m.substring(0, m.indexOf(';')).trim();
        if (m == null || m.isEmpty() || m.equals("application/octet-stream")) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(j.name);
            String g = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
            if (g != null) m = g;
        }
        return m == null || m.isEmpty() ? "application/octet-stream" : m;
    }

    /** Taiyaar file ko phone me rakhta hai: video -> Gallery (Movies/Baatora), audio -> Music, photo -> Pictures. */
    private void publish(Job j, File tmp) throws Exception {
        String mime = mimeOf(j);
        j.mime = mime;
        final boolean video = mime.startsWith("video/"), audio = mime.startsWith("audio/"), image = mime.startsWith("image/");
        final String folder = video ? Environment.DIRECTORY_MOVIES : audio ? Environment.DIRECTORY_MUSIC
                : image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            Uri coll = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    : audio ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    : image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, j.name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, folder + "/Baatora");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(coll, cv);
            if (u == null) throw new IOException("no uri");
            try (InputStream in = new FileInputStream(tmp); OutputStream out = cr.openOutputStream(u)) {
                if (out == null) throw new IOException("no stream");
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, cv, null, null);
            j.uri = u.toString();
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(folder), "Baatora");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File out = new File(dir, j.name);
            int k = 1;
            while (out.exists()) {
                String nm = j.name;
                int dot = nm.lastIndexOf('.');
                out = new File(dir, dot > 0 ? nm.substring(0, dot) + " (" + k + ")" + nm.substring(dot) : nm + " (" + k + ")");
                k++;
            }
            try (InputStream in = new FileInputStream(tmp); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, new String[]{mime}, null);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            @SuppressWarnings("deprecation")
            long id = dm.addCompletedDownload(j.name, "Baatora Turbo", true, mime, out.getAbsolutePath(), out.length(), false);
            j.uri = "dm:" + id;
        }
    }

    /** Downloads page ke liye record. */
    private synchronized void record(Job j) {
        try {
            JSONArray old = Store.load(this, "turbo"), arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("id", j.id);
            o.put("name", j.name);
            o.put("uri", j.uri == null ? "" : j.uri);
            o.put("size", Math.max(j.total, j.done));
            o.put("mime", j.mime == null ? "" : j.mime);
            o.put("time", System.currentTimeMillis());
            o.put("status", j.status);
            o.put("url", j.url);
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 300; i++) arr.put(old.get(i));
            Store.prefs(this).edit().putString("turbo", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void finishedNotice(Job j, boolean ok) {
        try {
            Notification n = builder()
                    .setSmallIcon(ok ? android.R.drawable.stat_sys_download_done : android.R.drawable.stat_notify_error)
                    .setContentTitle(ok ? "Download complete ✅" : "Download failed ❌")
                    .setContentText(j.name).setAutoCancel(true).build();
            nm.notify((int) (j.id % 100000) + 100, n);
        } catch (Exception ignored) {}
    }
}
