package com.baatora.browser;

import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Baatora Password Manager.
 * Passwords phone ke Android Keystore wali chaabi se encrypt hokar sirf isi phone me rehte hain (kahin upload nahi hote).
 */
public class Passwords {

    static final int REQ_UNLOCK = 31;
    static final String ALIAS = "baatora_pw_key";
    final MainActivity a;
    final SharedPreferences sp;
    String js;

    Passwords(MainActivity a) {
        this.a = a;
        this.sp = a.getSharedPreferences("baatora_vault", Context.MODE_PRIVATE);
    }

    boolean saveOn() { return a.prefs.getBoolean("pwSave", true); }
    boolean fillOn() { return a.prefs.getBoolean("pwFill", true); }

    // ─────────── Encryption (Android Keystore, AES-GCM) ───────────
    SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return kg.generateKey();
    }

    String enc(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] out = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(out, Base64.NO_WRAP);
    }

    String dec(String s) {
        try {
            String[] p = s.split(":", 2);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }

    // ─────────── Store ───────────
    static String site(String host) {
        if (host == null) return "";
        host = host.toLowerCase();
        return host.startsWith("www.") ? host.substring(4) : (host.startsWith("m.") ? host.substring(2) : host);
    }

    synchronized JSONArray all() {
        try { return new JSONArray(sp.getString("list", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    synchronized void putAll(JSONArray arr) { sp.edit().putString("list", arr.toString()).apply(); }

    synchronized JSONArray forSite(String host) {
        String s = site(host);
        JSONArray all = all(), out = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && s.equals(o.optString("h"))) out.put(o);
        }
        return out;
    }

    synchronized int find(String host, String user) {
        String s = site(host);
        JSONArray all = all();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && s.equals(o.optString("h")) && user.equals(o.optString("u"))) return i;
        }
        return -1;
    }

    synchronized void save(String host, String user, String pass) {
        try {
            JSONArray all = all();
            int i = find(host, user);
            JSONObject o = new JSONObject().put("h", site(host)).put("u", user).put("p", enc(pass)).put("t", System.currentTimeMillis());
            if (i >= 0) all.put(i, o); else all.put(o);
            putAll(all);
        } catch (Exception e) { a.toast("Password save nahi ho paya"); }
    }

    synchronized void remove(int idx) {
        JSONArray all = all(), out = new JSONArray();
        for (int i = 0; i < all.length(); i++) if (i != idx) out.put(all.opt(i));
        putAll(out);
    }

    boolean never(String host) { return sp.getBoolean("never|" + site(host), false); }

    static String generate() {
        String L = "abcdefghijkmnopqrstuvwxyz", U = "ABCDEFGHJKLMNPQRSTUVWXYZ", D = "23456789", S = "!@#$%&*?-_";
        String all = L + U + D + S;
        SecureRandom r = new SecureRandom();
        char[] c = new char[16];
        c[0] = L.charAt(r.nextInt(L.length())); c[1] = U.charAt(r.nextInt(U.length()));
        c[2] = D.charAt(r.nextInt(D.length())); c[3] = S.charAt(r.nextInt(S.length()));
        for (int i = 4; i < c.length; i++) c[i] = all.charAt(r.nextInt(all.length()));
        for (int i = c.length - 1; i > 0; i--) { int j = r.nextInt(i + 1); char t = c[i]; c[i] = c[j]; c[j] = t; }
        return new String(c);
    }

    // ─────────── Page script ───────────
    String script(String nonce) {
        if (js == null) js = a.asset("pw.js");
        return js.isEmpty() ? "" : js.replace("__NONCE__", nonce);
    }

    void inject(MainActivity.Tab t, WebView v, String url) {
        if (url == null || !url.startsWith("http") || t.incognito) return;
        if (!saveOn() && !fillOn()) return;
        if (t.pwNonce == null) t.pwNonce = Long.toHexString(new SecureRandom().nextLong()) + Long.toHexString(new SecureRandom().nextLong());
        String s = script(t.pwNonce);
        if (!s.isEmpty()) v.evaluateJavascript(s, null);
    }

    /** Har tab ka apna bridge — sirf usi website ke password deta hai jo tab me khuli hai. */
    class Bridge {
        final MainActivity.Tab t;
        Bridge(MainActivity.Tab t) { this.t = t; }

        boolean ok(String n) { return n != null && n.equals(t.pwNonce) && t.pageHost != null; }

        @JavascriptInterface
        public String users(String n) {
            if (!ok(n) || !fillOn()) return "[]";
            JSONArray l = forSite(t.pageHost), out = new JSONArray();
            for (int i = 0; i < l.length(); i++) out.put(l.optJSONObject(i).optString("u"));
            return out.toString();
        }

        @JavascriptInterface
        public String fill(String n, int i) {
            if (!ok(n) || !fillOn()) return "null";
            JSONObject o = forSite(t.pageHost).optJSONObject(i);
            if (o == null) return "null";
            String p = dec(o.optString("p"));
            if (p == null) return "null";
            try { return new JSONObject().put("u", o.optString("u")).put("p", p).toString(); } catch (Exception e) { return "null"; }
        }

        @JavascriptInterface
        public String gen(String n) { return ok(n) ? generate() : ""; }

        @JavascriptInterface
        public void capture(String n, final String user, final String pass) {
            if (!ok(n) || !saveOn() || pass == null || pass.length() < 3) return;
            final String host = t.pageHost;
            if (never(host)) return;
            final String u = user == null ? "" : user.trim();
            int i = find(host, u);
            if (i >= 0) {
                String old = dec(all().optJSONObject(i).optString("p"));
                if (pass.equals(old)) return;                   // pehle se saved
            }
            final boolean update = i >= 0;
            a.runOnUiThread(() -> askSave(host, u, pass, update));
        }
    }

    String lastAsk = "";
    long lastAskAt = 0;

    void askSave(String host, String user, String pass, boolean update) {
        String k = host + "|" + user + "|" + pass.hashCode();
        if (k.equals(lastAsk) && System.currentTimeMillis() - lastAskAt < 60000) return;   // ek hi baar poochho
        lastAsk = k; lastAskAt = System.currentTimeMillis();
        new AlertDialog.Builder(a)
                .setTitle(update ? "🔑 Password update karein?" : "🔑 Password save karein?")
                .setMessage((user.isEmpty() ? "(username nahi)" : user) + "\n" + site(host)
                        + "\n\nPassword encrypted hokar sirf aapke phone me rahega.")
                .setPositiveButton(update ? "Update" : "Save", (d, w) -> { save(host, user, pass); a.toast("✓ Password save ho gaya"); })
                .setNeutralButton("Kabhi nahi", (d, w) -> { sp.edit().putBoolean("never|" + site(host), true).apply(); a.toast("Is site ke liye kabhi nahi poochhenge"); })
                .setNegativeButton("Abhi nahi", null)
                .show();
    }

    // ─────────── Password Manager screen (phone lock se khule) ───────────
    void open() {
        KeyguardManager km = (KeyguardManager) a.getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null && km.isDeviceSecure()) {
            Intent i = km.createConfirmDeviceCredentialIntent("Baatora Passwords", "Apna phone lock (PIN / fingerprint) daalo");
            if (i != null) { a.startActivityForResult(i, REQ_UNLOCK); return; }
        }
        list(null);
    }

    void onUnlock(boolean ok) {
        if (ok) list(null); else a.toast("Passwords dekhne ke liye phone lock zaroori hai");
    }

    void list(String filter) {
        final JSONArray all = all();
        final java.util.ArrayList<Integer> idx = new java.util.ArrayList<>();
        java.util.ArrayList<String> rows = new java.util.ArrayList<>();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null) continue;
            String h = o.optString("h"), u = o.optString("u");
            if (filter != null && !(h + " " + u).toLowerCase().contains(filter.toLowerCase())) continue;
            idx.add(i);
            rows.add("🔑 " + h + "\n      " + (u.isEmpty() ? "(username nahi)" : u));
        }
        AlertDialog.Builder b = new AlertDialog.Builder(a)
                .setTitle("🔐 Baatora Password Manager (" + all.length() + ")");
        if (rows.isEmpty()) b.setMessage(filter == null
                ? "Abhi koi password save nahi hai.\n\nKisi website par login karte hi Baatora poochhega: \"Password save karein?\""
                : "Kuch nahi mila");
        else b.setItems(rows.toArray(new String[0]), (d, w) -> entry(idx.get(w)));
        b.setPositiveButton("🔍 Dhoondo", (d, w) -> search())
                .setNeutralButton("⚙️ Settings", (d, w) -> settings())
                .setNegativeButton("Band karo", null).show();
    }

    void search() {
        final android.widget.EditText et = new android.widget.EditText(a);
        et.setHint("Website ya username");
        new AlertDialog.Builder(a).setTitle("Password dhoondo").setView(et)
                .setPositiveButton("Dhoondo", (d, w) -> list(et.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    void entry(final int i) {
        final JSONObject o = all().optJSONObject(i);
        if (o == null) return;
        final String h = o.optString("h"), u = o.optString("u");
        final String p = dec(o.optString("p"));
        String[] opts = {"👤 Username copy karo", "🔑 Password copy karo", "👁 Password dikhao", "🌐 Website kholo", "🗑 Delete"};
        new AlertDialog.Builder(a).setTitle(h + (u.isEmpty() ? "" : " • " + u))
                .setItems(opts, (d, w) -> {
                    switch (w) {
                        case 0: copy(u, false); break;
                        case 1: if (p != null) copy(p, true); break;
                        case 2: new AlertDialog.Builder(a).setTitle(h).setMessage((u.isEmpty() ? "" : u + "\n") + (p == null ? "(padha nahi gaya)" : p))
                                .setPositiveButton("OK", null).show(); break;
                        case 3: a.createTab("https://" + h, false, true); break;
                        case 4: new AlertDialog.Builder(a).setTitle("Delete karein?").setMessage(h + "\n" + u)
                                .setPositiveButton("Delete", (d2, w2) -> { remove(i); a.toast("🗑 Hata diya"); list(null); })
                                .setNegativeButton("Cancel", null).show(); break;
                    }
                }).show();
    }

    void copy(String s, boolean secret) {
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        ClipData cd = ClipData.newPlainText(secret ? "password" : "username", s);
        if (secret && android.os.Build.VERSION.SDK_INT >= 24) {
            android.os.PersistableBundle ex = new android.os.PersistableBundle();
            ex.putBoolean("android.content.extra.IS_SENSITIVE", true);
            cd.getDescription().setExtras(ex);
        }
        cm.setPrimaryClip(cd);
        a.toast(secret ? "🔑 Password copy hua" : "👤 Username copy hua");
        if (secret) new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            try { if (android.os.Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip(); } catch (Exception ignored) {}
        }, 60000);
    }

    void settings() {
        final String[] items = {
                (saveOn() ? "✅" : "⬜") + " Password save karne ke liye poochho",
                (fillOn() ? "✅" : "⬜") + " Login form me apne aap bharne ka button",
                "🔐 Naya strong password banao (copy)",
                "🚫 'Kabhi nahi' wali sites reset karo",
                "📱 Android Autofill service chuno (Google / Samsung)"};
        new AlertDialog.Builder(a).setTitle("Password settings")
                .setItems(items, (d, w) -> {
                    if (w == 0) a.prefs.edit().putBoolean("pwSave", !saveOn()).apply();
                    else if (w == 1) a.prefs.edit().putBoolean("pwFill", !fillOn()).apply();
                    else if (w == 2) { String g = generate(); copy(g, true);
                        new AlertDialog.Builder(a).setTitle("Strong password").setMessage(g + "\n\n(copy ho gaya)").setPositiveButton("OK", null).show(); return; }
                    else if (w == 3) { SharedPreferences.Editor e = sp.edit(); for (String k : sp.getAll().keySet()) if (k.startsWith("never|")) e.remove(k); e.apply(); a.toast("Reset ho gaya"); }
                    else if (w == 4) { a.openAutofillSettings(); return; }
                    settings();
                }).setNegativeButton("Wapas", (d, w) -> list(null)).show();
    }
}
