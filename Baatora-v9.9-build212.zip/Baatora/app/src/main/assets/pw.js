/* Baatora Password Manager — login form pehchaano, password bharo / banao / save ke liye poochho. */
(function(N){
if(window.__btpw)return;window.__btpw=1;
var B=window.BaatoraPw;if(!B)return;
function vis(e){try{var r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden';}catch(x){return false;}}
function pwFields(root){var a=[],l=(root||document).querySelectorAll('input[type=password]');for(var i=0;i<l.length;i++)if(vis(l[i]))a.push(l[i]);return a;}
function userField(p){
 var f=p.form||document,l=f.querySelectorAll('input'),best=null;
 for(var i=0;i<l.length;i++){var e=l[i];if(e===p)break;var t=(e.type||'text').toLowerCase();
  if(!vis(e))continue;
  if(/^(text|email|tel|number)$/.test(t)||/username|email/.test(e.autocomplete||''))best=e;}
 if(!best){var u=document.querySelector('input[autocomplete=username],input[type=email],input[name*=user i],input[name*=email i],input[name*=login i],input[id*=user i],input[id*=email i]');if(u&&vis(u))best=u;}
 return best;
}
function isNew(p){
 var ac=(p.autocomplete||'').toLowerCase();if(ac.indexOf('new-password')>=0)return true;if(ac.indexOf('current-password')>=0)return false;
 var s=((p.name||'')+' '+(p.id||'')+' '+(p.placeholder||'')).toLowerCase();
 if(/new|confirm|register|signup|sign_up|create|repeat|retype|again/.test(s))return true;
 var f=p.form;if(f&&pwFields(f).length>=2)return true;
 return /signup|sign-up|register|create.?account|join/.test(location.pathname.toLowerCase());
}
function setVal(e,v){
 try{var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(e,v);}catch(x){e.value=v;}
 e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));
}
var chip=null;
function hideChip(){if(chip){chip.remove();chip=null;}}
function showChip(p,html,onTap){
 hideChip();
 chip=document.createElement('div');
 chip.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:18px;z-index:2147483647;background:linear-gradient(90deg,#1E5BFF,#7C4DFF);'+
 'color:#fff;font:600 14px/1.3 sans-serif;padding:11px 16px;border-radius:22px;box-shadow:0 6px 22px rgba(0,0,0,.35);max-width:92vw;display:flex;gap:10px;align-items:center';
 chip.innerHTML=html+'<span style="opacity:.8;padding-left:8px;font-size:18px" data-x>×</span>';
 chip.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();if(ev.target&&ev.target.hasAttribute('data-x')){hideChip();return;}onTap(ev);},true);
 document.documentElement.appendChild(chip);
}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
var genUsed=null,offered=null;
function offer(p){
 if(offered===p)return;offered=p;
 if(isNew(p)){
  showChip(p,'🔐 Baatora: strong password banayein',function(){
   var g=B.gen(N);if(!g)return;genUsed=g;
   var all=pwFields(p.form||document);for(var i=0;i<all.length;i++)if(isNew(all[i])||all.length>=2)setVal(all[i],g);
   hideChip();
  });
  return;
 }
 var us=[];try{us=JSON.parse(B.users(N)||'[]');}catch(x){}
 if(!us.length)return;
 var html='🔑 <span>'+(us.length===1?esc(us[0]||'Saved password')+' — bharein':us.length+' saved login — chunein')+'</span>';
 showChip(p,html,function(){
  var i=0;
  if(us.length>1){var m='Kaun sa login?\n';for(var k=0;k<us.length;k++)m+=(k+1)+'. '+(us[k]||'(no username)')+'\n';var a=prompt(m,'1');if(a===null)return;i=Math.max(0,Math.min(us.length-1,(parseInt(a,10)||1)-1));}
  var c=null;try{c=JSON.parse(B.fill(N,i)||'null');}catch(x){}
  if(!c)return;
  var u=userField(p);if(u&&c.u)setVal(u,c.u);setVal(p,c.p);hideChip();
 });
}
function capture(form){
 try{
  var ps=pwFields(form||document);if(!ps.length)return;
  var p=null;for(var i=ps.length-1;i>=0;i--)if(ps[i].value){p=ps[i];break;}
  if(!p||p.value.length<3)return;
  var u=userField(p);
  B.capture(N,u?u.value:'',p.value);
 }catch(x){}
}
document.addEventListener('focusin',function(e){var t=e.target;if(t&&t.tagName==='INPUT'){if(t.type==='password')offer(t);else{var ps=pwFields(t.form||null);if(ps.length&&!ps[0].value&&!isNew(ps[0]))offer(ps[0]);}}},true);
document.addEventListener('submit',function(e){capture(e.target);},true);
document.addEventListener('click',function(e){
 var b=e.target&&e.target.closest&&e.target.closest('button,input[type=submit],input[type=button],[role=button],a');
 if(!b)return;var f=b.form||b.closest('form');
 var txt=((b.innerText||b.value||'')+' '+(b.id||'')+' '+(b.className||'')).toLowerCase();
 if(f||/log ?in|sign ?in|sign ?up|register|submit|continue|next|login|लॉग|साइन/.test(txt))setTimeout(function(){capture(f);},0);
},true);
document.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target&&e.target.type==='password')capture(e.target.form);},true);
window.addEventListener('pagehide',function(){capture(null);});
/* page khulte hi login form ho to turant offer */
function scan(){var ps=pwFields();if(ps.length&&!ps[0].value)offer(ps[0]);}
setTimeout(scan,700);
var st=0;try{new MutationObserver(function(){if(st)return;st=setTimeout(function(){st=0;if(!offered||!document.contains(offered))scan();},800);}).observe(document.documentElement,{childList:true,subtree:true});}catch(x){}
})('__NONCE__');
