BAATORA BROWSER - Made in India
================================

APK KAISE BANAYEIN (bina computer, sirf mobile se - FREE):

1. github.com par account banayein / login karein.
2. "New repository" banayein, naam: baatora (Public ya Private).
3. "Add file" > "Upload files" > Baatora-Android-Project.zip upload karein
   (zip ko extract MAT karein) > "Commit changes".
4. "Add file" > "Create new file"
   File naam me likhein:  .github/workflows/build.yml
   build.yml ka pura content copy karke paste karein > "Commit changes".
5. Upar "Actions" tab kholein. "Build Baatora APK" chalne lagega (5-8 minute).
6. Green tick aane par us run ko kholein > neeche "Artifacts" me
   "Baatora-Browser-APK" download karein > zip kholein > app-debug.apk install karein.

COMPUTER SE (Android Studio):
- Android Studio me "Baatora" folder Open karein > Build > Build APK(s).

App ka naam, package: com.baatora.browser (Version 7.2)
Signing key: app/baatora.jks (isse mat hatana — isi se update hota hai)
Logo badalna ho to: app/src/main/res/mipmap-*/ic_launcher.png aur drawable-nodpi/logo.png
Home page design: app/src/main/assets/home.html
