package com.baatora.browser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Chhote UI helpers: rang, gol kone, icon tiles aur website logos. */
final class Ui {

    static float density = 1f;
    static final int NAVY = 0xFF06103A, NAVY2 = 0xFF0D2A8A, BLUE = 0xFF1E5BFF,
            ORANGE = 0xFFFF8A00, GOLD = 0xFFFFC107, CYAN = 0xFF00E5FF, MUTED = 0xFF9FB3FF;

    static final int[][] PALETTE = {
            {0xFFFF9800, 0xFFFF5722}, {0xFF448AFF, 0xFF1A3FD8}, {0xFF00E5FF, 0xFF0091EA},
            {0xFFFF4081, 0xFFC51162}, {0xFFB388FF, 0xFF6200EA}, {0xFFFFD740, 0xFFFF9100},
            {0xFF64FFDA, 0xFF00897B}, {0xFFFF8A80, 0xFFD50000}
    };

    private Ui() {}

    static int dp(float v) { return (int) (v * density + 0.5f); }

    static GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    static GradientDrawable grad(int c1, int c2, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    static GradientDrawable stroke(GradientDrawable g, int color, float widthDp) {
        g.setStroke(dp(widthDp), color);
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static ImageView icon(Context c, int res, int tint) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(res);
        iv.setColorFilter(tint);
        return iv;
    }

    static ImageView iconButton(Context c, int res, View.OnClickListener l) {
        ImageView iv = icon(c, res, Color.WHITE);
        iv.setPadding(dp(10), dp(10), dp(10), dp(10));
        ripple(iv, true);
        iv.setOnClickListener(l);
        return iv;
    }

    static void ripple(View v, boolean borderless) {
        TypedValue tv = new TypedValue();
        v.getContext().getTheme().resolveAttribute(borderless
                ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        v.setForeground(v.getContext().getDrawable(tv.resourceId));
        v.setClickable(true);
    }

    /** Gradient squircle ke andar safed icon (menu ke liye). */
    static FrameLayout iconTile(Context c, int res, int[] colors, int sizeDp) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(grad(colors[0], colors[1], sizeDp * 0.34f));
        f.setElevation(dp(5));
        ImageView iv = icon(c, res, Color.WHITE);
        int pad = dp(sizeDp * 0.24f);
        iv.setPadding(pad, pad, pad, pad);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        return f;
    }

    /** Website ka asli logo (favicon), na mile to rangeen pehla akshar. */
    static FrameLayout siteIcon(Context c, String name, String host, int sizeDp) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(round(Color.WHITE, sizeDp * 0.3f));
        f.setClipToOutline(true);
        String letter = (name == null || name.trim().isEmpty()) ? "?" : name.trim().substring(0, 1).toUpperCase();
        int[] pal = PALETTE[Math.abs((host == null ? letter : host).hashCode()) % PALETTE.length];
        TextView t = text(c, letter, sizeDp * 0.42f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(grad(pal[0], pal[1], sizeDp * 0.3f));
        f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        ImageView iv = new ImageView(c);
        int pad = dp(sizeDp * 0.16f);
        iv.setPadding(pad, pad, pad, pad);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        favicon(iv, host, t);
        return f;
    }

    // ───── Favicon loader (chhota cache ke saath) ─────
    static final LruCache<String, Bitmap> CACHE = new LruCache<>(120);
    static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void favicon(ImageView iv, String host, View hideOnLoad) {
        if (host == null || host.isEmpty()) return;
        iv.setTag(host);
        Bitmap cached = CACHE.get(host);
        if (cached != null) { show(iv, cached, hideOnLoad); return; }
        POOL.execute(() -> {
            Bitmap bm = null;
            try {
                HttpURLConnection con = (HttpURLConnection) new URL(
                        "https://www.google.com/s2/favicons?sz=64&domain=" + host).openConnection();
                con.setConnectTimeout(6000);
                con.setReadTimeout(6000);
                InputStream in = con.getInputStream();
                bm = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) {}
            // Google 16px ka default globe deta hai jab logo na mile — use chhod do
            final Bitmap fb = (bm != null && bm.getWidth() > 16) ? bm : null;
            if (fb != null) CACHE.put(host, fb);
            MAIN.post(() -> { if (fb != null && host.equals(iv.getTag())) show(iv, fb, hideOnLoad); });
        });
    }

    private static void show(ImageView iv, Bitmap b, View hide) {
        iv.setImageBitmap(b);
        iv.setBackgroundColor(Color.WHITE);
        if (hide != null) hide.setVisibility(View.INVISIBLE);
    }
}
