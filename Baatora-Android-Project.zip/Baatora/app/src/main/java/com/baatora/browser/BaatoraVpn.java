package com.baatora.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Baatora Shield VPN — Baatora ka apna VPN.
 * Phone ke saare DNS sawaal (kaun si website kahan hai) ek surakshit, encrypted rasta (DNS-over-HTTPS, 1.1.1.1)
 * se jaate hain, aur ad / tracker / jua (betting) wali sites poore phone me rok di jaati hain.
 * Note: ye IP / desh nahi badalta — uske liye paid server chahiye.
 */
public class BaatoraVpn extends VpnService {

    static final String ACTION_START = "com.baatora.vpn.START", ACTION_STOP = "com.baatora.vpn.STOP";
    static final String VPN_ADDR = "10.111.222.1", VPN_DNS = "10.111.222.2";
    static final String CHANNEL = "baatora_vpn";
    static volatile boolean running;
    static volatile int blocked;

    ParcelFileDescriptor tun;
    Thread reader;
    ExecutorService pool;
    FileOutputStream out;

    static void start(Context c) {
        Intent i = new Intent(c, BaatoraVpn.class).setAction(ACTION_START);
        c.startService(i);
    }

    static void stop(Context c) {
        c.startService(new Intent(c, BaatoraVpn.class).setAction(ACTION_STOP));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(act)) {
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) open();
        if (running) {
            try { NotificationManager nm = getSystemService(NotificationManager.class); if (nm != null) nm.notify(41, note()); }
            catch (Exception ignored) {}
        }
        return START_STICKY;
    }

    Notification note() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Baatora VPN", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_shield)
                .setContentTitle("🛡 Baatora VPN chalu hai")
                .setContentText("Surakshit DNS + ad aur tracker block")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    void open() {
        try {
            Builder b = new Builder();
            b.setSession("Baatora VPN");
            b.addAddress(VPN_ADDR, 32);
            b.addDnsServer(VPN_DNS);
            b.addRoute(VPN_DNS, 32);   // sirf DNS tunnel se jata hai, baaki internet tez aur seedha
            b.setBlocking(true);
            b.setMtu(1500);
            try { b.addDisallowedApplication("com.cloudflare.onedotonedotonedotone"); } catch (Exception ignored) {}
            tun = b.establish();
            if (tun == null) { stopSelf(); return; }
            out = new FileOutputStream(tun.getFileDescriptor());
            pool = Executors.newFixedThreadPool(6);
            running = true;
            getSharedPreferences("baatora", MODE_PRIVATE).edit().putBoolean("myvpn", true).apply();
            reader = new Thread(this::loop, "baatora-vpn");
            reader.start();
        } catch (Exception e) {
            shutdown();
            stopSelf();
        }
    }

    void loop() {
        byte[] buf = new byte[32767];
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor())) {
            while (running) {
                int n = in.read(buf);
                if (n <= 0) continue;
                final byte[] pkt = new byte[n];
                System.arraycopy(buf, 0, pkt, 0, n);
                try { pool.execute(() -> handle(pkt)); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
        }
    }

    /** IPv4 + UDP + port 53 wale packet ka jawab do. */
    void handle(byte[] p) {
        try {
            if ((p[0] >> 4) != 4) return;
            int ihl = (p[0] & 0x0F) * 4;
            if (p[9] != 17) return; // UDP
            int dport = ((p[ihl + 2] & 0xFF) << 8) | (p[ihl + 3] & 0xFF);
            if (dport != 53) return;
            int udpLen = ((p[ihl + 4] & 0xFF) << 8) | (p[ihl + 5] & 0xFF);
            int qLen = Math.min(udpLen - 8, p.length - ihl - 8);
            if (qLen <= 12) return;
            byte[] q = new byte[qLen];
            System.arraycopy(p, ihl + 8, q, 0, qLen);

            String name = qname(q);
            byte[] ans;
            if (name != null && isBlocked(name)) {
                ans = nxdomain(q);
                blocked++;
            } else {
                ans = doh(q);
                if (ans == null) ans = udp(q);
                if (ans == null) return;
            }
            write(reply(p, ihl, ans));
        } catch (Exception ignored) {
        }
    }

    static String qname(byte[] q) {
        StringBuilder sb = new StringBuilder();
        int i = 12;
        while (i < q.length) {
            int l = q[i] & 0xFF;
            if (l == 0) break;
            if (l > 63 || i + 1 + l > q.length) return null;
            if (sb.length() > 0) sb.append('.');
            sb.append(new String(q, i + 1, l));
            i += l + 1;
        }
        return sb.toString().toLowerCase();
    }

    static boolean isBlocked(String h) {
        for (String a : MainActivity.AD_HOSTS) if (h.equals(a) || h.endsWith("." + a)) return true;
        for (String k : MainActivity.BET_WORDS) if (h.contains(k)) return true;
        return false;
    }

    static byte[] nxdomain(byte[] q) {
        byte[] r = q.clone();
        r[2] = (byte) (0x80 | (q[2] & 0x01) | 0x04); // response, RD copy, AA
        r[3] = (byte) 0x83;                           // RA + NXDOMAIN
        r[6] = r[7] = r[8] = r[9] = r[10] = r[11] = 0;
        return r;
    }

    static final String[] DOH = {"https://1.1.1.1/dns-query", "https://1.0.0.1/dns-query", "https://8.8.8.8/dns-query"};

    byte[] doh(byte[] q) {
        for (String u : DOH) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(u).openConnection();
                c.setConnectTimeout(4000);
                c.setReadTimeout(4000);
                c.setDoOutput(true);
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/dns-message");
                c.setRequestProperty("Accept", "application/dns-message");
                try (OutputStream o = c.getOutputStream()) { o.write(q); }
                if (c.getResponseCode() != 200) continue;
                try (InputStream in = c.getInputStream()) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] b = new byte[2048];
                    int n;
                    while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                    byte[] r = bo.toByteArray();
                    if (r.length >= 12) return r;
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }
        return null;
    }

    byte[] udp(byte[] q) {
        try (DatagramSocket s = new DatagramSocket()) {
            protect(s);
            s.setSoTimeout(4000);
            s.send(new DatagramPacket(q, q.length, InetAddress.getByName("1.1.1.1"), 53));
            byte[] b = new byte[4096];
            DatagramPacket dp = new DatagramPacket(b, b.length);
            s.receive(dp);
            byte[] r = new byte[dp.getLength()];
            System.arraycopy(b, 0, r, 0, r.length);
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    /** Jawab wala IPv4/UDP packet banao (source/destination ulte). */
    static byte[] reply(byte[] p, int ihl, byte[] dns) {
        int total = 20 + 8 + dns.length;
        byte[] r = new byte[total];
        r[0] = 0x45;
        r[2] = (byte) (total >> 8); r[3] = (byte) total;
        r[4] = p[4]; r[5] = p[5];
        r[6] = 0x40; // don't fragment
        r[8] = 64;
        r[9] = 17;
        System.arraycopy(p, 16, r, 12, 4); // src = purana dst
        System.arraycopy(p, 12, r, 16, 4); // dst = purana src
        int cs = 0;
        for (int i = 0; i < 20; i += 2) cs += ((r[i] & 0xFF) << 8) | (r[i + 1] & 0xFF);
        while ((cs >> 16) != 0) cs = (cs & 0xFFFF) + (cs >> 16);
        cs = ~cs & 0xFFFF;
        r[10] = (byte) (cs >> 8); r[11] = (byte) cs;
        r[20] = p[ihl + 2]; r[21] = p[ihl + 3]; // src port = 53
        r[22] = p[ihl];     r[23] = p[ihl + 1]; // dst port = app ka port
        int ul = 8 + dns.length;
        r[24] = (byte) (ul >> 8); r[25] = (byte) ul;
        r[26] = 0; r[27] = 0; // IPv4 me UDP checksum zaroori nahi
        System.arraycopy(dns, 0, r, 28, dns.length);
        return r;
    }

    synchronized void write(byte[] b) {
        try { if (out != null) out.write(b); } catch (Exception ignored) {}
    }

    void shutdown() {
        running = false;
        getSharedPreferences("baatora", MODE_PRIVATE).edit().putBoolean("myvpn", false).apply();
        try { if (pool != null) pool.shutdownNow(); } catch (Exception ignored) {}
        try { if (tun != null) tun.close(); } catch (Exception ignored) {}
        tun = null;
        out = null;
        try { NotificationManager nm = getSystemService(NotificationManager.class); if (nm != null) nm.cancel(41); }
        catch (Exception ignored) {}
    }

    @Override
    public void onRevoke() {
        shutdown();
        stopSelf();
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }
}
