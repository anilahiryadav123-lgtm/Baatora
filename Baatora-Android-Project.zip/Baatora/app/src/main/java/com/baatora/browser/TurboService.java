package com.baatora.browser;

import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.webkit.MimeTypeMap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ⚡ Turbo Download — ek file ko 4-6 hisson me ek saath download karta hai
 * (jab server ijazat de), isliye aksar normal se tez hota hai.
 */
public class TurboService extends Service {

    static final int RUNNING = 0, DONE = 1, FAILED = 2, CANCELLED = 3;
    static final String CH = "bt_downloads";

    static class Job {
        long id, time;
        String url, ua, cookie, referer, mime, name, uri;
        volatile long total = -1, done, speed, lastDone;
        volatile int status = RUNNING, parts = 1;
        volatile boolean cancel, abort;
    }

    static final ConcurrentHashMap<Long, Job> JOBS = new ConcurrentHashMap<>();
    static final AtomicLong IDS = new AtomicLong(System.currentTimeMillis());

    static long start(Context c, String url, String ua, String cookie, String referer, String mime, String name) {
        Job j = new Job();
        j.id = IDS.incrementAndGet();
        j.url = url; j.ua = ua; j.cookie = cookie; j.referer = referer; j.mime = mime; j.name = name;
        j.time = System.currentTimeMillis();
        JOBS.put(j.id, j);
        Intent i = new Intent(c, TurboService.class).putExtra("id", j.id);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        return j.id;
    }

    static ArrayList<Job> running() {
        ArrayList<Job> out = new ArrayList<>();
        for (Job j : JOBS.values()) if (j.status == RUNNING) out.add(j);
        return out;
    }

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler main = new Handler(Looper.getMainLooper());
    private NotificationManager nm;
    private int active = 0;
    private boolean ticking;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Baatora Downloads", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = summary();
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(77, n);
        long id = intent == null ? -1 : intent.getLongExtra("id", -1);
        final Job j = JOBS.get(id);
        if (j != null) {
            active++;
            pool.execute(() -> work(j));
        } else if (active == 0) {
            stopSelf();
        }
        if (!ticking) { ticking = true; main.post(ticker); }
        return START_NOT_STICKY;
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            for (Job j : JOBS.values()) {
                if (j.status != RUNNING) continue;
                j.speed = j.done - j.lastDone;
                j.lastDone = j.done;
            }
            if (active > 0) {
                nm.notify(77, summary());
                main.postDelayed(this, 1000);
            } else {
                ticking = false;
            }
        }
    };

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class).setAction("baatora.DOWNLOADS")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification.Builder builder() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_sys_download).setContentIntent(openApp());
    }

    private Notification summary() {
        long total = 0, done = 0, speed = 0;
        int n = 0;
        boolean known = true;
        for (Job j : JOBS.values()) {
            if (j.status != RUNNING) continue;
            n++;
            done += j.done;
            speed += j.speed;
            if (j.total > 0) total += j.total; else known = false;
        }
        int pct = known && total > 0 ? (int) (done * 100 / total) : 0;
        String text = Formatter.formatFileSize(this, done) + (known && total > 0 ? " / " + Formatter.formatFileSize(this, total) : "")
                + "  •  " + Formatter.formatFileSize(this, speed) + "/s";
        return builder().setContentTitle("⚡ Turbo download (" + Math.max(n, 1) + ")")
                .setContentText(text).setOngoing(true).setOnlyAlertOnce(true)
                .setProgress(100, pct, !known || total <= 0).build();
    }

    // ───────────── Download ka kaam ─────────────

    private void work(Job j) {
        File tmp = new File(getExternalFilesDir(null) != null ? getExternalFilesDir(null) : getCacheDir(), "bt_" + j.id + ".part");
        try {
            download(j, tmp);
            if (j.cancel) throw new IOException("cancel");
            publish(j, tmp);
            j.status = DONE;
            record(j);
            Store.addNotif(this, "dl", "Download poora hua ✅", j.name);
            finishedNotice(j, true);
        } catch (Exception e) {
            j.status = j.cancel ? CANCELLED : FAILED;
            if (!j.cancel) {
                record(j);
                Store.addNotif(this, "dlfail", "Download fail hua ❌", j.name);
                finishedNotice(j, false);
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            main.post(() -> {
                active--;
                if (active <= 0) {
                    active = 0;
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
                    stopSelf();
                }
            });
        }
    }

    private HttpURLConnection connect(Job j, String range) throws IOException {
        String url = j.url;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            if (j.ua != null) c.setRequestProperty("User-Agent", j.ua);
            if (j.cookie != null) c.setRequestProperty("Cookie", j.cookie);
            if (j.referer != null) c.setRequestProperty("Referer", j.referer);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (range != null) c.setRequestProperty("Range", range);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect");
                url = new URL(new URL(url), loc).toString();
                j.url = url;
                continue;
            }
            return c;
        }
        throw new IOException("too many redirects");
    }

    private void download(Job j, File tmp) throws Exception {
        HttpURLConnection probe = connect(j, "bytes=0-0");
        int code = probe.getResponseCode();
        long total = -1;
        boolean ranges = false;
        if (code == 206) {
            String cr = probe.getHeaderField("Content-Range");
            if (cr != null && cr.contains("/")) {
                try { total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()); ranges = true; } catch (Exception ignored) {}
            }
        } else if (code == 200) {
            total = probe.getContentLengthLong();
        } else {
            probe.disconnect();
            throw new IOException("HTTP " + code);
        }
        if (j.mime == null) j.mime = probe.getContentType();
        probe.disconnect();
        j.total = total;

        if (ranges && total > 2 * 1024 * 1024) {
            int parts = total > 50L * 1024 * 1024 ? 6 : 4;
            j.parts = parts;
            try (RandomAccessFile pre = new RandomAccessFile(tmp, "rw")) { pre.setLength(total); }
            long chunk = total / parts;
            ArrayList<Future<?>> fs = new ArrayList<>();
            for (int p = 0; p < parts; p++) {
                final long s = p * chunk, e = (p == parts - 1) ? total - 1 : s + chunk - 1;
                fs.add(pool.submit(() -> { part(j, tmp, s, e); return null; }));
            }
            for (Future<?> f : fs) {
                try { f.get(); } catch (Exception ex) { j.abort = true; throw ex; }
            }
        } else {
            HttpURLConnection c = connect(j, null);
            if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
            if (j.total <= 0) j.total = c.getContentLengthLong();
            try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (j.cancel) throw new IOException("cancel");
                    out.write(buf, 0, n);
                    add(j, n);
                }
            }
        }
    }

    private void part(Job j, File tmp, long start, long end) throws IOException {
        long pos = start;
        int tries = 0;
        while (pos <= end) {
            try {
                HttpURLConnection c = connect(j, "bytes=" + pos + "-" + end);
                if (c.getResponseCode() != 206) throw new IOException("no range");
                try (InputStream in = c.getInputStream(); RandomAccessFile raf = new RandomAccessFile(tmp, "rw")) {
                    raf.seek(pos);
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (j.cancel || j.abort) throw new IOException("stop");
                        int w = (int) Math.min(n, end - pos + 1);
                        raf.write(buf, 0, w);
                        pos += w;
                        add(j, w);
                        if (pos > end) break;
                    }
                }
            } catch (IOException ex) {
                if (j.cancel || j.abort || ++tries > 4) throw ex;
                try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
            }
        }
    }

    private static void add(Job j, long n) { synchronized (j) { j.done += n; } }

    private String mimeOf(Job j) {
        String m = j.mime;
        if (m != null && m.contains(";")) m = m.substring(0, m.indexOf(';')).trim();
        if (m == null || m.isEmpty() || m.equals("application/octet-stream")) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(j.name);
            String g = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
            if (g != null) m = g;
        }
        return m == null || m.isEmpty() ? "application/octet-stream" : m;
    }

    /** Taiyaar file ko phone ke Download/Baatora folder me rakhta hai. */
    private void publish(Job j, File tmp) throws Exception {
        String mime = mimeOf(j);
        j.mime = mime;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, j.name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Baatora");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new IOException("no uri");
            try (InputStream in = new FileInputStream(tmp); OutputStream out = cr.openOutputStream(u)) {
                if (out == null) throw new IOException("no stream");
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, cv, null, null);
            j.uri = u.toString();
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Baatora");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File out = new File(dir, j.name);
            int k = 1;
            while (out.exists()) {
                String nm = j.name;
                int dot = nm.lastIndexOf('.');
                out = new File(dir, dot > 0 ? nm.substring(0, dot) + " (" + k + ")" + nm.substring(dot) : nm + " (" + k + ")");
                k++;
            }
            try (InputStream in = new FileInputStream(tmp); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            @SuppressWarnings("deprecation")
            long id = dm.addCompletedDownload(j.name, "Baatora Turbo", true, mime, out.getAbsolutePath(), out.length(), false);
            j.uri = "dm:" + id;
        }
    }

    /** Downloads page ke liye record. */
    private synchronized void record(Job j) {
        try {
            JSONArray old = Store.load(this, "turbo"), arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("id", j.id);
            o.put("name", j.name);
            o.put("uri", j.uri == null ? "" : j.uri);
            o.put("size", Math.max(j.total, j.done));
            o.put("mime", j.mime == null ? "" : j.mime);
            o.put("time", System.currentTimeMillis());
            o.put("status", j.status);
            o.put("url", j.url);
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 300; i++) arr.put(old.get(i));
            Store.prefs(this).edit().putString("turbo", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void finishedNotice(Job j, boolean ok) {
        try {
            Notification n = builder()
                    .setSmallIcon(ok ? android.R.drawable.stat_sys_download_done : android.R.drawable.stat_notify_error)
                    .setContentTitle(ok ? "Download poora hua ✅" : "Download fail hua ❌")
                    .setContentText(j.name).setAutoCancel(true).build();
            nm.notify((int) (j.id % 100000) + 100, n);
        } catch (Exception ignored) {}
    }
}
