package com.baatora.browser;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Baatora ke saare naye screens: Menu, Tabs, History, Bookmarks, Downloads, About. */
final class Screens {

    final MainActivity a;
    Screens(MainActivity a) { this.a = a; }

    static final int DARK_DIALOG = android.R.style.Theme_Material_Dialog_Alert;
    static final Pattern QUALITY = Pattern.compile("(?<![0-9])(2160|1440|1080|720|540|480|360|240|144)p?(?![0-9])");

    // ═══════════════════════ BASE BUILDERS ═══════════════════════

    static class Page { Dialog d; LinearLayout root, header; }

    Page page(String title) {
        Page p = new Page();
        p.d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        p.root = new LinearLayout(a);
        p.root.setOrientation(LinearLayout.VERTICAL);
        p.root.setBackground(Ui.pageBg());
        p.header = new LinearLayout(a);
        p.header.setOrientation(LinearLayout.HORIZONTAL);
        p.header.setGravity(Gravity.CENTER_VERTICAL);
        p.header.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        p.header.setBackground(Ui.barBg());
        final Dialog d = p.d;
        p.header.addView(Ui.iconButton(a, R.drawable.ic_back, v -> d.dismiss()), sq(48));
        TextView t = Ui.text(a, title, 20, Color.WHITE, true);
        t.setPadding(Ui.dp(6), 0, 0, 0);
        p.header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        p.root.addView(p.header, new LinearLayout.LayoutParams(-1, -2));
        View accent = new View(a);
        accent.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Ui.ORANGE, Ui.GOLD, Ui.CYAN}));
        p.root.addView(accent, new LinearLayout.LayoutParams(-1, Ui.dp(2)));
        p.d.setContentView(p.root, new ViewGroup.LayoutParams(-1, -1));
        Window w = p.d.getWindow();
        if (w != null) {
            w.setStatusBarColor(Ui.BAR1);
            w.setNavigationBarColor(Ui.DEEP);
            MainActivity.lightBars(w);
            w.setWindowAnimations(android.R.style.Animation_Dialog);
        }
        return p;
    }

    LinearLayout sheetBox() {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(22));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.NAVY2, Ui.PAGE1, Ui.NAVY});
        float r = Ui.dp(28);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bg);
        View handle = new View(a);
        handle.setBackground(Ui.round(Ui.gl(0x66), 3));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(5));
        hl.gravity = Gravity.CENTER_HORIZONTAL;
        hl.bottomMargin = Ui.dp(12);
        box.addView(handle, hl);
        return box;
    }

    Dialog showSheet(View content) {
        Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
        }
        return d;
    }

    TextView sheetTitle(String s) {
        TextView t = Ui.text(a, s, 17, Ui.GOLD, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, Ui.dp(12));
        return t;
    }

    /** Gol rangeen icon + naam wala button (Settings / About / Exit). */
    View iconPill(int icon, int[] colors, String label, Drawable bg, int textColor, View.OnClickListener l) {
        LinearLayout p = new LinearLayout(a);
        p.setOrientation(LinearLayout.HORIZONTAL);
        p.setGravity(Gravity.CENTER);
        p.setPadding(Ui.dp(6), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        p.setBackground(bg);
        FrameLayout ic = new FrameLayout(a);
        GradientDrawable cb = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        cb.setShape(GradientDrawable.OVAL);
        ic.setBackground(cb);
        ic.setElevation(Ui.dp(3));
        boolean whiteBg = colors[0] == 0xFFFFFFFF;
        ImageView iv = Ui.icon(a, icon, whiteBg ? 0xFFC62828 : 0xFFFFFFFF);
        iv.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        ic.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        p.addView(ic, sq(32));
        TextView t = Ui.text(a, label, 14, textColor, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setPadding(Ui.dp(7), 0, 0, 0);
        p.addView(t, new LinearLayout.LayoutParams(-2, -2));
        p.setOnClickListener(l);
        Ui.ripple(p, false);
        return p;
    }

    TextView pill(String s, Drawable bg, int textColor, View.OnClickListener l) {
        TextView t = Ui.text(a, s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(10), Ui.dp(13), Ui.dp(10), Ui.dp(13));
        t.setBackground(bg);
        t.setOnClickListener(l);
        Ui.ripple(t, false);
        return t;
    }

    EditText searchBox(String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Color.WHITE);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setBackground(Ui.stroke(Ui.round(Ui.gl(0x22), 28), (Ui.GOLD & 0xFFFFFF) | 0x77000000, 1.5f));
        e.setPadding(Ui.dp(18), Ui.dp(13), Ui.dp(18), Ui.dp(13));
        Drawable ic = a.getDrawable(R.drawable.ic_search);
        if (ic != null) {
            ic = ic.mutate();
            ic.setTint(Ui.GOLD);
            e.setCompoundDrawablesRelativeWithIntrinsicBounds(ic, null, null, null);
            e.setCompoundDrawablePadding(Ui.dp(10));
        }
        return e;
    }

    LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(18), Ui.dp(16), Ui.dp(18), Ui.dp(18));
        c.setBackground(Ui.stroke(Ui.round(Ui.gl(0x16), 22), Ui.gl(0x26), 1));
        if (title != null) {
            TextView t = Ui.text(a, title, 15, Ui.GOLD, true);
            t.setPadding(0, 0, 0, Ui.dp(8));
            c.addView(t);
        }
        return c;
    }

    TextView para(String s) {
        TextView t = Ui.text(a, s, 14.5f, 0xFFDDE5FF, false);
        t.setLineSpacing(0, 1.35f);
        return t;
    }

    View empty(int icon, String title, String sub) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(20), Ui.dp(70), Ui.dp(20), Ui.dp(20));
        c.addView(Ui.iconTile(a, icon, Ui.PALETTE[1], 84), sq(84));
        TextView t = Ui.text(a, title, 18, Color.WHITE, true);
        t.setPadding(0, Ui.dp(18), 0, Ui.dp(6));
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        TextView s = Ui.text(a, sub, 13.5f, Ui.MUTED, false);
        s.setGravity(Gravity.CENTER);
        c.addView(s);
        return c;
    }

    void confirm(String title, String msg, String ok, Runnable r) {
        confirm(R.drawable.ic_delete, new int[]{0xFFFF6E6E, 0xFFC62828}, title, msg, ok, r);
    }

    /** Naya sundar confirm box: chamakta icon, bade gol buttons. */
    void confirm(int icon, int[] colors, String title, String msg, String ok, Runnable r) {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(22), Ui.dp(26), Ui.dp(22), Ui.dp(20));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.NAVY2, Ui.PAGE1, Ui.NAVY});
        bg.setCornerRadius(Ui.dp(30));
        bg.setStroke(Ui.dp(1), Ui.gl(0x33));
        box.setBackground(bg);

        FrameLayout glow = new FrameLayout(a);
        GradientDrawable halo = new GradientDrawable();
        halo.setShape(GradientDrawable.OVAL);
        halo.setColor((colors[0] & 0x00FFFFFF) | 0x33000000);
        glow.setBackground(halo);
        glow.addView(Ui.iconTile(a, icon, colors, 62), new FrameLayout.LayoutParams(Ui.dp(62), Ui.dp(62), Gravity.CENTER));
        box.addView(glow, sq(96));

        TextView t = Ui.text(a, title, 20, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView m = Ui.text(a, msg, 14.5f, 0xFFD5DEFF, false);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(0, 1.3f);
        box.addView(m, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout btns = new LinearLayout(a);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, Ui.dp(22), 0, 0);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, -2, 1f);
        b1.rightMargin = Ui.dp(6);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, -2, 1f);
        b2.leftMargin = Ui.dp(6);
        btns.addView(pill(L.t("cancel"), Ui.stroke(Ui.round(Ui.gl(0x1F), 26), Ui.gl(0x33), 1), Color.WHITE, v -> d.dismiss()), b1);
        btns.addView(pill(ok, Ui.grad(colors[0], colors[1], 26), Ui.ON_COLOR, v -> { d.dismiss(); r.run(); }), b2);
        box.addView(btns, new LinearLayout.LayoutParams(-1, -2));

        d.setContentView(box);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (a.getResources().getDisplayMetrics().widthPixels * 0.88f), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        box.setScaleX(0.85f);
        box.setScaleY(0.85f);
        box.setAlpha(0f);
        box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.2f)).start();
    }

    static LinearLayout.LayoutParams sq(int sizeDp) {
        return new LinearLayout.LayoutParams(Ui.dp(sizeDp), Ui.dp(sizeDp));
    }

    static LinearLayout.LayoutParams rowLp(int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Ui.dp(bottomDp);
        return lp;
    }

    ImageView logoView() {
        ImageView iv = new ImageView(a);
        iv.setImageResource(R.drawable.logo);
        iv.setBackground(Ui.round(Ui.NAVY, 12));
        iv.setClipToOutline(true);
        return iv;
    }

    // ═══════════════════════ 3-DOTS MENU ═══════════════════════

    static class Item {
        final int icon; final String label; final int[] colors; final boolean active; final Runnable run;
        Item(int i, String l, int[] c, boolean act, Runnable r) { icon = i; label = l; colors = c; active = act; run = r; }
    }

    String appVer() {
        try { return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; }
        catch (Exception e) { return "6.8"; }
    }

    static int[] P(int i) { return Ui.PALETTE[i % Ui.PALETTE.length]; }

    void menu() {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();

        // ── Header: logo, naam, bell, settings ──
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(2), 0, 0, Ui.dp(14));
        ImageView lg = logoView();
        lg.setBackground(Ui.round(Ui.NAVY, 16));
        head.addView(lg, sq(48));
        LinearLayout hc = new LinearLayout(a);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.setPadding(Ui.dp(12), 0, 0, 0);
        hc.addView(Ui.text(a, "Baatora", 20, Color.WHITE, true));
        TextView hs = Ui.text(a, (a.vpnActive() ? "🛡 VPN ON  •  " : "") + "Made in India 🇮🇳", 12, Ui.GOLD, false);
        hc.addView(hs);
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(circleBtn(R.drawable.ic_bell, a.unreadNotifs(), v -> { dh[0].dismiss(); notifications(); }), sq(44));
        View gap = new View(a);
        head.addView(gap, new LinearLayout.LayoutParams(Ui.dp(8), 1));
        head.addView(circleBtn(R.drawable.ic_settings, 0, v -> { dh[0].dismiss(); settings(); }), sq(44));
        box.addView(head);

        // ── Aaj ka data + roke gaye ads ──
        LinearLayout stats = new LinearLayout(a);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, 0, 0, Ui.dp(12));
        long data = Store.dataToday(a);
        stats.addView(statChip("📊", L.t("data_today"), data < 0 ? "—" : Formatter.formatFileSize(a, data), P(1)),
                new LinearLayout.LayoutParams(0, -2, 1f));
        View sp = new View(a);
        stats.addView(sp, new LinearLayout.LayoutParams(Ui.dp(8), 1));
        stats.addView(statChip(R.drawable.ic_adblock, L.t("ads_blocked"), String.valueOf(Store.adsToday(a)), new int[]{0xFF69F0AE, 0xFF00A152}),
                new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(stats);

        // ── Light / Dark / System default ──
        LinearLayout modes = new LinearLayout(a);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modes.setPadding(Ui.dp(5), Ui.dp(5), Ui.dp(5), Ui.dp(5));
        modes.setBackground(Ui.stroke(Ui.round(Ui.gl(0x12), 22), Ui.gl(0x1F), 1));
        String[][] mm = {{"light", "☀", L.t("mode_light")}, {"dark", "🌙", L.t("mode_dark")}, {"default", "📱", L.t("mode_default")}};
        int[] th = Ui.THEMES[Ui.themeIdx];
        for (final String[] md : mm) {
            boolean sel = Ui.MODE.equals(md[0]);
            LinearLayout opt = new LinearLayout(a);
            opt.setOrientation(LinearLayout.HORIZONTAL);
            opt.setGravity(Gravity.CENTER);
            opt.setPadding(Ui.dp(6), Ui.dp(10), Ui.dp(6), Ui.dp(10));
            if (sel) opt.setBackground(Ui.grad(Ui.GOLD, Ui.ORANGE, 18));
            View sw = new View(a);
            GradientDrawable sg = md[0].equals("light") ? Ui.round(Color.WHITE, 9)
                    : md[0].equals("dark") ? Ui.round(0xFF111111, 9)
                    : new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{th[6], th[2]});
            sg.setShape(GradientDrawable.OVAL);
            sg.setStroke(Ui.dp(1.5f), sel ? Ui.INK : Ui.gl(0x55));
            sw.setBackground(sg);
            opt.addView(sw, sq(18));
            TextView t = Ui.text(a, md[2], 12.5f, sel ? Ui.INK : Color.WHITE, true);
            t.setPadding(Ui.dp(6), 0, 0, 0);
            t.setSingleLine(true);
            opt.addView(t);
            opt.setOnClickListener(v -> {
                dh[0].dismiss();
                a.setMode(md[0]);
                menu();
            });
            Ui.ripple(opt, false);
            modes.addView(opt, new LinearLayout.LayoutParams(0, -2, md[0].equals("default") ? 1.35f : 1f));
        }
        box.addView(modes, rowLp(14));

        // ── 4 bade quick action ──
        LinearLayout quick = new LinearLayout(a);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        Object[][] q = {
                {R.drawable.ic_add, L.t("new_tab"), P(0), (Runnable) () -> a.createTab(MainActivity.HOME, false, true)},
                {R.drawable.ic_incognito, L.t("incognito"), P(4), (Runnable) () -> a.openIncognito()},
                {R.drawable.ic_star, L.t("add_bookmark"), P(5), (Runnable) a::addBookmark},
                {R.drawable.ic_share, L.t("share"), P(2), (Runnable) () -> { if (a.web() != null) a.share(a.web().getUrl()); }}
        };
        for (Object[] it : q) {
            final Runnable run = (Runnable) it[3];
            int[] col = (int[]) it[2];
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(Ui.dp(4), Ui.dp(14), Ui.dp(4), Ui.dp(12));
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{col[0], col[1]});
            g.setCornerRadius(Ui.dp(22));
            cell.setBackground(g);
            cell.setElevation(Ui.dp(6));
            ImageView ic = Ui.icon(a, (int) it[0], Color.WHITE);
            cell.addView(ic, sq(28));
            TextView lb = Ui.text(a, (String) it[1], 11.5f, Ui.ON_COLOR, true);
            lb.setGravity(Gravity.CENTER);
            lb.setMaxLines(2);
            lb.setPadding(0, Ui.dp(6), 0, 0);
            cell.addView(lb, new LinearLayout.LayoutParams(-1, -2));
            cell.setOnClickListener(v -> { dh[0].dismiss(); run.run(); });
            Ui.ripple(cell, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
            quick.addView(cell, lp);
        }
        box.addView(quick);

        // ── Toggle chips ──
        TextView tq = Ui.text(a, L.t("quick_toggles"), 13, Ui.MUTED, true);
        tq.setPadding(Ui.dp(4), Ui.dp(16), 0, Ui.dp(8));
        box.addView(tq);
        HorizontalScrollView hsv = new HorizontalScrollView(a);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(chips);
        Object[][] tg = {
                {R.drawable.ic_moon, L.t("night"), a.on("night", false), (Runnable) a::toggleNight},
                {R.drawable.ic_adblock, L.t("adblock"), a.adBlock, (Runnable) a::toggleAdBlock},
                {R.drawable.ic_flash, L.t("datasaver"), a.on("datasaver", false), (Runnable) a::toggleDataSaver},
                {R.drawable.ic_desktop, L.t("desktop"), a.on("desktop", false), (Runnable) a::toggleDesktop},
                {R.drawable.ic_refresh, L.t("pull"), a.on("pull", true), (Runnable) a::togglePull}
        };
        for (Object[] it : tg) {
            final Runnable run = (Runnable) it[3];
            boolean on = (boolean) it[2];
            LinearLayout chip = new LinearLayout(a);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(Ui.dp(12), Ui.dp(9), Ui.dp(16), Ui.dp(9));
            chip.setBackground(on ? Ui.grad(Ui.GOLD, Ui.ORANGE, 22) : Ui.stroke(Ui.round(Ui.gl(0x14), 22), Ui.gl(0x33), 1));
            chip.addView(Ui.icon(a, (int) it[0], on ? Ui.INK : Ui.ICON), sq(18));
            TextView t = Ui.text(a, (String) it[1] + (on ? "  ✓" : ""), 13, on ? Ui.INK : Color.WHITE, true);
            t.setPadding(Ui.dp(8), 0, 0, 0);
            chip.addView(t);
            chip.setOnClickListener(v -> { dh[0].dismiss(); run.run(); });
            Ui.ripple(chip, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(8);
            chips.addView(chip, lp);
        }
        box.addView(hsv);

        // ── Tools grid ──
        TextView tt = Ui.text(a, L.t("tools"), 13, Ui.MUTED, true);
        tt.setPadding(Ui.dp(4), Ui.dp(16), 0, Ui.dp(8));
        box.addView(tt);
        ArrayList<Item> m = new ArrayList<>();
        m.add(new Item(R.drawable.ic_star, "Baatora AI", new int[]{0xFF7C4DFF, 0xFFFF4081}, false, () -> a.ai.open()));
        m.add(new Item(R.drawable.ic_vpn, L.t("vpn"), new int[]{0xFF69F0AE, 0xFF00A152}, a.vpnActive(), this::vpn));
        m.add(new Item(R.drawable.ic_bookmark, L.t("bookmarks"), P(2), false, () -> list("bookmarks")));
        m.add(new Item(R.drawable.ic_history, L.t("history"), P(1), false, () -> list("history")));
        m.add(new Item(R.drawable.ic_download, L.t("downloads"), P(6), false, this::downloads));
        m.add(new Item(R.drawable.ic_video, L.t("video_dl"), P(3), false, this::videoDownload));
        m.add(new Item(R.drawable.ic_book, L.t("reader"), P(5), false, a::readerMode));
        m.add(new Item(R.drawable.ic_speaker, L.t("read_aloud"), P(4), false, a::readAloud));
        m.add(new Item(R.drawable.ic_translate, L.t("translate"), P(1), false, a::translatePage));
        m.add(new Item(R.drawable.ic_camera, L.t("screenshot"), P(7), false, a::screenshot));
        m.add(new Item(R.drawable.ic_addhome, L.t("add_home"), P(0), false, a::addToHome));
        m.add(new Item(R.drawable.ic_doc, L.t("pdf"), P(3), false, a::savePdf));
        m.add(new Item(R.drawable.ic_tabs, L.t("recent"), P(2), false, this::recentSheet));
        m.add(new Item(R.drawable.ic_copy, L.t("copy_link"), P(6), false, () -> { if (a.web() != null) a.copy(a.web().getUrl()); }));
        m.add(new Item(R.drawable.ic_code, L.t("source"), P(4), false, a::pageSource));
        m.add(new Item(R.drawable.ic_fullscreen, L.t("fullscreen"), P(5), false, () -> a.setAppFull(true)));
        m.add(new Item(R.drawable.ic_textsize, L.t("textsize"), P(0), false, () -> a.chooseTextSize(null)));

        GridLayout grid = new GridLayout(a);
        grid.setColumnCount(4);
        for (final Item it : m) {
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(Ui.dp(2), Ui.dp(12), Ui.dp(2), Ui.dp(10));
            GradientDrawable cb = Ui.round(Ui.gl(0x12), 20);
            cb.setStroke(Ui.dp(it.active ? 2 : 1), it.active ? 0xFF69F0AE : Ui.gl(0x1F));
            cell.setBackground(cb);
            FrameLayout circ = new FrameLayout(a);
            GradientDrawable cg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, it.colors);
            cg.setShape(GradientDrawable.OVAL);
            circ.setBackground(cg);
            ImageView ic = Ui.icon(a, it.icon, Color.WHITE);
            ic.setPadding(Ui.dp(9), Ui.dp(9), Ui.dp(9), Ui.dp(9));
            circ.addView(ic, new FrameLayout.LayoutParams(-1, -1));
            cell.addView(circ, sq(42));
            TextView lb = Ui.text(a, it.label + (it.active ? " ✓" : ""), 11, it.active ? 0xFF69F0AE : Color.WHITE, it.active);
            lb.setGravity(Gravity.CENTER);
            lb.setMaxLines(2);
            lb.setPadding(0, Ui.dp(6), 0, 0);
            cell.addView(lb, new LinearLayout.LayoutParams(-1, -2));
            cell.setOnClickListener(v -> { dh[0].dismiss(); it.run.run(); });
            Ui.ripple(cell, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.setMargins(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
            grid.addView(cell, lp);
        }

        // ── Neeche: Settings | About | Exit ──
        LinearLayout bottom = new LinearLayout(a);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(0, Ui.dp(12), 0, 0);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, -2, 1f);
        bl.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
        bottom.addView(iconPill(R.drawable.ic_settings, new int[]{0xFF448AFF, 0xFF1A3FD8}, L.t("settings"),
                Ui.stroke(Ui.round(Ui.gl(0x1A), 26), Ui.gl(0x33), 1), Color.WHITE,
                v -> { dh[0].dismiss(); settings(); }), bl);
        LinearLayout.LayoutParams bl2 = new LinearLayout.LayoutParams(0, -2, 1f);
        bl2.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
        bottom.addView(iconPill(R.drawable.ic_info, new int[]{0xFFFFC107, 0xFFFF8A00}, L.t("about"),
                Ui.stroke(Ui.round(Ui.gl(0x1A), 26), Ui.gl(0x33), 1), Color.WHITE,
                v -> { dh[0].dismiss(); about(); }), bl2);
        LinearLayout.LayoutParams bl3 = new LinearLayout.LayoutParams(0, -2, 1f);
        bl3.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
        bottom.addView(iconPill(R.drawable.ic_power, new int[]{0xFFFFFFFF, 0xFFFFE0E0}, L.t("exit"),
                Ui.grad(0xFFFF5F6D, 0xFFC62828, 26), Ui.ON_COLOR,
                v -> { dh[0].dismiss(); a.finish(); }), bl3);

        LinearLayout inner = new LinearLayout(a);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.addView(grid);
        inner.addView(bottom);
        ScrollView sv = new ScrollView(a);
        sv.addView(inner);
        box.addView(sv);
        dh[0] = showSheet(box);
    }

    View statChip(int icon, String label, String value, int[] colors) {
        LinearLayout c = (LinearLayout) statChip("", label, value, colors);
        TextView e = (TextView) c.getChildAt(0);
        c.removeViewAt(0);
        FrameLayout f = new FrameLayout(a);
        f.setBackground(e.getBackground());
        ImageView iv = Ui.icon(a, icon, Color.WHITE);
        iv.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        c.addView(f, 0, sq(32));
        return c;
    }

    View statChip(String emoji, String label, String value, int[] colors) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(Ui.dp(10), Ui.dp(9), Ui.dp(10), Ui.dp(9));
        c.setBackground(Ui.stroke(Ui.round(Ui.gl(0x14), 16), (colors[0] & 0x00FFFFFF) | 0x55000000, 1));
        TextView e = Ui.text(a, emoji, 16, Color.WHITE, false);
        e.setGravity(Gravity.CENTER);
        e.setBackground(Ui.grad(colors[0], colors[1], 12));
        c.addView(e, sq(32));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(8), 0, 0, 0);
        col.addView(Ui.text(a, value, 14.5f, Color.WHITE, true));
        TextView l = Ui.text(a, label, 10.5f, Ui.MUTED, false);
        l.setSingleLine(true);
        col.addView(l);
        c.addView(col);
        return c;
    }

    /** Chhota glass gol button, badge ke saath. */
    View circleBtn(int icon, int badge, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(a);
        f.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1F), 22), Ui.gl(0x33), 1));
        ImageView iv = Ui.icon(a, icon, Ui.ICON);
        iv.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        if (badge > 0) {
            TextView b = Ui.text(a, badge > 9 ? "9+" : String.valueOf(badge), 10, Ui.ON_COLOR, true);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Ui.stroke(Ui.round(0xFFFF3D3D, 10), Ui.NAVY, 2));
            f.addView(b, new FrameLayout.LayoutParams(Ui.dp(20), Ui.dp(20), Gravity.TOP | Gravity.END));
        }
        f.setOnClickListener(l);
        Ui.ripple(f, true);
        return f;
    }

    // ═══════════════════════ TABS (Chrome jaisa) ═══════════════════════

    static final int TAB_GRID = 0, TAB_CAROUSEL = 1, TAB_LIST = 2;

    void tabs() {
        a.captureThumb(a.cur());
        final Dialog d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Ui.pageBg());

        final boolean[] incog = {a.cur() != null && a.cur().incognito};
        final String[] q = {""};
        final int[] mode = {Math.max(0, Math.min(2, a.prefs.getInt("tab_layout", TAB_GRID)))};
        final Runnable[] render = new Runnable[1];

        // Upar: [gintee | incognito] segment beech me
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(10));
        TextView ttl = Ui.text(a, "Tabs", 22, Color.WHITE, true);
        top.addView(ttl, new LinearLayout.LayoutParams(0, -2, 1f));

        // ── Normal | Incognito: do sundar pill button (icon + naam + ginti) ──
        LinearLayout seg = new LinearLayout(a);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setGravity(Gravity.CENTER_VERTICAL);
        seg.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
        seg.setBackground(Ui.stroke(Ui.round(Ui.gl(0x18), 28), Ui.gl(0x2A), 1));
        final LinearLayout normalWrap = new LinearLayout(a);
        normalWrap.setOrientation(LinearLayout.HORIZONTAL);
        normalWrap.setGravity(Gravity.CENTER);
        normalWrap.setPadding(Ui.dp(12), 0, Ui.dp(14), 0);
        final ImageView normIc = Ui.icon(a, R.drawable.ic_tabs, Color.WHITE);
        normalWrap.addView(normIc, sq(18));
        final TextView count = Ui.text(a, "0", 14, Color.WHITE, true);
        count.setPadding(Ui.dp(7), 0, 0, 0);
        normalWrap.addView(count);
        final LinearLayout incogWrap = new LinearLayout(a);
        incogWrap.setOrientation(LinearLayout.HORIZONTAL);
        incogWrap.setGravity(Gravity.CENTER);
        incogWrap.setPadding(Ui.dp(12), 0, Ui.dp(14), 0);
        final ImageView incogIc = Ui.icon(a, R.drawable.ic_incognito, Color.WHITE);
        incogWrap.addView(incogIc, sq(20));
        final TextView icount = Ui.text(a, "0", 14, Color.WHITE, true);
        icount.setPadding(Ui.dp(7), 0, 0, 0);
        incogWrap.addView(icount);
        seg.addView(normalWrap, new LinearLayout.LayoutParams(-2, Ui.dp(42)));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-2, Ui.dp(42));
        ilp.leftMargin = Ui.dp(4);
        seg.addView(incogWrap, ilp);
        Ui.ripple(normalWrap, false);
        Ui.ripple(incogWrap, false);
        // Tap: seedha wahi mode chalu (aakhri tab ya naya). Lamba dabao: sirf us mode ke tabs ki list.
        normalWrap.setOnClickListener(v -> openMode(false, d));
        incogWrap.setOnClickListener(v -> openMode(true, d));
        normalWrap.setOnLongClickListener(v -> { incog[0] = false; render[0].run(); return true; });
        incogWrap.setOnLongClickListener(v -> { incog[0] = true; render[0].run(); return true; });
        top.addView(seg);
        root.addView(top);

        EditText search = searchBox(L.t("search_tabs"));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(8));
        root.addView(search, slp);

        final TextView hint = Ui.text(a, L.t("tabs_hint"), 12, Ui.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 0, 0, Ui.dp(6));
        hint.setVisibility(View.GONE);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        final FrameLayout holder = new FrameLayout(a);
        root.addView(holder, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ── Neeche ki patti (Opera jaisi): layout badlo | history | + | gintee | ⋮ ──
        LinearLayout bottom = new LinearLayout(a);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(4));
        bottom.setBackground(Ui.stroke(Ui.round(Ui.LIGHT ? 0xFFFFFFFF : Ui.gl(0x22), 34), Ui.gl(0x22), 1));
        bottom.setElevation(Ui.dp(8));

        final ImageView layoutBtn = Ui.iconButton(a, R.drawable.ic_view_carousel, null);
        bottom.addView(layoutBtn, new LinearLayout.LayoutParams(0, Ui.dp(58), 1f));
        ImageView histBtn = Ui.iconButton(a, R.drawable.ic_history, v -> { d.dismiss(); list("history"); });
        bottom.addView(histBtn, new LinearLayout.LayoutParams(0, Ui.dp(58), 1f));

        FrameLayout plus = new FrameLayout(a);
        GradientDrawable plusBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.ORANGE, 0xFF1E5BFF});
        plusBg.setShape(GradientDrawable.OVAL);
        plus.setBackground(plusBg);
        plus.setElevation(Ui.dp(10));
        ImageView plusIc = Ui.icon(a, R.drawable.ic_add, 0xFFFFFFFF);
        plusIc.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(14));
        plus.addView(plusIc, new FrameLayout.LayoutParams(-1, -1));
        Ui.ripple(plus, true);
        plus.setOnClickListener(v -> { d.dismiss(); a.createTab(incog[0] ? MainActivity.INCOG_HOME : MainActivity.HOME, incog[0], true); });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(Ui.dp(56), Ui.dp(56));
        plp.setMargins(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4));
        bottom.addView(plus, plp);

        FrameLayout cntWrap = new FrameLayout(a);
        final TextView cnt = Ui.text(a, "1", 13, Ui.ICON, true);
        cnt.setGravity(Gravity.CENTER);
        cnt.setBackground(Ui.stroke(Ui.round(0x00000000, 6), Ui.ICON, 2));
        cntWrap.addView(cnt, new FrameLayout.LayoutParams(Ui.dp(26), Ui.dp(26), Gravity.CENTER));
        Ui.ripple(cntWrap, true);
        cntWrap.setOnClickListener(v -> d.dismiss());
        bottom.addView(cntWrap, new LinearLayout.LayoutParams(0, Ui.dp(58), 1f));

        final ImageView more = Ui.iconButton(a, R.drawable.ic_more, null);
        more.setOnClickListener(v -> {
            LinearLayout box = sheetBox();
            box.addView(sheetTitle("Tabs ke vikalp"));
            final Dialog[] sd = new Dialog[1];
            // Design chunne ke 3 sundar cards
            TextView dl = Ui.text(a, "DESIGN", 11.5f, Ui.MUTED, true);
            dl.setPadding(Ui.dp(4), Ui.dp(6), 0, Ui.dp(8));
            box.addView(dl);
            LinearLayout drow = new LinearLayout(a);
            drow.setOrientation(LinearLayout.HORIZONTAL);
            Object[][] ds = {{R.drawable.ic_view_grid, "Grid", TAB_GRID, new int[]{0xFF448AFF, 0xFF1A3FD8}},
                    {R.drawable.ic_view_carousel, "Carousel", TAB_CAROUSEL, new int[]{0xFFB388FF, 0xFF6200EA}},
                    {R.drawable.ic_view_list, "List", TAB_LIST, new int[]{0xFF64FFDA, 0xFF00897B}}};
            for (Object[] dd : ds) {
                final int m = (int) dd[2];
                boolean sel = mode[0] == m;
                LinearLayout cell = new LinearLayout(a);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(Ui.dp(6), Ui.dp(14), Ui.dp(6), Ui.dp(12));
                cell.setBackground(sel ? Ui.stroke(Ui.round(Ui.gl(0x22), 20), Ui.ORANGE, 2) : Ui.stroke(Ui.round(Ui.gl(0x12), 20), Ui.gl(0x26), 1));
                FrameLayout ic = Ui.iconTile(a, (int) dd[0], (int[]) dd[3], 46);
                cell.addView(ic, sq(46));
                TextView tl = Ui.text(a, (String) dd[1] + (sel ? "  ✓" : ""), 13, Color.WHITE, true);
                tl.setPadding(0, Ui.dp(8), 0, 0);
                cell.addView(tl);
                cell.setOnClickListener(x -> {
                    mode[0] = m;
                    a.prefs.edit().putInt("tab_layout", m).apply();
                    sd[0].dismiss();
                    render[0].run();
                });
                Ui.ripple(cell, false);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
                cl.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
                drow.addView(cell, cl);
            }
            box.addView(drow);
            TextView al = Ui.text(a, "TABS", 11.5f, Ui.MUTED, true);
            al.setPadding(Ui.dp(4), Ui.dp(18), 0, Ui.dp(8));
            box.addView(al);
            Object[][] acts = {{R.drawable.ic_close, "Sab tabs band karein", "Saare normal aur incognito tabs", new int[]{0xFFFF6E6E, 0xFFC62828}, 1},
                    {R.drawable.ic_incognito, "Incognito tabs band karein", "Sirf private tabs", new int[]{0xFFB388FF, 0xFF6200EA}, 2},
                    {R.drawable.ic_add, "Naya Incognito tab", "Bina history ke browsing", new int[]{0xFF7C4DFF, 0xFF3A1270}, 3}};
            for (Object[] ac : acts) {
                final int id = (int) ac[4];
                LinearLayout r = baseRow((int) ac[0], (int[]) ac[3], (String) ac[1], (String) ac[2]);
                r.setPadding(Ui.dp(6), Ui.dp(10), Ui.dp(6), Ui.dp(10));
                r.setOnClickListener(x -> {
                    sd[0].dismiss();
                    if (id == 3) { d.dismiss(); a.createTab(MainActivity.INCOG_HOME, true, true); return; }
                    boolean onlyIncog = id == 2;
                    for (int i = a.tabs.size() - 1; i >= 0; i--) {
                        if (!onlyIncog || a.tabs.get(i).incognito) a.closeTab(i);
                    }
                    render[0].run();
                });
                Ui.ripple(r, false);
                box.addView(r);
            }
            sd[0] = showSheet(box);
        });
        bottom.addView(more, new LinearLayout.LayoutParams(0, Ui.dp(58), 1f));

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.setMargins(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(14));
        root.addView(bottom, blp);

        layoutBtn.setOnClickListener(v -> {
            // Grid → Carousel → List → Grid
            mode[0] = mode[0] == TAB_GRID ? TAB_CAROUSEL : mode[0] == TAB_CAROUSEL ? TAB_LIST : TAB_GRID;
            a.prefs.edit().putInt("tab_layout", mode[0]).apply();
            layoutBtn.animate().rotationBy(180f).setDuration(250).start();
            render[0].run();
        });

        render[0] = () -> {
            holder.removeAllViews();
            int normal = 0;
            for (MainActivity.Tab t : a.tabs) if (!t.incognito) normal++;
            count.setText(String.valueOf(normal));
            cnt.setText(String.valueOf(a.tabs.size()));
            // Button par agle design ka nishaan (Opera jaisa)
            layoutBtn.setImageResource(mode[0] == TAB_GRID ? R.drawable.ic_view_carousel
                    : mode[0] == TAB_CAROUSEL ? R.drawable.ic_view_list : R.drawable.ic_view_grid);
            hint.setText(mode[0] == TAB_CAROUSEL ? "👆  Tab band karne ke liye upar swipe karein" : L.t("tabs_hint"));
            int inc = 0;
            for (MainActivity.Tab t : a.tabs) if (t.incognito) inc++;
            icount.setText(String.valueOf(inc));
            GradientDrawable nOn = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF448AFF, 0xFF1A3FD8});
            nOn.setCornerRadius(Ui.dp(22));
            GradientDrawable iOn = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFB388FF, 0xFF6200EA});
            iOn.setCornerRadius(Ui.dp(22));
            normalWrap.setBackground(!incog[0] ? nOn : null);
            incogWrap.setBackground(incog[0] ? iOn : null);
            normalWrap.setElevation(!incog[0] ? Ui.dp(4) : 0);
            incogWrap.setElevation(incog[0] ? Ui.dp(4) : 0);
            normIc.setColorFilter(!incog[0] ? 0xFFFFFFFF : Ui.ICON);
            count.setTextColor(!incog[0] ? 0xFFFFFFFF : Ui.TEXT);
            incogIc.setColorFilter(incog[0] ? 0xFFFFFFFF : Ui.ICON);
            icount.setTextColor(incog[0] ? 0xFFFFFFFF : Ui.TEXT);
            String query = q[0].toLowerCase();
            ArrayList<MainActivity.Tab> shown = new ArrayList<>();
            for (MainActivity.Tab t : a.tabs) {
                if (t.incognito != incog[0]) continue;
                String u = t.web.getUrl();
                String title = tabTitle(t);
                if (!query.isEmpty() && !(title + " " + u).toLowerCase().contains(query)) continue;
                shown.add(t);
            }
            if (shown.isEmpty()) {
                View e = empty(incog[0] ? R.drawable.ic_incognito : R.drawable.ic_tabs,
                        incog[0] ? "Koi Incognito tab nahi" : "Koi tab nahi mila",
                        incog[0] ? "Neeche + dabakar Incognito tab kholein" : "Neeche + dabakar naya tab kholein");
                holder.addView(e, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
                return;
            }
            if (mode[0] == TAB_CAROUSEL) {
                holder.addView(carousel(shown, d, render[0]), new FrameLayout.LayoutParams(-1, -1));
            } else if (mode[0] == TAB_LIST) {
                ScrollView sv = new ScrollView(a);
                LinearLayout col = new LinearLayout(a);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setPadding(Ui.dp(14), Ui.dp(4), Ui.dp(14), Ui.dp(20));
                for (MainActivity.Tab t : shown) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(96));
                    lp.bottomMargin = Ui.dp(12);
                    col.addView(tabRow(t, d, render[0]), lp);
                }
                sv.addView(col);
                holder.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            } else {
                ScrollView sv = new ScrollView(a);
                GridLayout grid = new GridLayout(a);
                grid.setColumnCount(2);
                grid.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(24));
                for (MainActivity.Tab t : shown) {
                    GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                            GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
                    lp.width = 0;
                    lp.setMargins(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
                    grid.addView(tabCard(t, d, render[0]), lp);
                }
                sv.addView(grid);
                holder.addView(sv, new FrameLayout.LayoutParams(-1, -1));
            }
            holder.setAlpha(0f);
            holder.setTranslationY(Ui.dp(14));
            holder.animate().alpha(1f).translationY(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
        };

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int x, int y, int z) {}
            public void onTextChanged(CharSequence s, int x, int y, int z) {}
            public void afterTextChanged(Editable s) { q[0] = s.toString().trim(); render[0].run(); }
        });

        d.setContentView(root, new ViewGroup.LayoutParams(-1, -1));
        Window w = d.getWindow();
        if (w != null) { w.setStatusBarColor(Ui.PAGE1); w.setNavigationBarColor(Ui.DEEP); MainActivity.lightBars(w); }
        d.show();
        render[0].run();
    }

    /** Normal ya Incognito par tap: us mode ka aakhri tab kholo, na ho to naya. */
    void openMode(boolean incognito, Dialog d) {
        int idx = -1;
        for (int i = a.tabs.size() - 1; i >= 0; i--) if (a.tabs.get(i).incognito == incognito) { idx = i; break; }
        d.dismiss();
        if (idx >= 0) a.switchTab(idx);
        else a.createTab(incognito ? MainActivity.INCOG_HOME : MainActivity.HOME, incognito, true);
        a.toast(incognito ? "🕶 Incognito chalu" : "🌐 Normal browsing");
    }

    /** Page ki tasveer: chaudai ke hisaab se upar se dikhayi jaati hai. */
    View thumbView(final MainActivity.Tab t, boolean home, String title, String host, int iconDp, float radius) {
        FrameLayout thumb = new FrameLayout(a);
        thumb.setBackground(Ui.grad(Ui.NAVY2, Ui.NAVY, radius));
        thumb.setClipToOutline(true);
        if (t.thumb != null) {
            final ImageView iv = new ImageView(a);
            iv.setImageBitmap(t.thumb);
            iv.setScaleType(ImageView.ScaleType.MATRIX);
            thumb.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            iv.addOnLayoutChangeListener((v, l, tp, r, b, ol, ot, or, ob) -> {
                if (t.thumb == null || t.thumb.getWidth() == 0 || iv.getWidth() == 0) return;
                float s = iv.getWidth() / (float) t.thumb.getWidth();
                Matrix mx = new Matrix();
                mx.setScale(s, s);
                iv.setImageMatrix(mx);
            });
        } else {
            View big = home ? logoView() : Ui.siteIcon(a, title, host, iconDp);
            thumb.addView(big, new FrameLayout.LayoutParams(Ui.dp(iconDp), Ui.dp(iconDp), Gravity.CENTER));
        }
        return thumb;
    }

    /** List design: baayein chhoti tasveer, daayein naam (Opera jaisa). */
    View tabRow(final MainActivity.Tab t, final Dialog d, final Runnable rerender) {
        boolean isCur = t == a.cur();
        String u = t.web.getUrl();
        boolean home = u == null || u.startsWith(MainActivity.HOME);
        String title = tabTitle(t);
        String host = home ? null : Uri.parse(u).getHost();

        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(6), Ui.dp(8));
        GradientDrawable bg = isCur
                ? new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{t.incognito ? 0xFF5B1F9E : 0xFF6A5CFF, t.incognito ? 0xFF3A1270 : 0xFF1E5BFF})
                : Ui.round(t.incognito ? 0xFF2A1450 : Ui.gl(0x24), 26);
        bg.setCornerRadius(Ui.dp(26));
        c.setBackground(bg);
        c.setElevation(Ui.dp(4));

        c.addView(thumbView(t, home, title, host, 40, 20), new LinearLayout.LayoutParams(Ui.dp(116), -1));

        LinearLayout tx = new LinearLayout(a);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(Ui.dp(14), 0, Ui.dp(4), 0);
        TextView tt = Ui.text(a, title, 16, isCur ? 0xFFFFFFFF : Color.WHITE, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(tt);
        TextView hs = Ui.text(a, home ? "New tab" : (host == null ? u : host), 13, isCur ? 0xDDFFFFFF : Ui.MUTED, false);
        hs.setSingleLine(true);
        hs.setEllipsize(TextUtils.TruncateAt.END);
        hs.setPadding(0, Ui.dp(3), 0, 0);
        tx.addView(hs);
        c.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));

        ImageView x = Ui.icon(a, R.drawable.ic_close, isCur ? 0xFFFFFFFF : 0xFFFFB4B4);
        x.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        Ui.ripple(x, true);
        x.setOnClickListener(v -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        });
        c.addView(x, sq(44));

        Ui.ripple(c, false);
        swipeToClose(c, () -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        }, () -> {
            d.dismiss();
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.switchTab(idx);
        });
        return c;
    }

    /** Carousel design: beech me ek bada tab, side me agle/pichle (Opera jaisa). */
    View carousel(final ArrayList<MainActivity.Tab> shown, final Dialog d, final Runnable rerender) {
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        final int cardW = (int) (sw * 0.66f);
        final int side = (sw - cardW) / 2;

        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);

        final SnapScroller hsv = new SnapScroller(a);
        final LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(side - Ui.dp(8), 0, side - Ui.dp(8), 0);
        row.setClipToPadding(false);
        hsv.row = row;
        hsv.addView(row, new FrameLayout.LayoutParams(-2, -1));
        wrap.addView(hsv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // Neeche chhoti tasveerein (strip)
        final LinearLayout strip = new LinearLayout(a);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER);
        HorizontalScrollView stripSv = new HorizontalScrollView(a);
        stripSv.setHorizontalScrollBarEnabled(false);
        stripSv.setFillViewport(true);
        stripSv.addView(strip, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(-1, Ui.dp(76));
        stl.setMargins(0, Ui.dp(6), 0, Ui.dp(2));
        wrap.addView(stripSv, stl);

        int curIdx = 0;
        for (int i = 0; i < shown.size(); i++) {
            final MainActivity.Tab t = shown.get(i);
            if (t == a.cur()) curIdx = i;
            View card = carouselCard(t, d, rerender);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cardW, -1);
            lp.setMargins(Ui.dp(8), Ui.dp(10), Ui.dp(8), Ui.dp(10));
            row.addView(card, lp);

            String u = t.web.getUrl();
            boolean home = u == null || u.startsWith(MainActivity.HOME);
            View mini = thumbView(t, home, tabTitle(t), home ? null : Uri.parse(u).getHost(), 24, 8);
            final int fi = i;
            mini.setOnClickListener(v -> hsv.go(fi, true));
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(64));
            mlp.setMargins(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
            strip.addView(mini, mlp);
        }
        hsv.onPage = p -> {
            for (int i = 0; i < strip.getChildCount(); i++) {
                View m = strip.getChildAt(i);
                boolean on = i == p;
                m.animate().scaleX(on ? 1.15f : 0.9f).scaleY(on ? 1.15f : 0.9f).alpha(on ? 1f : 0.55f).setDuration(150).start();
                m.setForeground(on ? Ui.stroke(Ui.round(0x00000000, 8), Ui.ORANGE, 2) : null);
            }
        };
        final int start = curIdx;
        hsv.post(() -> hsv.go(start, false));
        return wrap;
    }

    View carouselCard(final MainActivity.Tab t, final Dialog d, final Runnable rerender) {
        boolean isCur = t == a.cur();
        String u = t.web.getUrl();
        boolean home = u == null || u.startsWith(MainActivity.HOME);
        String title = tabTitle(t);
        String host = home ? null : Uri.parse(u).getHost();

        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(7), Ui.dp(4), Ui.dp(7), Ui.dp(7));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                t.incognito ? new int[]{0xFF6A2BC2, 0xFF3A1270} : new int[]{0xFF6A5CFF, 0xFF4B3FE0});
        bg.setCornerRadius(Ui.dp(30));
        if (isCur) bg.setStroke(Ui.dp(3), Ui.ORANGE);
        c.setBackground(bg);
        c.setElevation(Ui.dp(10));

        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(10), Ui.dp(8), 0, Ui.dp(8));
        if (home) head.addView(logoView(), sq(24));
        else head.addView(Ui.siteIcon(a, title, host, 24), sq(24));
        TextView tt = Ui.text(a, title, 16, 0xFFFFFFFF, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tt.setPadding(Ui.dp(10), 0, Ui.dp(4), 0);
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView x = Ui.icon(a, R.drawable.ic_close, 0xFFFFFFFF);
        x.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        Ui.ripple(x, true);
        x.setOnClickListener(v -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        });
        head.addView(x, sq(40));
        c.addView(head);
        c.addView(thumbView(t, home, title, host, 72, 24), new LinearLayout.LayoutParams(-1, 0, 1f));

        swipeUpToClose(c, () -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        }, () -> {
            d.dismiss();
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.switchTab(idx);
        });
        return c;
    }

    /** Carousel card: upar phenko to band, tap karo to khule; side ki khinchai scroller ko jaati hai. */
    void swipeUpToClose(final View v, final Runnable onClose, final Runnable onTap) {
        final int slop = ViewConfiguration.get(a).getScaledTouchSlop();
        final float[] start = new float[2];
        final boolean[] drag = {false};
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = e.getRawX();
                    start[1] = e.getRawY();
                    drag[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (!drag[0] && Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx) && dy < 0) {
                        drag[0] = true;
                        if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    if (drag[0]) {
                        float ty = Math.min(0, dy);
                        view.setTranslationY(ty);
                        view.setAlpha(1f - Math.min(0.9f, Math.abs(ty) / view.getHeight()));
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (drag[0]) {
                        if (-dy > view.getHeight() * 0.25f) {
                            view.animate().translationY(-view.getHeight() * 1.2f).alpha(0f).setDuration(200).withEndAction(onClose).start();
                        } else {
                            view.animate().translationY(0).alpha(1f).setDuration(180).start();
                        }
                    } else if (Math.abs(dx) < slop && Math.abs(dy) < slop) {
                        onTap.run();
                    }
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    view.animate().translationY(0).alpha(1f).setDuration(180).start();
                    return true;
            }
            return false;
        });
    }

    /** Ek-ek card par ruk kar chalne wala side scroller, beech wala card bada dikhta hai. */
    static class SnapScroller extends HorizontalScrollView {
        LinearLayout row;
        int page;
        boolean flung;
        java.util.function.IntConsumer onPage;

        SnapScroller(Context c) {
            super(c);
            setHorizontalScrollBarEnabled(false);
            setOverScrollMode(OVER_SCROLL_NEVER);
            setFillViewport(true);
        }

        int nearest() {
            if (row == null) return 0;
            int cx = getScrollX() + getWidth() / 2, best = 0, bd = Integer.MAX_VALUE;
            for (int i = 0; i < row.getChildCount(); i++) {
                View ch = row.getChildAt(i);
                int d = Math.abs(ch.getLeft() + ch.getWidth() / 2 - cx);
                if (d < bd) { bd = d; best = i; }
            }
            return best;
        }

        void go(int i, boolean smooth) {
            if (row == null || row.getChildCount() == 0) return;
            i = Math.max(0, Math.min(row.getChildCount() - 1, i));
            View ch = row.getChildAt(i);
            int x = ch.getLeft() + ch.getWidth() / 2 - getWidth() / 2;
            page = i;
            if (smooth) smoothScrollTo(x, 0); else scrollTo(x, 0);
            if (onPage != null) onPage.accept(i);
        }

        @Override
        public void fling(int vx) {
            flung = true;
            int n = nearest();
            if (n == page && Math.abs(vx) > 400) n = page + (vx > 0 ? 1 : -1);
            go(n, true);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) flung = false;
            boolean r = super.onTouchEvent(e);
            int act = e.getActionMasked();
            if ((act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) && !flung) go(nearest(), true);
            return r;
        }

        @Override
        protected void onScrollChanged(int l, int t, int ol, int ot) {
            super.onScrollChanged(l, t, ol, ot);
            if (row == null || getWidth() == 0) return;
            int cx = l + getWidth() / 2;
            for (int i = 0; i < row.getChildCount(); i++) {
                View ch = row.getChildAt(i);
                float dist = Math.abs(ch.getLeft() + ch.getWidth() / 2f - cx) / getWidth();
                float s = 1f - Math.min(0.14f, dist * 0.2f);
                ch.setScaleX(s);
                ch.setScaleY(s);
            }
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            super.onLayout(changed, l, t, r, b);
            onScrollChanged(getScrollX(), 0, getScrollX(), 0);
        }
    }

    String tabTitle(MainActivity.Tab t) {
        String u = t.web.getUrl();
        if (u == null || u.startsWith(MainActivity.HOME)) return "Baatora Home";
        return TextUtils.isEmpty(t.title) ? u : t.title;
    }

    View tabCard(final MainActivity.Tab t, final Dialog d, final Runnable rerender) {
        boolean isCur = t == a.cur();
        String u = t.web.getUrl();
        boolean home = u == null || u.startsWith(MainActivity.HOME);
        String title = tabTitle(t);
        String host = home ? null : Uri.parse(u).getHost();

        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(6));
        GradientDrawable bg = Ui.round(t.incognito ? 0xFF2A1450 : Ui.gl(0x24), 24);
        if (isCur) Ui.stroke(bg, Ui.ORANGE, 3);
        c.setBackground(bg);
        c.setElevation(Ui.dp(6));

        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(6), Ui.dp(4), 0, Ui.dp(4));
        if (home) head.addView(logoView(), sq(22));
        else head.addView(Ui.siteIcon(a, title, host, 22), sq(22));
        TextView tt = Ui.text(a, title, 13, Color.WHITE, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tt.setPadding(Ui.dp(8), 0, Ui.dp(4), 0);
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView x = Ui.icon(a, R.drawable.ic_close, 0xFFFFB4B4);
        x.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        Ui.ripple(x, true);
        x.setOnClickListener(v -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        });
        head.addView(x, sq(32));
        c.addView(head);

        FrameLayout thumb = new FrameLayout(a);
        thumb.setBackground(Ui.grad(Ui.NAVY2, Ui.NAVY, 18));
        thumb.setClipToOutline(true);
        if (t.thumb != null) {
            final ImageView iv = new ImageView(a);
            iv.setImageBitmap(t.thumb);
            iv.setScaleType(ImageView.ScaleType.MATRIX);
            thumb.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            iv.post(() -> {
                if (t.thumb == null || t.thumb.getWidth() == 0) return;
                float s = iv.getWidth() / (float) t.thumb.getWidth();
                Matrix mx = new Matrix();
                mx.setScale(s, s);
                iv.setImageMatrix(mx);
            });
        } else {
            View big = home ? logoView() : Ui.siteIcon(a, title, host, 64);
            thumb.addView(big, new FrameLayout.LayoutParams(Ui.dp(64), Ui.dp(64), Gravity.CENTER));
        }
        c.addView(thumb, new LinearLayout.LayoutParams(-1, Ui.dp(210)));

        Ui.ripple(c, false);
        swipeToClose(c, () -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        }, () -> {
            d.dismiss();
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.switchTab(idx);
        });
        return c;
    }

    /** Card ko left/right swipe karne par band, tap karne par khule. */
    void swipeToClose(final View v, final Runnable onClose, final Runnable onTap) {
        final int slop = ViewConfiguration.get(a).getScaledTouchSlop();
        final float[] start = new float[2];
        final boolean[] drag = {false};
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = e.getRawX();
                    start[1] = e.getRawY();
                    drag[0] = false;
                    view.setPressed(true);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (!drag[0] && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) {
                        drag[0] = true;
                        view.setPressed(false);
                        if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
                    } else if (!drag[0] && Math.abs(dy) > slop) {
                        view.setPressed(false);
                    }
                    if (drag[0]) {
                        view.setTranslationX(dx);
                        view.setRotation(dx / view.getWidth() * 8f);
                        view.setAlpha(1f - Math.min(0.9f, Math.abs(dx) / view.getWidth()));
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    view.setPressed(false);
                    float dx = e.getRawX() - start[0], dy = e.getRawY() - start[1];
                    if (drag[0]) {
                        if (Math.abs(dx) > view.getWidth() * 0.3f) {
                            view.animate().translationX(Math.signum(dx) * view.getWidth() * 1.3f)
                                    .alpha(0f).setDuration(180).withEndAction(onClose).start();
                        } else {
                            view.animate().translationX(0).rotation(0).alpha(1f).setDuration(180).start();
                        }
                    } else if (Math.abs(dx) < slop && Math.abs(dy) < slop) {
                        onTap.run();
                    }
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    view.setPressed(false);
                    view.animate().translationX(0).rotation(0).alpha(1f).setDuration(180).start();
                    return true;
            }
            return false;
        });
    }

    // ═══════════════════════ HISTORY / BOOKMARKS ═══════════════════════

    void list(final String key) {
        final boolean hist = key.equals("history");
        final String title = L.t(hist ? "history" : "bookmarks");
        final Page p = page((hist ? "🕘  " : "🔖  ") + title);
        final Runnable[] render = new Runnable[1];

        p.header.addView(Ui.iconButton(a, R.drawable.ic_delete, v ->
                confirm(L.t(hist ? "clear_hist_t" : "clear_bm_t"), L.t(hist ? "clear_hist_m" : "clear_bm_m"),
                        L.t("clear_btn"), () -> { a.save(key, new JSONArray()); render[0].run(); })), sq(48));

        final EditText search = searchBox(L.t(hist ? "search_hist" : "search_bm"));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(6));
        p.root.addView(search, slp);

        final int[] range = {0};
        final ArrayList<TextView> rchips = new ArrayList<>();
        if (hist) {
            HorizontalScrollView hs = new HorizontalScrollView(a);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(4));
            hs.addView(row);
            String[] labels = {L.t("all"), L.t("f_today"), L.t("f_week"), L.t("f_month"), L.t("f_year")};
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView c = Ui.text(a, labels[i], 13.5f, Color.WHITE, true);
                c.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
                c.setOnClickListener(v -> {
                    range[0] = idx;
                    for (int k = 0; k < rchips.size(); k++) {
                        boolean sel = k == idx;
                        rchips.get(k).setBackground(sel ? Ui.grad(Ui.GOLD, Ui.ORANGE, 18) : Ui.stroke(Ui.round(Ui.gl(0x14), 18), Ui.gl(0x33), 1));
                        rchips.get(k).setTextColor(sel ? Ui.INK : Ui.TEXT);
                    }
                    if (render[0] != null) render[0].run();
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.rightMargin = Ui.dp(8);
                row.addView(c, lp);
                rchips.add(c);
            }
            p.root.addView(hs);
        }

        ScrollView sv = new ScrollView(a);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), Ui.dp(4), Ui.dp(14), Ui.dp(24));
        sv.addView(list);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        render[0] = () -> {
            list.removeAllViews();
            JSONArray arr = a.load(key);
            String q = search.getText().toString().trim().toLowerCase();
            String lastGroup = null;
            GridLayout grid = null;
            if (!hist) {
                grid = new GridLayout(a);
                grid.setColumnCount(2);
                list.addView(grid, new LinearLayout.LayoutParams(-1, -2));
            }
            int shown = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                final String t = o.optString("t"), u = o.optString("u");
                long time = o.optLong("time", 0);
                if (!q.isEmpty() && !(t + " " + u).toLowerCase().contains(q)) continue;
                if (hist && range[0] > 0 && time < rangeStart(range[0])) continue;
                final int idx = i;
                String host = Uri.parse(u).getHost();
                View.OnClickListener open = v -> { p.d.dismiss(); if (a.web() != null) a.web().loadUrl(u); };
                View.OnClickListener del = v -> { JSONArray cur = a.load(key); cur.remove(idx); a.save(key, cur); render[0].run(); };
                if (hist) {
                    String g = dayLabel(time);
                    if (!g.equals(lastGroup)) {
                        list.addView(dayChip(g));
                        lastGroup = g;
                    }
                    String sub = (host == null ? u : host) + (time > 0 ? "  •  " + timeFmt.format(new Date(time)) : "");
                    list.addView(histRow(t, host, time > 0 ? timeFmt.format(new Date(time)) : "", open, del), rowLp(10));
                } else {
                    GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                            GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
                    lp.width = 0;
                    lp.setMargins(Ui.dp(5), Ui.dp(5), Ui.dp(5), Ui.dp(5));
                    grid.addView(bookmarkCard(t, host, open, del), lp);
                }
                shown++;
            }
            if (hist && shown > 0) {
                TextView cnt = Ui.text(a, "●  " + shown + " pages", 12, Ui.GOLD, true);
                cnt.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
                list.addView(cnt, 0);
            }
            if (shown == 0) {
                list.removeAllViews();
                list.addView(empty(hist ? R.drawable.ic_history : R.drawable.ic_bookmark,
                        !q.isEmpty() ? L.t("not_found") : L.t(hist ? "empty_hist" : "empty_bm"),
                        hist ? "🕘" : "⭐  " + L.t("add_bookmark")));
            }
        };
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int x, int y, int z) {}
            public void onTextChanged(CharSequence s, int x, int y, int z) {}
            public void afterTextChanged(Editable s) { render[0].run(); }
        });
        p.d.show();
        if (!rchips.isEmpty()) rchips.get(0).performClick(); else render[0].run();
    }

    static long rangeStart(int r) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        if (r == 2) c.add(Calendar.DAY_OF_YEAR, -6);
        else if (r == 3) c.add(Calendar.DAY_OF_YEAR, -29);
        else if (r == 4) c.add(Calendar.YEAR, -1);
        return c.getTimeInMillis();
    }

    View histRow(String title, String host, String time, View.OnClickListener open, View.OnClickListener del) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(4), Ui.dp(10));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.gl(0x2C), Ui.gl(0x0E)});
        bg.setCornerRadius(Ui.dp(20));
        bg.setStroke(Ui.dp(1), Ui.gl(0x2A));
        r.setBackground(bg);
        r.addView(Ui.siteIcon(a, title, host, 46), sq(46));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, Ui.dp(6), 0);
        TextView t = Ui.text(a, TextUtils.isEmpty(title) ? host : title, 15, Color.WHITE, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        String h = host == null ? "" : host.replaceFirst("^www\\.", "").replaceFirst("^m\\.", "");
        TextView s = Ui.text(a, h, 12, Ui.MUTED, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        s.setPadding(0, Ui.dp(2), 0, 0);
        col.addView(s);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!time.isEmpty()) {
            TextView tm = Ui.text(a, time, 11, Ui.GOLD, true);
            tm.setPadding(Ui.dp(9), Ui.dp(4), Ui.dp(9), Ui.dp(4));
            tm.setBackground(Ui.stroke(Ui.round(Ui.gl(0x14), 12), (Ui.GOLD & 0xFFFFFF) | 0x55000000, 1));
            r.addView(tm, new LinearLayout.LayoutParams(-2, -2));
        }
        ImageView x = Ui.iconButton(a, R.drawable.ic_close, del);
        x.setColorFilter(0xFFFF8A80);
        r.addView(x, sq(40));
        r.setOnClickListener(open);
        Ui.ripple(r, false);
        return r;
    }

    View dayChip(String g) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Ui.dp(14), 0, Ui.dp(8));
        TextView t = Ui.text(a, "📅  " + g, 13, Ui.INK, true);
        t.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(6));
        t.setBackground(Ui.grad(Ui.GOLD, Ui.ORANGE, 16));
        r.addView(t);
        View line = new View(a);
        line.setBackground(Ui.round(Ui.gl(0x26), 1));
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(0, Ui.dp(1), 1f);
        ll.leftMargin = Ui.dp(10);
        r.addView(line, ll);
        return r;
    }

    View bookmarkCard(String title, String host, View.OnClickListener open, View.OnClickListener del) {
        FrameLayout f = new FrameLayout(a);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.gl(0x26), Ui.gl(0x0D)});
        bg.setCornerRadius(Ui.dp(22));
        bg.setStroke(Ui.dp(1), Ui.gl(0x26));
        f.setBackground(bg);
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(12), Ui.dp(20), Ui.dp(12), Ui.dp(16));
        c.addView(Ui.siteIcon(a, title, host, 56), sq(56));
        TextView t = Ui.text(a, TextUtils.isEmpty(title) ? host : title, 14, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setPadding(0, Ui.dp(10), 0, Ui.dp(2));
        c.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView h = Ui.text(a, host == null ? "" : host.replaceFirst("^www\\.", ""), 11.5f, Ui.MUTED, false);
        h.setGravity(Gravity.CENTER);
        h.setSingleLine(true);
        h.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(h, new LinearLayout.LayoutParams(-1, -2));
        f.addView(c, new FrameLayout.LayoutParams(-1, -2));
        ImageView x = Ui.icon(a, R.drawable.ic_close, Color.WHITE);
        x.setBackground(Ui.round(0x44FF5252, 14));
        x.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        Ui.ripple(x, true);
        x.setOnClickListener(del);
        FrameLayout.LayoutParams xl = new FrameLayout.LayoutParams(Ui.dp(28), Ui.dp(28), Gravity.TOP | Gravity.END);
        xl.setMargins(0, Ui.dp(8), Ui.dp(8), 0);
        f.addView(x, xl);
        f.setOnClickListener(open);
        Ui.ripple(f, false);
        return f;
    }

    View row(String title, String host, String sub, View.OnClickListener open, View.OnClickListener del) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(4), Ui.dp(10));
        r.setBackground(Ui.round(Ui.gl(0x16), 18));
        r.addView(Ui.siteIcon(a, title, host, 42), sq(42));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
        TextView t = Ui.text(a, TextUtils.isEmpty(title) ? host : title, 15, Color.WHITE, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        TextView s = Ui.text(a, sub, 12, Ui.MUTED, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(s);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView x = Ui.iconButton(a, R.drawable.ic_close, del);
        x.setColorFilter(0xFFFF8A80);
        r.addView(x, sq(42));
        r.setOnClickListener(open);
        Ui.ripple(r, false);
        return r;
    }

    static String dayLabel(long t) {
        if (t <= 0) return "Pehle";
        Calendar now = Calendar.getInstance(), c = Calendar.getInstance();
        c.setTimeInMillis(t);
        if (sameDay(now, c)) return "Aaj";
        now.add(Calendar.DAY_OF_YEAR, -1);
        if (sameDay(now, c)) return "Kal";
        return new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(new Date(t));
    }

    static boolean sameDay(Calendar x, Calendar y) {
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR);
    }

    // ═══════════════════════ DOWNLOADS ═══════════════════════

    static class Dl { long id, total, done, time, speed, turboId; String name, mime, uri, url; int status; boolean turbo; }

    static final String[] DL_FILTERS = {"Sab", "Video", "Audio", "Photo", "Docs", "Apps"};

    void downloads() {
        final Page p = page(L.t("downloads"));
        p.header.addView(Ui.iconButton(a, R.drawable.ic_folder, v -> {
            try { a.startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { a.toast("Downloads folder nahi khula"); }
        }), sq(48));

        LinearLayout stat = new LinearLayout(a);
        stat.setOrientation(LinearLayout.HORIZONTAL);
        stat.setGravity(Gravity.CENTER_VERTICAL);
        stat.setPadding(Ui.dp(18), Ui.dp(16), Ui.dp(18), Ui.dp(16));
        stat.setBackground(Ui.grad(Ui.ORANGE, Ui.ACC, 22));
        stat.setElevation(Ui.dp(6));
        stat.addView(Ui.iconTile(a, R.drawable.ic_download, new int[]{0x33FFFFFF, 0x22FFFFFF}, 48), sq(48));
        LinearLayout sc = new LinearLayout(a);
        sc.setOrientation(LinearLayout.VERTICAL);
        sc.setPadding(Ui.dp(14), 0, 0, 0);
        final TextView statBig = Ui.text(a, "0 files", 20, Ui.ON_COLOR, true);
        final TextView statSmall = Ui.text(a, "", 12.5f, 0xFFFFF3E0, false);
        sc.addView(statBig);
        sc.addView(statSmall);
        stat.addView(sc, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(-1, -2);
        stLp.setMargins(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(4));
        p.root.addView(stat, stLp);

        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(6));
        hs.addView(chips);
        p.root.addView(hs);

        ScrollView sv = new ScrollView(a);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(24));
        sv.addView(list);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final String[] filter = {"Sab"};
        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable[] tick = new Runnable[1];
        final ArrayList<TextView> chipViews = new ArrayList<>();
        final Runnable styleChips = () -> {
            for (TextView c : chipViews) {
                boolean sel = String.valueOf(c.getTag()).equals(filter[0]);
                c.setBackground(sel ? Ui.grad(Ui.GOLD, Ui.ORANGE, 20) : Ui.stroke(Ui.round(Ui.gl(0x14), 20), Ui.gl(0x33), 1));
                c.setTextColor(sel ? Ui.INK : Ui.TEXT);
            }
        };
        for (String f : DL_FILTERS) {
            TextView c = Ui.text(a, f.equals("Sab") ? L.t("all") : f, 13.5f, Color.WHITE, true);
            c.setTag(f);
            c.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
            c.setOnClickListener(v -> {
                filter[0] = f;
                styleChips.run();
                h.removeCallbacksAndMessages(null);
                tick[0].run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(8);
            chips.addView(c, lp);
            chipViews.add(c);
        }
        styleChips.run();

        tick[0] = () -> {
            boolean running = renderDownloads(list, statBig, statSmall, filter[0], () -> {
                h.removeCallbacksAndMessages(null);
                tick[0].run();
            });
            if (running && p.d.isShowing()) h.postDelayed(tick[0], 1000);
        };
        p.d.setOnDismissListener(x -> h.removeCallbacksAndMessages(null));
        p.d.show();
        tick[0].run();
    }

    ArrayList<Dl> queryDownloads() {
        ArrayList<Dl> out = new ArrayList<>();
        JSONArray ids = a.load("dl_ids");
        if (ids.length() == 0) return out;
        long[] arr = new long[ids.length()];
        for (int i = 0; i < ids.length(); i++) arr[i] = ids.optLong(i);
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query().setFilterById(arr));
            while (c != null && c.moveToNext()) {
                Dl d = new Dl();
                d.id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                d.name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                d.mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                d.status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                d.total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                d.done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                d.time = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP));
                out.add(d);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        Collections.sort(out, (x, y) -> Long.compare(y.id, x.id));
        return out;
    }

    static String fileType(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase();
        String m = mime == null ? "" : mime.toLowerCase();
        if (m.startsWith("video") || n.matches(".*\\.(mp4|mkv|webm|3gp|mov|avi|m4v)$")) return "Video";
        if (m.startsWith("audio") || n.matches(".*\\.(mp3|m4a|aac|wav|ogg|flac|opus)$")) return "Audio";
        if (m.startsWith("image") || n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp)$")) return "Photo";
        if (n.endsWith(".apk") || m.equals("application/vnd.android.package-archive")) return "Apps";
        if (n.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|zip|rar|7z)$") || m.contains("pdf")) return "Docs";
        return "Other";
    }

    static int typeIcon(String type) {
        switch (type) {
            case "Video": return R.drawable.ic_video;
            case "Audio": return R.drawable.ic_music;
            case "Photo": return R.drawable.ic_image;
            case "Apps": return R.drawable.ic_android;
            case "Docs": return R.drawable.ic_doc;
            default: return R.drawable.ic_file;
        }
    }

    static int[] typeColors(String type) {
        switch (type) {
            case "Video": return P(3);
            case "Audio": return P(4);
            case "Photo": return P(6);
            case "Apps": return new int[]{0xFF69F0AE, 0xFF00A152};
            case "Docs": return P(1);
            default: return P(2);
        }
    }

    boolean renderDownloads(LinearLayout list, TextView statBig, TextView statSmall, String filter, Runnable refresh) {
        list.removeAllViews();
        ArrayList<Dl> all = queryDownloads();
        all.addAll(turboItems());
        Collections.sort(all, (x, y) -> Long.compare(y.time, x.time));
        boolean running = false;
        int doneCount = 0, active = 0;
        long doneBytes = 0, speed = 0;
        for (Dl d : all) {
            if (d.status == DownloadManager.STATUS_SUCCESSFUL) { doneCount++; doneBytes += Math.max(0, d.total); }
            else if (d.status != DownloadManager.STATUS_FAILED) { active++; running = true; speed += d.speed; }
        }
        statBig.setText(doneCount + " files  •  " + Formatter.formatFileSize(a, doneBytes));
        statSmall.setText(active > 0 ? "⚡ " + active + " chal rahe  •  " + Formatter.formatFileSize(a, speed) + "/s"
                : "📁 Download / Baatora folder");

        final SimpleDateFormat fmt = new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH);
        int shown = 0;
        for (final Dl d : all) {
            String type = fileType(d.name, d.mime);
            if (!filter.equals("Sab") && !filter.equals(type)) continue;
            shown++;
            boolean inProgress = d.status == DownloadManager.STATUS_RUNNING
                    || d.status == DownloadManager.STATUS_PENDING || d.status == DownloadManager.STATUS_PAUSED;
            boolean failed = d.status == DownloadManager.STATUS_FAILED;

            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(12), Ui.dp(14), Ui.dp(6), Ui.dp(14));
            GradientDrawable rb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    inProgress ? new int[]{Ui.gl(0x26), Ui.gl(0x10)} : new int[]{Ui.gl(0x18), Ui.gl(0x0C)});
            rb.setCornerRadius(Ui.dp(20));
            rb.setStroke(Ui.dp(1), inProgress ? (Ui.GOLD & 0x00FFFFFF) | 0x66000000 : Ui.gl(0x1A));
            r.setBackground(rb);

            FrameLayout tileWrap = new FrameLayout(a);
            tileWrap.addView(Ui.iconTile(a, typeIcon(type), typeColors(type), 48), new FrameLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
            if (d.turbo) {
                TextView bolt = Ui.text(a, "⚡", 10, Color.WHITE, true);
                bolt.setGravity(Gravity.CENTER);
                bolt.setBackground(Ui.stroke(Ui.round(Ui.ORANGE, 9), Ui.NAVY, 1.5f));
                bolt.setElevation(Ui.dp(8));
                tileWrap.addView(bolt, new FrameLayout.LayoutParams(Ui.dp(18), Ui.dp(18), Gravity.BOTTOM | Gravity.END));
            }
            r.addView(tileWrap, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));

            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
            TextView name = Ui.text(a, d.name == null ? "File" : d.name, 14.5f, Color.WHITE, true);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            col.addView(name);

            String status;
            int statusColor = Ui.MUTED;
            int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0;
            switch (d.status) {
                case DownloadManager.STATUS_RUNNING:
                    status = (d.total > 0 ? pct + "%  •  " : "") + Formatter.formatFileSize(a, d.done) + " / "
                            + (d.total > 0 ? Formatter.formatFileSize(a, d.total) : "?")
                            + (d.turbo ? "  •  " + Formatter.formatFileSize(a, d.speed) + "/s" : "");
                    statusColor = 0xFF80D8FF;
                    break;
                case DownloadManager.STATUS_PENDING:
                    status = "Shuru ho raha hai...";
                    break;
                case DownloadManager.STATUS_PAUSED:
                    status = "Ruka hua — internet ka intezaar";
                    statusColor = 0xFFFFD180;
                    break;
                case DownloadManager.STATUS_SUCCESSFUL:
                    status = "✓ " + Formatter.formatFileSize(a, Math.max(0, d.total)) + "  •  " + fmt.format(new Date(d.time));
                    statusColor = 0xFF9BE7B4;
                    break;
                default:
                    status = d.turbo ? "✕ Fail hua — dobara try ke liye tap karein" : "✕ Download fail ho gaya";
                    statusColor = 0xFFFF8A80;
            }
            if (inProgress) {
                ProgressBar pb = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
                pb.setProgressDrawable(a.getDrawable(R.drawable.progress_bar));
                pb.setBackground(Ui.round(Ui.gl(0x26), 4));
                pb.setMax(100);
                pb.setIndeterminate(false);
                pb.setProgress(pct);
                pb.setClipToOutline(true);
                LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-1, Ui.dp(8));
                pl.topMargin = Ui.dp(8);
                pl.bottomMargin = Ui.dp(5);
                col.addView(pb, pl);
            }
            TextView st = Ui.text(a, status, 12, statusColor, false);
            st.setPadding(0, Ui.dp(3), 0, 0);
            col.addView(st);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            ImageView x;
            if (inProgress && d.turbo) {
                x = Ui.iconButton(a, R.drawable.ic_close, v -> {
                    TurboService.Job j = TurboService.JOBS.get(d.turboId);
                    if (j != null) j.cancel = true;
                    a.toast("Download roka gaya");
                    refresh.run();
                });
            } else {
                x = Ui.iconButton(a, R.drawable.ic_delete, v -> confirm(L.t("delete") + "?",
                        (d.name == null ? "File" : d.name), L.t("delete"), () -> {
                            deleteDownload(d);
                            refresh.run();
                        }));
            }
            x.setColorFilter(0xFFFF8A80);
            r.addView(x, sq(42));

            r.setOnClickListener(v -> {
                if (d.status == DownloadManager.STATUS_SUCCESSFUL) {
                    if (d.turbo) openTurbo(d); else openDownload(d.id);
                } else if (failed && d.turbo && d.url != null) {
                    deleteDownload(d);
                    a.startDownload(d.url, null, d.mime == null || d.mime.isEmpty() ? null : d.mime, d.name);
                    refresh.run();
                } else a.toast(st.getText().toString());
            });
            Ui.ripple(r, false);
            list.addView(r, rowLp(10));
        }
        if (shown == 0) {
            list.addView(empty(R.drawable.ic_download,
                    filter.equals("Sab") ? "Abhi koi download nahi" : "Is type ki koi file nahi",
                    "⚡ Turbo download se files tez aati hain aur yahan dikhti hain"));
        }
        return running;
    }

    ArrayList<Dl> turboItems() {
        ArrayList<Dl> out = new ArrayList<>();
        for (TurboService.Job j : TurboService.running()) {
            Dl d = new Dl();
            d.turbo = true; d.turboId = j.id; d.name = j.name; d.mime = j.mime; d.time = j.time;
            d.total = j.total; d.done = j.done; d.speed = j.speed; d.status = DownloadManager.STATUS_RUNNING; d.url = j.url;
            out.add(d);
        }
        JSONArray arr = a.load("turbo");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Dl d = new Dl();
            d.turbo = true; d.turboId = o.optLong("id"); d.name = o.optString("name"); d.mime = o.optString("mime");
            d.time = o.optLong("time"); d.total = o.optLong("size"); d.done = d.total; d.uri = o.optString("uri"); d.url = o.optString("url");
            d.status = o.optInt("status") == TurboService.DONE ? DownloadManager.STATUS_SUCCESSFUL : DownloadManager.STATUS_FAILED;
            out.add(d);
        }
        return out;
    }

    void openTurbo(Dl d) {
        if (d.uri == null || d.uri.isEmpty()) { a.toast("File nahi mili"); return; }
        if (d.uri.startsWith("dm:")) {
            try { openDownload(Long.parseLong(d.uri.substring(3))); } catch (Exception e) { a.toast("File nahi mili"); }
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(d.uri), d.mime == null || d.mime.isEmpty() ? "*/*" : d.mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Exception e) {
            a.toast("Is file ko kholne wala app nahi mila");
        }
    }

    void deleteDownload(Dl d) {
        if (d.turbo) {
            try {
                if (d.uri != null && d.uri.startsWith("content:")) a.getContentResolver().delete(Uri.parse(d.uri), null, null);
                else if (d.uri != null && d.uri.startsWith("dm:"))
                    ((DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE)).remove(Long.parseLong(d.uri.substring(3)));
            } catch (Exception ignored) {}
            JSONArray arr = a.load("turbo"), keep = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null && o.optLong("id") != d.turboId) keep.put(o);
            }
            a.save("turbo", keep);
            return;
        }
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        try { dm.remove(d.id); } catch (Exception ignored) {}
        JSONArray ids = a.load("dl_ids"), keep = new JSONArray();
        for (int i = 0; i < ids.length(); i++) if (ids.optLong(i) != d.id) keep.put(ids.optLong(i));
        a.save("dl_ids", keep);
    }

    void openDownload(long id) {
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        try {
            Uri u = dm.getUriForDownloadedFile(id);
            String mime = dm.getMimeTypeForDownloadedFile(id);
            if (u == null) { a.toast("File nahi mili (shayad delete ho gayi)"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Exception e) {
            a.toast("Is file ko kholne wala app nahi mila");
        }
    }

    void downloadSheet(final String url, final String ua, final String mime, String name, long len) {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("Download karein"));

        String type = fileType(name, mime);
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(Ui.iconTile(a, typeIcon(type), typeColors(type), 56), sq(56));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, 0, 0);
        final EditText nameEdit = new EditText(a);
        nameEdit.setText(name);
        nameEdit.setTextColor(Color.WHITE);
        nameEdit.setTextSize(15);
        nameEdit.setSingleLine(true);
        nameEdit.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1F), 12), Ui.gl(0x33), 1));
        nameEdit.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
        col.addView(nameEdit);
        TextView size = Ui.text(a, (len > 0 ? Formatter.formatFileSize(a, len) + "  •  " : "") + type, 12.5f, Ui.MUTED, false);
        size.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
        col.addView(size);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(r);

        String ft = fileType(name, mime);
        TextView info = Ui.text(a, ft.equals("Video") ? "🎞  Gallery me (Movies/Baatora) save hoga"
                : ft.equals("Audio") ? "🎵  Music/Baatora folder me save hoga"
                : ft.equals("Photo") ? "🖼  Gallery me (Pictures/Baatora) save hoga"
                : "📁  Phone ke Download folder me save hoga", 12.5f, Ui.MUTED, false);
        info.setPadding(Ui.dp(4), Ui.dp(14), 0, Ui.dp(16));
        box.addView(info);

        LinearLayout btns = new LinearLayout(a);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, -2, 1f);
        b1.rightMargin = Ui.dp(6);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, -2, 1.4f);
        b2.leftMargin = Ui.dp(6);
        btns.addView(pill("Cancel", Ui.round(Ui.gl(0x26), 26), Color.WHITE, v -> dh[0].dismiss()), b1);
        btns.addView(pill("⬇  Download", Ui.grad(Ui.GOLD, Ui.ORANGE, 26), Ui.INK, v -> {
            String n = nameEdit.getText().toString().trim();
            dh[0].dismiss();
            a.startDownload(url, ua, mime, n.isEmpty() ? "Baatora_file" : n);
        }), b2);
        box.addView(btns);
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ VIDEO / AUDIO DOWNLOAD ═══════════════════════

    void videoDownload() {
        final MainActivity.Tab t = a.cur();
        if (t == null) return;
        String u = t.web.getUrl();
        if (MainActivity.isYouTube(u)) { youtubeInfo(); return; }
        if (!MainActivity.isRealUrl(u)) { a.toast("Pehle koi video wali website kholein"); return; }
        a.scanMedia(t, () -> mediaSheet(t));
    }

    void youtubeInfo() {
        new AlertDialog.Builder(a, DARK_DIALOG)
                .setTitle("YouTube video download")
                .setMessage("YouTube apni videos ko kisi bhi browser se download karne ki ijazat nahi deta " +
                        "(unke niyam aur copyright ki wajah se), isliye Baatora me YouTube download nahi hai.\n\n" +
                        "Offline dekhne ke liye YouTube app me video ke neeche ⬇ Download button use karein.\n\n" +
                        "Doosri websites par jahan seedhi video ya audio file hoti hai, wahan Baatora ka " +
                        "⬇ Download button apne aap dikh jayega.")
                .setPositiveButton("Samjh gaya", null).show();
    }

    static int quality(String u) {
        Matcher m = QUALITY.matcher(u);
        int best = 0;
        while (m.find()) {
            int v = Integer.parseInt(m.group(1));
            if (v > best) best = v;
        }
        return best;
    }

    static String ext(String u) {
        String path = Uri.parse(u).getPath();
        if (path == null) return "";
        int dot = path.lastIndexOf('.');
        return dot >= 0 ? path.substring(dot + 1).toUpperCase() : "";
    }

    static boolean isAudio(String u) {
        String e = ext(u);
        return e.equals("MP3") || e.equals("M4A") || e.equals("AAC") || e.equals("OGG")
                || e.equals("WAV") || e.equals("FLAC") || e.equals("OPUS");
    }

    void mediaSheet(final MainActivity.Tab t) {
        if (MainActivity.isYouTube(t.web.getUrl())) { youtubeInfo(); return; }
        ArrayList<String> items;
        items = a.visibleMedia(t);
        if (items.isEmpty()) {
            a.toast("Is page par koi video/audio file nahi mili. Video chala kar dobara try karein.");
            return;
        }
        Collections.sort(items, (x, y) -> {
            long[] ix = t.info.get(x), iy = t.info.get(y);
            long dx = ix == null ? 0 : Math.max(ix[0], 0), dy = iy == null ? 0 : Math.max(iy[0], 0);
            if (dx != dy) return dy > dx ? 1 : -1;
            return quality(y) - quality(x);
        });

        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("🎬  Video / Audio mila"));
        TextView sub = Ui.text(a, "Quality chunein aur download karein", 13, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, Ui.dp(12));
        box.addView(sub);

        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (final String u : items) {
            boolean audio = isAudio(u);
            int q = quality(u);
            String label = audio ? "Audio  •  " + ext(u)
                    : q > 0 ? q + "p" + (q >= 1080 ? "  Full HD" : q >= 720 ? "  HD" : "") + "  •  " + ext(u)
                    : ext(u).equals("M3U8") ? "Video  •  Stream (HD)"
                    : "Video  •  " + ext(u);
            long[] inf = t.info.get(u);
            if (inf != null && inf[0] > 0) {
                long sec = inf[0];
                label += "  •  " + (sec >= 3600 ? (sec / 3600) + ":" + String.format("%02d", (sec % 3600) / 60) + ":" + String.format("%02d", sec % 60)
                        : (sec / 60) + ":" + String.format("%02d", sec % 60));
            } else if (inf != null && inf[1] > 0) {
                label += "  •  " + Formatter.formatFileSize(a, inf[1]);
            }
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
            r.setBackground(Ui.round(Ui.gl(0x16), 18));
            r.addView(Ui.iconTile(a, audio ? R.drawable.ic_music : R.drawable.ic_video,
                    audio ? P(4) : P(3), 44), sq(44));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(12), 0, Ui.dp(8), 0);
            col.addView(Ui.text(a, label, 15, Color.WHITE, true));
            TextView fn = Ui.text(a, URLUtil.guessFileName(u, null, null), 11.5f, Ui.MUTED, false);
            fn.setSingleLine(true);
            fn.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            col.addView(fn);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            ImageView dl = Ui.icon(a, R.drawable.ic_download, Ui.INK);
            GradientDrawable dbg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.GOLD, Ui.ORANGE});
            dbg.setShape(GradientDrawable.OVAL);
            dbg.setStroke(Ui.dp(1.5f), 0x66FFFFFF);
            dl.setBackground(dbg);
            dl.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
            dl.setElevation(Ui.dp(4));
            dl.setOnClickListener(v -> {
                dh[0].dismiss();
                a.onDownload(u, t.web.getSettings().getUserAgentString(), null, null, 0);
            });
            r.addView(dl, sq(46));
            list.addView(r, rowLp(8));
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, items.size() > 5 ? Ui.dp(360) : -2));
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ ABOUT ═══════════════════════

    void about() {
        final Page p = page("About");
        ScrollView sv = new ScrollView(a);
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(30));
        sv.addView(c);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // 3D logo + ghoomti rings
        float den = Ui.density;
        FrameLayout stage = new FrameLayout(a);
        final RingView ra = new RingView(a, Ui.ORANGE, Ui.GOLD, Ui.dp(4));
        final RingView rb = new RingView(a, Ui.CYAN, Ui.BLUE, Ui.dp(3));
        ra.setRotationX(66);
        rb.setRotationX(66);
        rb.setRotation(60);
        ra.setCameraDistance(9000 * den);
        rb.setCameraDistance(9000 * den);
        stage.addView(rb, new FrameLayout.LayoutParams(Ui.dp(220), Ui.dp(220), Gravity.CENTER));
        stage.addView(ra, new FrameLayout.LayoutParams(Ui.dp(185), Ui.dp(185), Gravity.CENTER));
        ImageView logo = logoView();
        logo.setBackground(Ui.round(Ui.NAVY, 30));
        logo.setElevation(Ui.dp(16));
        logo.setCameraDistance(9000 * den);
        stage.addView(logo, new FrameLayout.LayoutParams(Ui.dp(110), Ui.dp(110), Gravity.CENTER));
        c.addView(stage, new LinearLayout.LayoutParams(Ui.dp(230), Ui.dp(230)));

        final ValueAnimator spin = ValueAnimator.ofFloat(0f, 360f);
        spin.setDuration(1800);
        spin.setRepeatCount(ValueAnimator.INFINITE);
        spin.setInterpolator(new LinearInterpolator());
        spin.addUpdateListener(an -> {
            float v = (float) an.getAnimatedValue();
            ra.setPhase(v);
            rb.setPhase(-v * 1.3f);
        });
        spin.start();
        logo.setRotationY(-360);
        logo.animate().rotationY(0).setDuration(1500).setInterpolator(new DecelerateInterpolator(1.6f)).start();

        final TextView name = Ui.text(a, "Baatora", 38, Color.WHITE, true);
        name.setGravity(Gravity.CENTER);
        c.addView(name, new LinearLayout.LayoutParams(-2, -2));
        name.post(() -> name.getPaint().setShader(new LinearGradient(0, 0, name.getWidth(), 0,
                new int[]{Ui.GOLD, Ui.ORANGE, Ui.CYAN, Ui.BLUE}, null, Shader.TileMode.CLAMP)));
        TextView tagline = Ui.text(a, "Tez. Surakshit. Apna Browser.", 14, 0xFFB8F3FF, false);
        tagline.setGravity(Gravity.CENTER);
        c.addView(tagline, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout pills = new LinearLayout(a);
        pills.setOrientation(LinearLayout.HORIZONTAL);
        pills.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        TextView ver = Ui.text(a, "Version " + appVer(), 13, Color.WHITE, true);
        ver.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        ver.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1F), 20), Ui.gl(0x44), 1));
        pills.addView(ver);
        TextView made = Ui.text(a, "Made in India 🇮🇳", 13, Ui.INK, true);
        made.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        GradientDrawable tri = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF138808});
        tri.setCornerRadius(Ui.dp(20));
        made.setBackground(tri);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.leftMargin = Ui.dp(10);
        pills.addView(made, mlp);
        c.addView(pills, new LinearLayout.LayoutParams(-2, -2));

        // Developer card
        LinearLayout dev = card(null);
        dev.setBackground(Ui.stroke(Ui.grad(Ui.NAVY2, Ui.PAGE1, 24), (Ui.GOLD & 0x00FFFFFF) | 0x66000000, 1.5f));
        dev.addView(Ui.text(a, "👨‍💻  Banaya hai", 13, 0xFFB8C6FF, false));
        LinearLayout nameRow = new LinearLayout(a);
        nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.setGravity(Gravity.BOTTOM);
        TextView devName = Ui.text(a, "Anil Yadav", 30, Ui.GOLD, true);
        nameRow.addView(devName);
        // Pata: chhota sa, naam ke side me
        LinearLayout loc = new LinearLayout(a);
        loc.setOrientation(LinearLayout.HORIZONTAL);
        loc.setGravity(Gravity.CENTER_VERTICAL);
        loc.setPadding(Ui.dp(8), Ui.dp(3), Ui.dp(10), Ui.dp(3));
        loc.setBackground(Ui.round(Ui.gl(0x1C), 12));
        loc.addView(Ui.icon(a, R.drawable.ic_location, Ui.ORANGE), sq(14));
        TextView addr = Ui.text(a, "Thane, MH", 11.5f, 0xFFDDE5FF, false);
        addr.setPadding(Ui.dp(4), 0, 0, 0);
        loc.addView(addr);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, -2);
        llp.setMargins(Ui.dp(10), 0, 0, Ui.dp(8));
        nameRow.addView(loc, llp);
        dev.addView(nameRow);
        TextView role = Ui.text(a, "Founder & Developer, Baatora  •  Sapne dekhne wala, unhe sach karne wala ✨", 13, 0xFFB8C6FF, false);
        role.setPadding(0, Ui.dp(4), 0, 0);
        role.setLineSpacing(0, 1.25f);
        dev.addView(role);
        c.addView(dev, cardLp());

        LinearLayout me = card("🙏  Mere baare me");
        me.addView(para("Namaste! Main Anil Yadav hoon — Thane, Maharashtra ka ek aam insaan, jiske sapne bade hain. " +
                "Roz ke kaam me mobile aur internet ke saath din guzarte-guzarte mujhe ehsaas hua ki hamare logon ko " +
                "ek aisa browser chahiye jo unki bhasha bole, unka data bachaye aur faltu ads se pareshaan na kare."));
        TextView p2 = para("Isi soch ne Baatora ko janm diya. Na koi badi company, na koi bada office — bas lagan, " +
                "raat-din ki mehnat aur seekhne ki bhookh. Har button, har rang aur har feature maine is soch ke saath " +
                "banaya hai ki aap use pehli baar me hi apna samjhein.");
        p2.setPadding(0, Ui.dp(10), 0, 0);
        me.addView(p2);
        TextView p3 = para("Mera maanna hai — \"Agar iraada pakka ho, to ek chhota sa shehar bhi duniya ko kuch bada de sakta hai.\" " +
                "Aapka har sujhav mere liye keemti hai. Baatora ko apna pyaar dete rahiye — Jai Hind! 🇮🇳");
        p3.setPadding(0, Ui.dp(10), 0, 0);
        me.addView(p3);
        LinearLayout tags = new LinearLayout(a);
        tags.setOrientation(LinearLayout.HORIZONTAL);
        tags.setPadding(0, Ui.dp(14), 0, 0);
        String[][] tg = {{"💡", "Soch"}, {"💪", "Mehnat"}, {"❤", "Desh"}};
        for (String[] t : tg) {
            TextView ch = Ui.text(a, t[0] + "  " + t[1], 12.5f, Ui.INK, true);
            ch.setGravity(Gravity.CENTER);
            ch.setPadding(Ui.dp(10), Ui.dp(7), Ui.dp(10), Ui.dp(7));
            ch.setBackground(Ui.grad(Ui.GOLD, Ui.ORANGE, 14));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
            tl.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
            tags.addView(ch, tl);
        }
        me.addView(tags);
        c.addView(me, cardLp());

        LinearLayout vision = card("🚀  Baatora ka Bhavishya");
        vision.addView(para("Baatora sirf ek browser nahi, Bharat ka apna digital saathi banne ki raah par hai. " +
                "Hamara sapna hai ki gaon se shahar tak har Bharatiya internet ko tez, surakshit aur bina rukawat " +
                "chalaye — apni bhasha me, apne andaaz me. Har naye update ke saath Baatora aur smart, aur halka " +
                "aur aur bharosemand banta jayega. 🇮🇳"));
        c.addView(vision, cardLp());

        LinearLayout feat = card("✨  Aage kya aa raha hai");
        String[][] fs = {
                {"🤖", "Baatora AI saathi — sawaal poochho, page ka saar Hindi me pao"},
                {"🗣", "Poora browser awaaz se chalao — \"YouTube kholo\", \"aaj ki khabar padho\""},
                {"🌐", "Har website ek tap me apni bhasha me — 22 Bharatiya bhashayein"},
                {"🛡", "Aur mazboot Baatora Shield — ad, tracker aur dhokebaaz sites se poori suraksha"},
                {"⚡", "Kam data me tez browsing — 2G/3G par bhi smooth chalega"},
                {"☁", "Sync — bookmarks, history aur tabs har phone me saath"},
                {"🏪", "Chhote dukaandaron ke liye apni dukaan online laane ke aasaan tools"},
                {"🎨", "Naye premium Home designs aur themes har mahine"}};
        for (String[] f : fs) {
            LinearLayout fr = new LinearLayout(a);
            fr.setOrientation(LinearLayout.HORIZONTAL);
            fr.setGravity(Gravity.CENTER_VERTICAL);
            fr.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
            TextView em = Ui.text(a, f[0], 16, Color.WHITE, false);
            em.setGravity(Gravity.CENTER);
            em.setBackground(Ui.grad(0xFF2E3B8F, 0xFF1A2466, 12));
            fr.addView(em, sq(34));
            TextView ft = Ui.text(a, f[1], 14, 0xFFDDE5FF, false);
            ft.setPadding(Ui.dp(12), 0, 0, 0);
            ft.setLineSpacing(0, 1.2f);
            fr.addView(ft, new LinearLayout.LayoutParams(0, -2, 1f));
            feat.addView(fr);
        }
        TextView mot = Ui.text(a, "\"Apna Browser, Apna Bharat\" — Baatora ke saath judne ke liye dhanyavaad 🙏", 13, Ui.GOLD, true);
        mot.setPadding(0, Ui.dp(12), 0, 0);
        mot.setGravity(Gravity.CENTER);
        feat.addView(mot, new LinearLayout.LayoutParams(-1, -2));
        c.addView(feat, cardLp());

        TextView foot = Ui.text(a, "© 2026 Anil Yadav  •  Sabhi adhikar surakshit\nJai Hind 🇮🇳", 12.5f, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setLineSpacing(0, 1.4f);
        foot.setPadding(0, Ui.dp(22), 0, 0);
        c.addView(foot, new LinearLayout.LayoutParams(-1, -2));

        p.d.setOnDismissListener(x -> spin.cancel());
        p.d.show();
    }

    // ═══════════════════════ GOOGLE ACCOUNT ═══════════════════════

    View accountCard(Runnable beforeAction) {
        boolean signed = a.googleSignedIn();
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
        r.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1A), 20), Ui.gl(0x2E), 1));
        FrameLayout av = new FrameLayout(a);
        av.setBackground(Ui.round(Color.WHITE, 22));
        av.setClipToOutline(true);
        ImageView g = new ImageView(a);
        g.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        av.addView(g, new FrameLayout.LayoutParams(-1, -1));
        Ui.favicon(g, "google.com", null);
        r.addView(av, sq(44));

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, Ui.dp(6), 0);
        col.addView(Ui.text(a, L.t(signed ? "g_on" : "g_title"), 15, Color.WHITE, true));
        col.addView(Ui.text(a, L.t(signed ? "g_on_sub" : "g_sub"), 12, Ui.MUTED, false));
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        if (signed) {
            TextView out = pill(L.t("sign_out"), Ui.round(0x33FF5252, 18), 0xFFFF8A80, v -> { beforeAction.run(); a.googleSignOut(); });
            out.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
            r.addView(out);
        } else {
            LinearLayout btns = new LinearLayout(a);
            btns.setOrientation(LinearLayout.VERTICAL);
            TextView in = pill(L.t("sign_in"), Ui.grad(Ui.GOLD, Ui.ORANGE, 16), Ui.INK, v -> { beforeAction.run(); a.googleSignIn(); });
            in.setPadding(Ui.dp(16), Ui.dp(7), Ui.dp(16), Ui.dp(7));
            btns.addView(in);
            TextView up = pill(L.t("sign_up"), Ui.round(Ui.gl(0x26), 16), Color.WHITE, v -> { beforeAction.run(); a.googleSignUp(); });
            up.setPadding(Ui.dp(16), Ui.dp(7), Ui.dp(16), Ui.dp(7));
            LinearLayout.LayoutParams ul = new LinearLayout.LayoutParams(-1, -2);
            ul.topMargin = Ui.dp(6);
            btns.addView(up, ul);
            r.addView(btns);
        }
        return r;
    }

    // ═══════════════════════ SETTINGS ═══════════════════════

    void settings() {
        final Page p = page(L.t("settings"));
        ScrollView sv = new ScrollView(a);
        final LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(30));
        sv.addView(c);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final Runnable reopen = () -> { p.d.dismiss(); settings(); };

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            c.removeAllViews();

            // Hero card
            LinearLayout hero = new LinearLayout(a);
            hero.setOrientation(LinearLayout.VERTICAL);
            hero.setPadding(Ui.dp(18), Ui.dp(18), Ui.dp(18), Ui.dp(16));
            GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.ORANGE, Ui.BLUE});
            hg.setCornerRadius(Ui.dp(26));
            hero.setBackground(hg);
            hg.setColors(new int[]{Ui.ORANGE, Ui.ACC});
            hero.setElevation(Ui.dp(8));
            LinearLayout hr = new LinearLayout(a);
            hr.setOrientation(LinearLayout.HORIZONTAL);
            hr.setGravity(Gravity.CENTER_VERTICAL);
            ImageView lg = logoView();
            lg.setBackground(Ui.round(Ui.NAVY, 18));
            hr.addView(lg, sq(60));
            LinearLayout hc = new LinearLayout(a);
            hc.setOrientation(LinearLayout.VERTICAL);
            hc.setPadding(Ui.dp(14), 0, 0, 0);
            hc.addView(Ui.text(a, "Baatora Browser", 21, Ui.ON_COLOR, true));
            hc.addView(Ui.text(a, "Version " + appVer() + "  •  Made in India 🇮🇳", 12.5f, Ui.ON_COLOR, false));
            hr.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
            hero.addView(hr);
            boolean def = a.isDefaultBrowser();
            TextView db = pill(def ? L.t("is_default") : "★  " + L.t("default_browser"),
                    def ? Ui.round(0x33FFFFFF, 20) : Ui.round(Color.WHITE, 20), def ? Ui.ON_COLOR : Ui.INK,
                    v -> { if (!a.isDefaultBrowser()) a.setDefaultBrowser(); });
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, -2);
            dl.topMargin = Ui.dp(14);
            hero.addView(db, dl);
            c.addView(hero, rowLp(12));

            c.addView(accountCard(() -> p.d.dismiss()), rowLp(4));

            String eng = a.engine();
            String engName = eng.equals("bing") ? "Bing" : eng.equals("duckduckgo") ? "DuckDuckGo" : eng.equals("yahoo") ? "Yahoo" : "Google";

            group(c, "🎨  " + L.t("s_look"),
                    actionRow(R.drawable.ic_palette, new int[]{Ui.GOLD, Ui.ORANGE}, L.t("theme"), Ui.THEME_NAMES[Ui.themeIdx], () -> themeSheet(reopen)),
                    actionRow(R.drawable.ic_translate, P(4), L.t("language"), L.NATIVE[L.idx], () -> langSheet(reopen)),
                    actionRow(R.drawable.ic_moon, new int[]{0xFF90A4AE, 0xFF263238}, L.t("appearance"),
                            Ui.MODE.equals("light") ? L.t("mode_light") : Ui.MODE.equals("dark") ? L.t("mode_dark") : L.t("mode_default"),
                            () -> {
                                String[] keys = {"light", "dark", "default"};
                                int sel = Ui.MODE.equals("light") ? 0 : Ui.MODE.equals("dark") ? 1 : 2;
                                choiceSheet("🌓  " + L.t("appearance"),
                                        new String[]{"☀  " + L.t("mode_light"), "🌙  " + L.t("mode_dark"), "📱  " + L.t("mode_default")},
                                        sel, w -> { a.setMode(keys[w]); reopen.run(); });
                            }),
                    toggleRow(R.drawable.ic_swap, P(2), L.t("bar_bottom"), L.t("bar_bottom_sub"), a.on("barBottom", false), a::toggleBarBottom),
                    toggleRow(R.drawable.ic_tabs, P(6), L.t("bottom_nav"), L.t("bottom_nav_sub"), a.on("bottomNav", true), a::toggleBottomNav),
                    toggleRow(R.drawable.ic_fullscreen, P(4), L.t("auto_hide"), L.t("auto_hide_sub"), a.on("autoHide", false), () -> a.togglePref("autoHide", false)),
                    toggleRow(R.drawable.ic_moon, P(1), L.t("night"), L.t("night_sub"), a.on("night", false), a::toggleNight),
                    actionRow(R.drawable.ic_textsize, P(3), L.t("textsize"), a.prefs.getInt("textZoom", 100) + "%", () -> a.chooseTextSize(render[0])));

            group(c, "🌐  " + L.t("s_browsing"),
                    actionRow(R.drawable.ic_globe, P(1), L.t("engine"), engName, () -> a.chooseEngine(render[0])),
                    toggleRow(R.drawable.ic_tabs, P(0), L.t("restore"), L.t("restore_sub"), a.on("restore", true), () -> a.togglePref("restore", true)),
                    toggleRow(R.drawable.ic_desktop, P(4), L.t("desktop"), L.t("desktop_sub"), a.on("desktop", false), a::toggleDesktop),
                    toggleRow(R.drawable.ic_flash, P(5), L.t("datasaver"), L.t("datasaver_sub"), a.on("datasaver", false), a::toggleDataSaver),
                    toggleRow(R.drawable.ic_refresh, P(2), L.t("pull"), L.t("pull_sub"), a.on("pull", true), a::togglePull),
                    toggleRow(R.drawable.ic_video, P(3), L.t("autoplay"), L.t("autoplay_sub"), a.on("autoplay", true), () -> a.toggleWebPref("autoplay", true)),
                    toggleRow(R.drawable.ic_js, P(5), L.t("js"), L.t("js_sub"), a.on("js", true), () -> a.toggleWebPref("js", true)));

            group(c, "✨  Baatora AI",
                    actionRow(R.drawable.ic_star, new int[]{0xFF7C4DFF, 0xFFFF4081}, "Baatora AI kholein", "Chat + Voice", () -> { p.d.dismiss(); a.ai.open(); }),
                    toggleRow(R.drawable.ic_star, new int[]{0xFFFF8A00, 0xFFFF4081}, "Floating AI button", "Chamakta button screen par (kahin bhi khiskayein)",
                            a.on("aiBtn", true), a::toggleAiButton),
                    toggleRow(R.drawable.ic_speaker, new int[]{0xFF00BFA5, 0xFF00796B}, "Jawab bol kar sunayein", "AI ka har jawab awaaz me",
                            a.on("aiSpeak", false), () -> a.togglePref("aiSpeak", false)),
                    actionRow(R.drawable.ic_mic, new int[]{0xFFFF4081, 0xFFC51162}, "Voice Assistant", "Bol kar poochhiye", () -> { p.d.dismiss(); a.ai.voice(); }));

            group(c, "🛡  " + L.t("s_privacy"),
                    actionRow(R.drawable.ic_vpn, new int[]{0xFF69F0AE, 0xFF00A152}, L.t("vpn"),
                            a.vpnActive() ? L.t("vpn_on") + " ✓" : L.t("vpn_off"), () -> { p.d.dismiss(); vpn(); }),
                    toggleRow(R.drawable.ic_adblock, P(6), L.t("adblock"), L.t("adblock_sub"), a.adBlock, a::toggleAdBlock),
                    toggleRow(R.drawable.ic_fullscreen, P(7), L.t("popup"), L.t("popup_sub"), a.on("popupBlock", true), () -> a.toggleWebPref("popupBlock", true)),
                    toggleRow(R.drawable.ic_info, P(1), L.t("safe"), L.t("safe_sub"), a.on("safe", true), () -> a.toggleWebPref("safe", true)),
                    toggleRow(R.drawable.ic_cookie, P(5), L.t("tpc"), L.t("tpc_sub"), a.on("tpc", true), () -> a.toggleWebPref("tpc", true)),
                    actionRow(R.drawable.ic_broom, new int[]{0xFFFFB74D, 0xFFE65100}, L.t("clear"), L.t("clear_sub"), a::clearData));

            group(c, "⬇  " + L.t("downloads"),
                    toggleRow(R.drawable.ic_flash, new int[]{Ui.GOLD, Ui.ORANGE}, L.t("turbo"), L.t("turbo_sub"), a.on("turbo", true), () -> a.togglePref("turbo", true)),
                    toggleRow(R.drawable.ic_download, P(6), L.t("ask_dl"), "", a.on("askDl", true), () -> a.togglePref("askDl", true)),
                    toggleRow(R.drawable.ic_bell, P(0), L.t("notif_toggle"), "", a.on("notif", true), () -> a.togglePref("notif", true)),
                    actionRow(R.drawable.ic_folder, P(2), L.t("downloads"), "", () -> downloads()));

            group(c, "ℹ  " + L.t("s_info"),
                    actionRow(R.drawable.ic_bell, P(3), L.t("notifications"), a.unreadNotifs() > 0 ? a.unreadNotifs() + " new" : "", () -> notifications()),
                    actionRow(R.drawable.ic_info, P(0), "Baatora", "Version " + appVer() + "  •  " + L.t("created") + " Anil Yadav", () -> about()));
        };
        p.d.show();
        render[0].run();
    }

    /** Ek group card: upar heading, andar rows aur beech me patli line. */
    void group(LinearLayout c, String title, View... rows) {
        TextView t = Ui.text(a, title, 13.5f, Ui.GOLD, true);
        t.setPadding(Ui.dp(6), Ui.dp(18), 0, Ui.dp(8));
        c.addView(t);
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(0, Ui.dp(4), 0, Ui.dp(4));
        card.setBackground(Ui.stroke(Ui.round(Ui.gl(0x14), 22), Ui.gl(0x1F), 1));
        for (int i = 0; i < rows.length; i++) {
            if (i > 0) {
                View line = new View(a);
                line.setBackgroundColor(Ui.gl(0x14));
                LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, 1);
                ll.leftMargin = Ui.dp(64);
                card.addView(line, ll);
            }
            card.addView(rows[i], new LinearLayout.LayoutParams(-1, -2));
        }
        c.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    // ═══════════════════════ THEME / LANGUAGE PICKERS ═══════════════════════

    void themeSheet(final Runnable after) {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("🎨  " + L.t("choose_theme") + "  (" + Ui.THEME_KEYS.length + ")"));
        GridLayout grid = new GridLayout(a);
        grid.setColumnCount(3);
        for (int i = 0; i < Ui.THEME_KEYS.length; i++) {
            final int idx = i;
            int[] t = Ui.THEMES[i];
            boolean sel = i == Ui.themeIdx;
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(Ui.dp(5), Ui.dp(6), Ui.dp(5), Ui.dp(8));

            FrameLayout prev = new FrameLayout(a);
            GradientDrawable pb = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{t[3], t[4], t[5]});
            pb.setCornerRadius(Ui.dp(18));
            if (sel) pb.setStroke(Ui.dp(3), t[8]); else pb.setStroke(Ui.dp(1), Ui.gl(0x33));
            prev.setBackground(pb);
            prev.setClipToOutline(true);
            View bar = new View(a);
            bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{t[0], t[1], t[2]}));
            prev.addView(bar, new FrameLayout.LayoutParams(-1, Ui.dp(22), Gravity.TOP));
            View search = new View(a);
            search.setBackground(Ui.round(Color.WHITE, 6));
            FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-1, Ui.dp(10), Gravity.TOP);
            sl.setMargins(Ui.dp(10), Ui.dp(6), Ui.dp(10), 0);
            prev.addView(search, sl);
            LinearLayout dots = new LinearLayout(a);
            dots.setOrientation(LinearLayout.HORIZONTAL);
            dots.setGravity(Gravity.CENTER);
            for (int k = 6; k <= 8; k++) {
                View dot = new View(a);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(t[k]);
                dot.setBackground(dg);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.dp(14), Ui.dp(14));
                dl.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
                dots.addView(dot, dl);
            }
            FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            dlp.topMargin = Ui.dp(4);
            prev.addView(dots, dlp);
            View nav = new View(a);
            nav.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{t[4], t[3], t[4]}));
            prev.addView(nav, new FrameLayout.LayoutParams(-1, Ui.dp(14), Gravity.BOTTOM));
            View navLine = new View(a);
            navLine.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{t[6], t[8], t[7]}));
            FrameLayout.LayoutParams nll = new FrameLayout.LayoutParams(-1, Ui.dp(2), Gravity.BOTTOM);
            nll.bottomMargin = Ui.dp(12);
            prev.addView(navLine, nll);
            if (sel) {
                ImageView ck = Ui.icon(a, R.drawable.ic_check, t[4]);
                ck.setBackground(Ui.round(t[8], 11));
                ck.setPadding(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
                FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(Ui.dp(22), Ui.dp(22), Gravity.BOTTOM | Gravity.END);
                cl.setMargins(0, 0, Ui.dp(6), Ui.dp(6));
                prev.addView(ck, cl);
            }
            cell.addView(prev, new LinearLayout.LayoutParams(-1, Ui.dp(84)));
            TextView name = Ui.text(a, Ui.THEME_NAMES[i], 12.5f, sel ? t[8] : Color.WHITE, true);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setPadding(Ui.dp(4), Ui.dp(5), Ui.dp(4), Ui.dp(5));
            name.setBackground(Ui.round(sel ? Ui.gl(0x26) : Ui.gl(0x10), 10));
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
            nlp.topMargin = Ui.dp(6);
            cell.addView(name, nlp);
            cell.setOnClickListener(v -> {
                dh[0].dismiss();
                a.setThemeKey(Ui.THEME_KEYS[idx]);
                if (after != null) after.run();
            });
            Ui.ripple(cell, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            grid.addView(cell, lp);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(grid);
        int maxH = (int) (a.getResources().getDisplayMetrics().heightPixels * 0.62f);
        box.addView(sv, new LinearLayout.LayoutParams(-1, maxH));
        dh[0] = showSheet(box);
    }

    void langSheet(final Runnable after) {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("🌐  " + L.t("choose_lang")));
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        int[][] badgeColors = {P(0), P(5), P(1), P(7), P(3), P(6), P(4)};
        int[] order = {2, 0, 1, 3, 4, 5, 6};   // English sabse pehle
        for (int i : order) {
            final int idx = i;
            boolean sel = i == L.idx;
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(14), Ui.dp(10));
            r.setBackground(sel ? Ui.stroke(Ui.round(Ui.gl(0x26), 18), Ui.GOLD, 2) : Ui.round(Ui.gl(0x14), 18));
            TextView badge = Ui.text(a, L.BADGE[i], 18, Ui.ON_COLOR, true);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(Ui.grad(badgeColors[i][0], badgeColors[i][1], 14));
            r.addView(badge, sq(46));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(14), 0, 0, 0);
            col.addView(Ui.text(a, L.NATIVE[i], 18, Color.WHITE, true));
            col.addView(Ui.text(a, L.SUB[i], 12, Ui.MUTED, false));
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            View radio = new View(a);
            GradientDrawable rg = new GradientDrawable();
            rg.setShape(GradientDrawable.OVAL);
            if (sel) { rg.setColor(Ui.GOLD); rg.setStroke(Ui.dp(4), Ui.gl(0x55)); }
            else rg.setStroke(Ui.dp(2), Ui.gl(0x88));
            radio.setBackground(rg);
            r.addView(radio, sq(22));
            r.setOnClickListener(v -> {
                dh[0].dismiss();
                a.setLang(L.KEYS[idx]);
                if (after != null) after.run();
            });
            Ui.ripple(r, false);
            list.addView(r, rowLp(8));
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv);
        dh[0] = showSheet(box);
    }

    /** Sundar chunav sheet (text size, search engine). */
    void choiceSheet(String title, String[] labels, int selected, java.util.function.IntConsumer pick) {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle(title));
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean sel = i == selected;
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(18), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            r.setBackground(sel ? Ui.grad(Ui.GOLD, Ui.ORANGE, 18) : Ui.round(Ui.gl(0x14), 18));
            r.addView(Ui.text(a, labels[i], 16, sel ? Ui.INK : Color.WHITE, sel), new LinearLayout.LayoutParams(0, -2, 1f));
            if (sel) r.addView(Ui.icon(a, R.drawable.ic_check, Ui.INK), sq(22));
            r.setOnClickListener(v -> { dh[0].dismiss(); pick.accept(idx); });
            Ui.ripple(r, false);
            box.addView(r, rowLp(8));
        }
        dh[0] = showSheet(box);
    }

    void section(LinearLayout c, String title) {
        TextView t = Ui.text(a, title, 13.5f, Ui.GOLD, true);
        t.setPadding(Ui.dp(4), Ui.dp(18), 0, Ui.dp(8));
        c.addView(t);
    }

    LinearLayout baseRow(int icon, int[] colors, String title, String sub) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        FrameLayout circ = new FrameLayout(a);
        GradientDrawable cg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        cg.setShape(GradientDrawable.OVAL);
        circ.setBackground(cg);
        ImageView ic = Ui.icon(a, icon, Color.WHITE);
        ic.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        circ.addView(ic, new FrameLayout.LayoutParams(-1, -1));
        r.addView(circ, sq(36));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(14), 0, Ui.dp(8), 0);
        col.addView(Ui.text(a, title, 15, Color.WHITE, true));
        if (sub != null && !sub.isEmpty()) {
            TextView s = Ui.text(a, sub, 12, Ui.MUTED, false);
            s.setPadding(0, Ui.dp(2), 0, 0);
            col.addView(s);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }

    View toggleRow(int icon, int[] colors, String title, String sub, boolean on, Runnable toggle) {
        LinearLayout r = baseRow(icon, colors, title, sub);
        final Switch sw = new Switch(a);
        sw.setChecked(on);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{0xFFFFC107, 0xFFB0BEC5}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{0xFFFF8A00, Ui.gl(0x55)}));
        sw.setOnCheckedChangeListener((b, checked) -> toggle.run());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        Ui.ripple(r, false);
        return r;
    }

    View actionRow(int icon, int[] colors, String title, String value, Runnable action) {
        LinearLayout r = baseRow(icon, colors, title, value);
        ImageView arrow = Ui.icon(a, R.drawable.ic_forward, Ui.MUTED);
        arrow.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
        r.addView(arrow, sq(28));
        r.setOnClickListener(v -> action.run());
        Ui.ripple(r, false);
        return r;
    }

    // ═══════════════════════ FREE VPN ═══════════════════════

    void vpn() {
        final Page p = page("Baatora VPN");
        ScrollView sv = new ScrollView(a);
        final LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(30));
        sv.addView(c);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        float den = Ui.density;
        FrameLayout stage = new FrameLayout(a);
        final RingView ra = new RingView(a, 0xFF69F0AE, Ui.CYAN, Ui.dp(4));
        final RingView rb = new RingView(a, Ui.GOLD, Ui.ORANGE, Ui.dp(3));
        ra.setRotationX(62); rb.setRotationX(62); rb.setRotation(70);
        ra.setCameraDistance(9000 * den); rb.setCameraDistance(9000 * den);
        stage.addView(rb, new FrameLayout.LayoutParams(Ui.dp(250), Ui.dp(250), Gravity.CENTER));
        stage.addView(ra, new FrameLayout.LayoutParams(Ui.dp(210), Ui.dp(210), Gravity.CENTER));
        // Beech me bada gol POWER button (dabate hi VPN chalu/band)
        final FrameLayout orb = new FrameLayout(a);
        orb.setElevation(Ui.dp(16));
        final ImageView pw = Ui.icon(a, R.drawable.ic_power, Color.WHITE);
        pw.setPadding(Ui.dp(40), Ui.dp(40), Ui.dp(40), Ui.dp(40));
        orb.addView(pw, new FrameLayout.LayoutParams(-1, -1));
        Ui.ripple(orb, true);
        stage.addView(orb, new FrameLayout.LayoutParams(Ui.dp(150), Ui.dp(150), Gravity.CENTER));
        c.addView(stage, new LinearLayout.LayoutParams(Ui.dp(260), Ui.dp(260)));

        // Status chip: ● Chalu / ● Band
        final TextView chip = Ui.text(a, "", 13, Color.WHITE, true);
        chip.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(6));
        LinearLayout.LayoutParams chl = new LinearLayout.LayoutParams(-2, -2);
        chl.gravity = Gravity.CENTER_HORIZONTAL;
        c.addView(chip, chl);
        final TextView status = Ui.text(a, "", 26, Color.WHITE, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, Ui.dp(10), 0, 0);
        c.addView(status, new LinearLayout.LayoutParams(-1, -2));
        final TextView sub = Ui.text(a, "", 14, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Ui.dp(4), 0, Ui.dp(16));
        c.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        // 3 chhote tiles: Ads roke | DNS | Speed
        LinearLayout stats = new LinearLayout(a);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] sv3 = new TextView[3];
        Object[][] st3 = {{R.drawable.ic_adblock, "Ads roke", new int[]{0xFFFF6E6E, 0xFFC62828}},
                {R.drawable.ic_lock, "DNS 1.1.1.1", new int[]{0xFF448AFF, 0xFF1A3FD8}},
                {R.drawable.ic_flash, "Speed", new int[]{0xFFFFD740, 0xFFFF9100}}};
        for (int i = 0; i < 3; i++) {
            LinearLayout tl = new LinearLayout(a);
            tl.setOrientation(LinearLayout.VERTICAL);
            tl.setGravity(Gravity.CENTER);
            tl.setPadding(Ui.dp(6), Ui.dp(12), Ui.dp(6), Ui.dp(12));
            tl.setBackground(Ui.stroke(Ui.round(Ui.gl(0x14), 20), Ui.gl(0x26), 1));
            tl.addView(Ui.iconTile(a, (int) st3[i][0], (int[]) st3[i][2], 38), sq(38));
            sv3[i] = Ui.text(a, "", 15, Color.WHITE, true);
            sv3[i].setPadding(0, Ui.dp(6), 0, 0);
            tl.addView(sv3[i]);
            TextView lb = Ui.text(a, (String) st3[i][1], 11, Ui.MUTED, false);
            tl.addView(lb);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
            tlp.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
            stats.addView(tl, tlp);
        }
        c.addView(stats, rowLp(16));

        // Bada button: power icon + text (font me na dikhne wala ⏻ nishaan hata diya)
        final LinearLayout main = new LinearLayout(a);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setGravity(Gravity.CENTER);
        main.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(16));
        main.setElevation(Ui.dp(6));
        final ImageView mIc = Ui.icon(a, R.drawable.ic_power, Color.WHITE);
        main.addView(mIc, sq(24));
        final TextView mTx = Ui.text(a, "", 17, Ui.ON_COLOR, true);
        mTx.setPadding(Ui.dp(10), 0, 0, 0);
        main.addView(mTx);
        Ui.ripple(main, false);
        c.addView(main, rowLp(18));

        final Runnable update = () -> {
            boolean on = a.myVpnOn();
            GradientDrawable og = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    on ? new int[]{0xFF69F0AE, 0xFF00A152} : new int[]{0xFF3D5AFE, 0xFF1A237E});
            og.setShape(GradientDrawable.OVAL);
            og.setStroke(Ui.dp(5), on ? 0x6669F0AE : 0x553D5AFE);
            orb.setBackground(og);
            chip.setText(on ? "●  CONNECTED" : "●  DISCONNECTED");
            chip.setTextColor(on ? 0xFF00E676 : 0xFFFF8A80);
            chip.setBackground(Ui.stroke(Ui.round(on ? 0x2200E676 : 0x22FF5252, 16), on ? 0x6600E676 : 0x66FF5252, 1));
            status.setText(on ? "Aap surakshit hain" : "VPN band hai");
            status.setTextColor(Ui.TEXT);
            sub.setText(on ? "Baatora Shield aapke phone ki hifaazat kar raha hai 🔒" : "Beech wala button ya neeche wala button dabayein");
            sv3[0].setText(String.valueOf(BaatoraVpn.blocked));
            sv3[1].setText(on ? "Encrypted" : "—");
            sv3[2].setText(on ? "Full ⚡" : "—");
            mTx.setText(on ? "VPN band karein" : "VPN chalu karein");
            GradientDrawable mb = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    on ? new int[]{0xFFFF6E6E, 0xFFC62828} : new int[]{0xFF00E676, 0xFF00A152});
            mb.setCornerRadius(Ui.dp(30));
            main.setBackground(mb);
        };
        main.setOnClickListener(v -> a.toggleMyVpn(update));
        orb.setOnClickListener(v -> a.toggleMyVpn(update));
        update.run();

        LinearLayout info = card("Baatora Shield kya karta hai?");
        Object[][] pts = {
                {R.drawable.ic_lock, new int[]{0xFF448AFF, 0xFF1A3FD8}, "Surakshit browsing", "Website ke pate encrypted rasta (1.1.1.1) se jaate hain — Wi-Fi wala nahi dekh sakta"},
                {R.drawable.ic_adblock, new int[]{0xFFFF6E6E, 0xFFC62828}, "Poore phone me ad block", "Har app me ad, tracker aur jua wali sites ruk jaati hain"},
                {R.drawable.ic_flash, new int[]{0xFFFFD740, 0xFFFF9100}, "Speed kam nahi", "Sirf DNS tunnel se jata hai, baaki internet seedha"},
                {R.drawable.ic_vpn, new int[]{0xFF69F0AE, 0xFF00A152}, "Ek tap me chalu", "Status bar me 🔑 dikhe to samjhein VPN chalu hai"}};
        for (Object[] pt : pts) {
            LinearLayout r = baseRow((int) pt[0], (int[]) pt[1], (String) pt[2], (String) pt[3]);
            r.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
            info.addView(r);
        }
        TextView hon = Ui.text(a, "ℹ Ye VPN aapka desh / IP nahi badalta — uske liye paid VPN server chahiye hota hai.", 12, Ui.MUTED, false);
        hon.setPadding(0, Ui.dp(10), 0, 0);
        info.addView(hon);
        c.addView(info, cardLp());

        final ValueAnimator spin = ValueAnimator.ofFloat(0f, 360f);
        spin.setDuration(2200);
        spin.setRepeatCount(ValueAnimator.INFINITE);
        spin.setInterpolator(new LinearInterpolator());
        final int[] tick = {0};
        spin.addUpdateListener(an -> {
            float v = (float) an.getAnimatedValue();
            ra.setPhase(v);
            rb.setPhase(-v * 1.3f);
        });
        spin.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationRepeat(android.animation.Animator animation) { update.run(); }
        });
        spin.start();
        p.d.setOnDismissListener(x -> spin.cancel());
        p.d.show();
    }

    // ═══════════════════════ NOTIFICATIONS ═══════════════════════

    void notifications() {
        final Page p = page("🔔  " + L.t("notifications"));
        final Runnable[] render = new Runnable[1];
        p.header.addView(Ui.iconButton(a, R.drawable.ic_check, v -> { a.markNotifsRead(); render[0].run(); }), sq(48));
        p.header.addView(Ui.iconButton(a, R.drawable.ic_delete, v ->
                confirm(R.drawable.ic_bell, new int[]{0xFFFF6E6E, 0xFFC62828}, L.t("notifications") + "?",
                        L.t("clear_btn") + " — " + L.t("notifications"), L.t("clear_btn"),
                        () -> { a.save("notifs", new JSONArray()); a.refreshHomes(); render[0].run(); })), sq(48));

        ScrollView sv = new ScrollView(a);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(24));
        sv.addView(list);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        render[0] = () -> {
            list.removeAllViews();
            JSONArray arr = a.load("notifs");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                final String type = o.optString("type");
                boolean unread = !o.optBoolean("read");
                LinearLayout r = new LinearLayout(a);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(14));
                GradientDrawable bg = Ui.round(unread ? Ui.gl(0x22) : Ui.gl(0x12), 20);
                if (unread) bg.setStroke(Ui.dp(1), (Ui.GOLD & 0x00FFFFFF) | 0x77000000);
                r.setBackground(bg);
                int icon; int[] col;
                switch (type) {
                    case "dl": icon = R.drawable.ic_download; col = new int[]{0xFF69F0AE, 0xFF00A152}; break;
                    case "dlfail": icon = R.drawable.ic_close; col = P(7); break;
                    case "shot": icon = R.drawable.ic_camera; col = P(3); break;
                    case "new": icon = R.drawable.ic_star; col = P(5); break;
                    case "welcome": icon = R.drawable.ic_flash; col = P(0); break;
                    default: icon = R.drawable.ic_bell; col = P(1);
                }
                r.addView(Ui.iconTile(a, icon, col, 44), sq(44));
                LinearLayout colv = new LinearLayout(a);
                colv.setOrientation(LinearLayout.VERTICAL);
                colv.setPadding(Ui.dp(12), 0, 0, 0);
                LinearLayout top = new LinearLayout(a);
                top.setOrientation(LinearLayout.HORIZONTAL);
                top.setGravity(Gravity.CENTER_VERTICAL);
                TextView t = Ui.text(a, o.optString("t"), 15, Color.WHITE, true);
                top.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                if (unread) {
                    View dot = new View(a);
                    GradientDrawable dg = new GradientDrawable();
                    dg.setShape(GradientDrawable.OVAL);
                    dg.setColor(Ui.GOLD);
                    dot.setBackground(dg);
                    top.addView(dot, sq(10));
                }
                colv.addView(top);
                TextView m = Ui.text(a, o.optString("m"), 13, 0xFFD5DEFF, false);
                m.setLineSpacing(0, 1.25f);
                m.setPadding(0, Ui.dp(3), 0, Ui.dp(4));
                colv.addView(m);
                colv.addView(Ui.text(a, timeAgo(o.optLong("time")), 11.5f, Ui.MUTED, false));
                r.addView(colv, new LinearLayout.LayoutParams(0, -2, 1f));
                r.setOnClickListener(v -> {
                    if (type.startsWith("dl")) downloads();
                    else if (type.equals("new") || type.equals("welcome")) about();
                });
                Ui.ripple(r, false);
                list.addView(r, rowLp(10));
            }
            if (arr.length() == 0) list.addView(empty(R.drawable.ic_bell, L.t("empty_notif"), "🔔"));
        };
        p.d.setOnDismissListener(x -> a.markNotifsRead());
        p.d.show();
        render[0].run();
    }

    static String timeAgo(long t) {
        long d = (System.currentTimeMillis() - t) / 1000;
        if (d < 60) return "Abhi";
        if (d < 3600) return (d / 60) + " min pehle";
        if (d < 86400) return (d / 3600) + " ghante pehle";
        return new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new Date(t));
    }

    // ═══════════════════════ SITE INFO (lock dabane par) ═══════════════════════

    void siteInfo() {
        MainActivity.Tab t = a.cur();
        final String u = t == null ? null : t.web.getUrl();
        if (!MainActivity.isRealUrl(u)) { a.urlBar.requestFocus(); return; }
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        String host = Uri.parse(u).getHost();
        boolean secure = u.startsWith("https://");
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(4), 0, 0, Ui.dp(14));
        head.addView(Ui.siteIcon(a, host, host, 50), sq(50));
        LinearLayout hc = new LinearLayout(a);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.setPadding(Ui.dp(12), 0, 0, 0);
        hc.addView(Ui.text(a, host, 17, Color.WHITE, true));
        hc.addView(Ui.text(a, secure ? "🔒 Surakshit connection (HTTPS)" : "⚠ Asurakshit connection — password na daalein",
                12.5f, secure ? 0xFF69F0AE : 0xFFFF8A80, false));
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(head);

        LinearLayout tmp = new LinearLayout(a);
        group(tmp, L.t("tools"),
                actionRow(R.drawable.ic_search, P(2), L.t("find"), "", () -> { dh[0].dismiss(); a.openFind(); }),
                actionRow(R.drawable.ic_book, P(5), L.t("reader"), "", () -> { dh[0].dismiss(); a.readerMode(); }),
                actionRow(R.drawable.ic_translate, P(1), L.t("translate"), "", () -> { dh[0].dismiss(); a.translatePage(); }),
                actionRow(R.drawable.ic_cookie, P(7), "Is site ki cookies hatayein", "", () -> { dh[0].dismiss(); a.clearSiteCookies(u); }),
                actionRow(R.drawable.ic_copy, P(6), L.t("copy_link"), "", () -> { dh[0].dismiss(); a.copy(u); }));
        box.addView(tmp);
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ RECENT (band kiye) TABS ═══════════════════════

    void recentSheet() {
        final JSONArray arr = a.load("closed");
        if (arr.length() == 0) { a.toast(L.t("recent") + ": 0"); return; }
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("🗂  " + L.t("recent")));
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final String u = o.optString("u");
            String host = Uri.parse(u).getHost();
            list.addView(row(o.optString("t"), host, host == null ? u : host,
                    v -> { dh[0].dismiss(); a.createTab(u, false, true); },
                    v -> { dh[0].dismiss(); JSONArray cur = a.load("closed"); JSONArray keep = new JSONArray();
                        for (int k = 0; k < cur.length(); k++) { JSONObject x = cur.optJSONObject(k);
                            if (x != null && !u.equals(x.optString("u"))) keep.put(x); }
                        a.save("closed", keep); recentSheet(); }), rowLp(8));
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, arr.length() > 6 ? Ui.dp(420) : -2));
        dh[0] = showSheet(box);
    }

    static LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(14);
        return lp;
    }
}
