package com.baatora.browser;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Baatora ke saare naye screens: Menu, Tabs, History, Bookmarks, Downloads, About. */
final class Screens {

    final MainActivity a;
    Screens(MainActivity a) { this.a = a; }

    static final int DARK_DIALOG = android.R.style.Theme_Material_Dialog_Alert;
    static final Pattern QUALITY = Pattern.compile("(?<![0-9])(2160|1440|1080|720|540|480|360|240|144)p?(?![0-9])");

    // ═══════════════════════ BASE BUILDERS ═══════════════════════

    static class Page { Dialog d; LinearLayout root, header; }

    Page page(String title) {
        Page p = new Page();
        p.d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        p.root = new LinearLayout(a);
        p.root.setOrientation(LinearLayout.VERTICAL);
        p.root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF0B1A5E, Ui.NAVY, 0xFF040A26}));
        p.header = new LinearLayout(a);
        p.header.setOrientation(LinearLayout.HORIZONTAL);
        p.header.setGravity(Gravity.CENTER_VERTICAL);
        p.header.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        p.header.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Ui.NAVY, Ui.NAVY2, Ui.BLUE}));
        final Dialog d = p.d;
        p.header.addView(Ui.iconButton(a, R.drawable.ic_back, v -> d.dismiss()), sq(48));
        TextView t = Ui.text(a, title, 20, Color.WHITE, true);
        t.setPadding(Ui.dp(6), 0, 0, 0);
        p.header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        p.root.addView(p.header, new LinearLayout.LayoutParams(-1, -2));
        p.d.setContentView(p.root, new ViewGroup.LayoutParams(-1, -1));
        Window w = p.d.getWindow();
        if (w != null) {
            w.setStatusBarColor(Ui.NAVY);
            w.setNavigationBarColor(0xFF040A26);
            w.setWindowAnimations(android.R.style.Animation_Dialog);
        }
        return p;
    }

    LinearLayout sheetBox() {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(22));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF15339A, 0xFF0A1A5C, Ui.NAVY});
        float r = Ui.dp(28);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bg);
        View handle = new View(a);
        handle.setBackground(Ui.round(0x66FFFFFF, 3));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(5));
        hl.gravity = Gravity.CENTER_HORIZONTAL;
        hl.bottomMargin = Ui.dp(12);
        box.addView(handle, hl);
        return box;
    }

    Dialog showSheet(View content) {
        Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
        }
        return d;
    }

    TextView sheetTitle(String s) {
        TextView t = Ui.text(a, s, 17, Ui.GOLD, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, Ui.dp(12));
        return t;
    }

    TextView pill(String s, Drawable bg, int textColor, View.OnClickListener l) {
        TextView t = Ui.text(a, s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(10), Ui.dp(13), Ui.dp(10), Ui.dp(13));
        t.setBackground(bg);
        t.setOnClickListener(l);
        Ui.ripple(t, false);
        return t;
    }

    EditText searchBox(String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Color.WHITE);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setBackground(Ui.stroke(Ui.round(0x1FFFFFFF, 26), 0x33FFFFFF, 1));
        e.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(12));
        Drawable ic = a.getDrawable(R.drawable.ic_search);
        if (ic != null) {
            ic = ic.mutate();
            ic.setTint(Ui.MUTED);
            e.setCompoundDrawablesRelativeWithIntrinsicBounds(ic, null, null, null);
            e.setCompoundDrawablePadding(Ui.dp(10));
        }
        return e;
    }

    LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(18), Ui.dp(16), Ui.dp(18), Ui.dp(18));
        c.setBackground(Ui.stroke(Ui.round(0x16FFFFFF, 22), 0x26FFFFFF, 1));
        if (title != null) {
            TextView t = Ui.text(a, title, 15, Ui.GOLD, true);
            t.setPadding(0, 0, 0, Ui.dp(8));
            c.addView(t);
        }
        return c;
    }

    TextView para(String s) {
        TextView t = Ui.text(a, s, 14.5f, 0xFFDDE5FF, false);
        t.setLineSpacing(0, 1.35f);
        return t;
    }

    View empty(int icon, String title, String sub) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(20), Ui.dp(70), Ui.dp(20), Ui.dp(20));
        c.addView(Ui.iconTile(a, icon, Ui.PALETTE[1], 84), sq(84));
        TextView t = Ui.text(a, title, 18, Color.WHITE, true);
        t.setPadding(0, Ui.dp(18), 0, Ui.dp(6));
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        TextView s = Ui.text(a, sub, 13.5f, Ui.MUTED, false);
        s.setGravity(Gravity.CENTER);
        c.addView(s);
        return c;
    }

    void confirm(String title, String msg, String ok, Runnable r) {
        new AlertDialog.Builder(a, DARK_DIALOG).setTitle(title).setMessage(msg)
                .setPositiveButton(ok, (d, w) -> r.run())
                .setNegativeButton("Cancel", null).show();
    }

    static LinearLayout.LayoutParams sq(int sizeDp) {
        return new LinearLayout.LayoutParams(Ui.dp(sizeDp), Ui.dp(sizeDp));
    }

    static LinearLayout.LayoutParams rowLp(int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Ui.dp(bottomDp);
        return lp;
    }

    ImageView logoView() {
        ImageView iv = new ImageView(a);
        iv.setImageResource(R.drawable.logo);
        iv.setBackground(Ui.round(Ui.NAVY, 12));
        iv.setClipToOutline(true);
        return iv;
    }

    // ═══════════════════════ 3-DOTS MENU ═══════════════════════

    static class Item {
        final int icon; final String label; final int[] colors; final boolean active; final Runnable run;
        Item(int i, String l, int[] c, boolean act, Runnable r) { icon = i; label = l; colors = c; active = act; run = r; }
    }

    static int[] P(int i) { return Ui.PALETTE[i % Ui.PALETTE.length]; }

    void menu() {
        ArrayList<Item> m = new ArrayList<>();
        m.add(new Item(R.drawable.ic_add, "Naya Tab", P(0), false, () -> a.createTab(MainActivity.HOME, false, true)));
        m.add(new Item(R.drawable.ic_incognito, "Incognito", P(4), false, () -> { a.createTab(MainActivity.HOME, true, true); a.toast("Incognito: history save nahi hogi"); }));
        m.add(new Item(R.drawable.ic_bookmark, "Bookmarks", P(2), false, () -> list("bookmarks", "Bookmarks")));
        m.add(new Item(R.drawable.ic_star, "Bookmark karein", P(5), false, a::addBookmark));
        m.add(new Item(R.drawable.ic_history, "History", P(1), false, () -> list("history", "History")));
        m.add(new Item(R.drawable.ic_download, "Downloads", P(6), false, this::downloads));
        m.add(new Item(R.drawable.ic_video, "Video download", P(3), false, this::videoDownload));
        m.add(new Item(R.drawable.ic_search, "Page me khojein", P(2), false, a::openFind));
        m.add(new Item(R.drawable.ic_share, "Share", P(0), false, () -> { if (a.web() != null) a.share(a.web().getUrl()); }));
        m.add(new Item(R.drawable.ic_copy, "Link copy", P(1), false, () -> { if (a.web() != null) a.copy(a.web().getUrl()); }));
        m.add(new Item(R.drawable.ic_desktop, "Desktop site", P(4), a.on("desktop", false), a::toggleDesktop));
        m.add(new Item(R.drawable.ic_moon, "Night mode", P(1), a.on("night", false), a::toggleNight));
        m.add(new Item(R.drawable.ic_shield, "Ad Block", P(6), a.adBlock, a::toggleAdBlock));
        m.add(new Item(R.drawable.ic_flash, "Data Saver", P(5), a.on("datasaver", false), a::toggleDataSaver));
        m.add(new Item(R.drawable.ic_refresh, "Pull refresh", P(2), a.on("pull", true), a::togglePull));
        m.add(new Item(R.drawable.ic_textsize, "Text size", P(3), false, a::chooseTextSize));
        m.add(new Item(R.drawable.ic_globe, "Search engine", P(1), false, a::chooseEngine));
        m.add(new Item(R.drawable.ic_doc, "PDF save", P(7), false, a::savePdf));
        m.add(new Item(R.drawable.ic_fullscreen, "Full screen", P(4), false, () -> a.setAppFull(true)));
        m.add(new Item(R.drawable.ic_delete, "Data clear", P(7), false, a::clearData));
        m.add(new Item(R.drawable.ic_info, "About", P(0), false, this::about));
        m.add(new Item(R.drawable.ic_exit, "Exit", P(3), false, a::finish));

        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();

        // Header: logo + naam
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(4), 0, 0, Ui.dp(14));
        head.addView(logoView(), sq(44));
        LinearLayout hc = new LinearLayout(a);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.setPadding(Ui.dp(12), 0, 0, 0);
        hc.addView(Ui.text(a, "Baatora Browser", 18, Color.WHITE, true));
        hc.addView(Ui.text(a, "Made in India 🇮🇳  •  by Anil Yadav", 12, 0xFFFFB74D, false));
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(head);

        View line = new View(a);
        line.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFF138808}));
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-1, Ui.dp(2));
        ll.bottomMargin = Ui.dp(10);
        box.addView(line, ll);

        GridLayout grid = new GridLayout(a);
        grid.setColumnCount(4);
        for (final Item it : m) {
            LinearLayout cell = new LinearLayout(a);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(Ui.dp(2), Ui.dp(9), Ui.dp(2), Ui.dp(7));

            FrameLayout holder = new FrameLayout(a);
            FrameLayout tile = Ui.iconTile(a, it.icon, it.active ? new int[]{0xFF69F0AE, 0xFF00A152} : it.colors, 54);
            holder.addView(tile, new FrameLayout.LayoutParams(Ui.dp(54), Ui.dp(54), Gravity.CENTER));
            if (it.active) {
                ImageView badge = Ui.icon(a, R.drawable.ic_check, 0xFF00A152);
                badge.setBackground(Ui.stroke(Ui.round(Color.WHITE, 10), 0xFF00A152, 1.5f));
                badge.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2));
                badge.setElevation(Ui.dp(8));
                holder.addView(badge, new FrameLayout.LayoutParams(Ui.dp(20), Ui.dp(20), Gravity.TOP | Gravity.END));
            }
            cell.addView(holder, new LinearLayout.LayoutParams(Ui.dp(62), Ui.dp(58)));

            TextView lb = Ui.text(a, it.label, 11.5f, it.active ? 0xFF69F0AE : Color.WHITE, it.active);
            lb.setGravity(Gravity.CENTER);
            lb.setMaxLines(2);
            lb.setPadding(0, Ui.dp(5), 0, 0);
            cell.addView(lb);

            cell.setOnClickListener(v -> { dh[0].dismiss(); it.run.run(); });
            Ui.ripple(cell, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            grid.addView(cell, lp);
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(grid);
        box.addView(sv);
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ TABS (Chrome jaisa) ═══════════════════════

    void tabs() {
        a.captureThumb(a.cur());
        final Dialog d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF0B1A5E, 0xFF06103A, 0xFF040A26}));

        final boolean[] incog = {a.cur() != null && a.cur().incognito};
        final String[] q = {""};
        final Runnable[] render = new Runnable[1];

        // Upar ki line: + | [gintee | incognito] | ⋮
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(8), Ui.dp(10));

        FrameLayout plus = Ui.iconTile(a, R.drawable.ic_add, new int[]{0xFFFF9800, 0xFFFF5722}, 52);
        Ui.ripple(plus, false);
        plus.setOnClickListener(v -> { d.dismiss(); a.createTab(MainActivity.HOME, incog[0], true); });
        top.addView(plus, sq(52));
        top.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));

        LinearLayout seg = new LinearLayout(a);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setGravity(Gravity.CENTER_VERTICAL);
        seg.setPadding(Ui.dp(5), Ui.dp(5), Ui.dp(5), Ui.dp(5));
        seg.setBackground(Ui.round(0x26FFFFFF, 28));
        final FrameLayout normalWrap = new FrameLayout(a);
        final TextView count = Ui.text(a, "0", 14, Color.WHITE, true);
        count.setGravity(Gravity.CENTER);
        normalWrap.addView(count, new FrameLayout.LayoutParams(Ui.dp(28), Ui.dp(28), Gravity.CENTER));
        final FrameLayout incogWrap = new FrameLayout(a);
        final ImageView incogIc = Ui.icon(a, R.drawable.ic_incognito, Color.WHITE);
        incogWrap.addView(incogIc, new FrameLayout.LayoutParams(Ui.dp(24), Ui.dp(24), Gravity.CENTER));
        seg.addView(normalWrap, new LinearLayout.LayoutParams(Ui.dp(64), Ui.dp(46)));
        seg.addView(incogWrap, new LinearLayout.LayoutParams(Ui.dp(64), Ui.dp(46)));
        normalWrap.setOnClickListener(v -> { incog[0] = false; render[0].run(); });
        incogWrap.setOnClickListener(v -> { incog[0] = true; render[0].run(); });
        top.addView(seg);
        top.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));

        final ImageView more = Ui.iconButton(a, R.drawable.ic_more, null);
        more.setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(a, more);
            pm.getMenu().add(0, 1, 0, "Sab tabs band karein");
            pm.getMenu().add(0, 2, 1, "Incognito tabs band karein");
            pm.setOnMenuItemClickListener(item -> {
                boolean onlyIncog = item.getItemId() == 2;
                for (int i = a.tabs.size() - 1; i >= 0; i--) {
                    if (!onlyIncog || a.tabs.get(i).incognito) a.closeTab(i);
                }
                render[0].run();
                return true;
            });
            pm.show();
        });
        top.addView(more, sq(48));
        root.addView(top);

        EditText search = searchBox("Tabs khojein");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(8));
        root.addView(search, slp);

        ScrollView sv = new ScrollView(a);
        final GridLayout grid = new GridLayout(a);
        grid.setColumnCount(2);
        grid.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(24));
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        render[0] = () -> {
            grid.removeAllViews();
            int normal = 0;
            for (MainActivity.Tab t : a.tabs) if (!t.incognito) normal++;
            count.setText(String.valueOf(normal));
            if (!incog[0]) {
                normalWrap.setBackground(Ui.round(Color.WHITE, 22));
                count.setTextColor(Ui.NAVY);
                count.setBackground(Ui.stroke(Ui.round(0x00000000, 7), Ui.NAVY, 2));
                incogWrap.setBackground(null);
                incogIc.setColorFilter(Color.WHITE);
            } else {
                normalWrap.setBackground(null);
                count.setTextColor(Color.WHITE);
                count.setBackground(Ui.stroke(Ui.round(0x00000000, 7), Color.WHITE, 2));
                incogWrap.setBackground(Ui.round(Color.WHITE, 22));
                incogIc.setColorFilter(0xFF5B1F9E);
            }
            String query = q[0].toLowerCase();
            int shown = 0;
            for (MainActivity.Tab t : a.tabs) {
                if (t.incognito != incog[0]) continue;
                String u = t.web.getUrl();
                String title = tabTitle(t);
                if (!query.isEmpty() && !(title + " " + u).toLowerCase().contains(query)) continue;
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                        GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
                lp.width = 0;
                lp.setMargins(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
                grid.addView(tabCard(t, d, render[0]), lp);
                shown++;
            }
            if (shown == 0) {
                View e = empty(incog[0] ? R.drawable.ic_incognito : R.drawable.ic_tabs,
                        incog[0] ? "Koi Incognito tab nahi" : "Koi tab nahi mila",
                        incog[0] ? "Upar + dabakar Incognito tab kholein" : "Upar + dabakar naya tab kholein");
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                        GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(0, 2, 1f));
                lp.width = 0;
                grid.addView(e, lp);
            }
        };

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int x, int y, int z) {}
            public void onTextChanged(CharSequence s, int x, int y, int z) {}
            public void afterTextChanged(Editable s) { q[0] = s.toString().trim(); render[0].run(); }
        });

        d.setContentView(root, new ViewGroup.LayoutParams(-1, -1));
        Window w = d.getWindow();
        if (w != null) { w.setStatusBarColor(0xFF0B1A5E); w.setNavigationBarColor(0xFF040A26); }
        d.show();
        render[0].run();
    }

    String tabTitle(MainActivity.Tab t) {
        String u = t.web.getUrl();
        if (u == null || u.startsWith(MainActivity.HOME)) return "Baatora Home";
        return TextUtils.isEmpty(t.title) ? u : t.title;
    }

    View tabCard(final MainActivity.Tab t, final Dialog d, final Runnable rerender) {
        boolean isCur = t == a.cur();
        String u = t.web.getUrl();
        boolean home = u == null || u.startsWith(MainActivity.HOME);
        String title = tabTitle(t);
        String host = home ? null : Uri.parse(u).getHost();

        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(6));
        GradientDrawable bg = Ui.round(t.incognito ? 0xFF2A1450 : 0xFF16286E, 24);
        if (isCur) Ui.stroke(bg, Ui.ORANGE, 3);
        c.setBackground(bg);
        c.setElevation(Ui.dp(6));

        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(6), Ui.dp(4), 0, Ui.dp(4));
        if (home) head.addView(logoView(), sq(22));
        else head.addView(Ui.siteIcon(a, title, host, 22), sq(22));
        TextView tt = Ui.text(a, title, 13, Color.WHITE, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tt.setPadding(Ui.dp(8), 0, Ui.dp(4), 0);
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView x = Ui.icon(a, R.drawable.ic_close, 0xFFFFB4B4);
        x.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        Ui.ripple(x, true);
        x.setOnClickListener(v -> {
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.closeTab(idx);
            rerender.run();
        });
        head.addView(x, sq(32));
        c.addView(head);

        FrameLayout thumb = new FrameLayout(a);
        thumb.setBackground(Ui.grad(0xFF13308F, Ui.NAVY, 18));
        thumb.setClipToOutline(true);
        if (t.thumb != null) {
            final ImageView iv = new ImageView(a);
            iv.setImageBitmap(t.thumb);
            iv.setScaleType(ImageView.ScaleType.MATRIX);
            thumb.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            iv.post(() -> {
                if (t.thumb == null || t.thumb.getWidth() == 0) return;
                float s = iv.getWidth() / (float) t.thumb.getWidth();
                Matrix mx = new Matrix();
                mx.setScale(s, s);
                iv.setImageMatrix(mx);
            });
        } else {
            View big = home ? logoView() : Ui.siteIcon(a, title, host, 64);
            thumb.addView(big, new FrameLayout.LayoutParams(Ui.dp(64), Ui.dp(64), Gravity.CENTER));
        }
        c.addView(thumb, new LinearLayout.LayoutParams(-1, Ui.dp(210)));

        c.setOnClickListener(v -> {
            d.dismiss();
            int idx = a.tabs.indexOf(t);
            if (idx >= 0) a.switchTab(idx);
        });
        Ui.ripple(c, false);
        return c;
    }

    // ═══════════════════════ HISTORY / BOOKMARKS ═══════════════════════

    void list(final String key, final String title) {
        final Page p = page(title);
        final boolean hist = key.equals("history");
        final Runnable[] render = new Runnable[1];

        p.header.addView(Ui.iconButton(a, R.drawable.ic_delete, v ->
                confirm(title + " saaf karein?", "Saari " + title.toLowerCase() + " hamesha ke liye hat jayegi.", "Saaf karein",
                        () -> { a.save(key, new JSONArray()); render[0].run(); })), sq(48));

        final EditText search = searchBox(title + " me khojein");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(6));
        p.root.addView(search, slp);

        ScrollView sv = new ScrollView(a);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), Ui.dp(4), Ui.dp(14), Ui.dp(24));
        sv.addView(list);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        render[0] = () -> {
            list.removeAllViews();
            JSONArray arr = a.load(key);
            String q = search.getText().toString().trim().toLowerCase();
            String lastGroup = null;
            int shown = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                final String t = o.optString("t"), u = o.optString("u");
                long time = o.optLong("time", 0);
                if (!q.isEmpty() && !(t + " " + u).toLowerCase().contains(q)) continue;
                if (hist) {
                    String g = dayLabel(time);
                    if (!g.equals(lastGroup)) {
                        TextView gh = Ui.text(a, g, 13.5f, Ui.GOLD, true);
                        gh.setPadding(Ui.dp(4), Ui.dp(14), 0, Ui.dp(8));
                        list.addView(gh);
                        lastGroup = g;
                    }
                }
                String host = Uri.parse(u).getHost();
                String sub = (host == null ? u : host) + (hist && time > 0 ? "  •  " + timeFmt.format(new Date(time)) : "");
                final int idx = i;
                list.addView(row(t, host, sub,
                        v -> { p.d.dismiss(); if (a.web() != null) a.web().loadUrl(u); },
                        v -> { JSONArray cur = a.load(key); cur.remove(idx); a.save(key, cur); render[0].run(); }),
                        rowLp(8));
                shown++;
            }
            if (shown == 0) {
                list.addView(empty(hist ? R.drawable.ic_history : R.drawable.ic_bookmark,
                        !q.isEmpty() ? "Kuch nahi mila" : (hist ? "Abhi koi history nahi" : "Abhi koi bookmark nahi"),
                        hist ? "Jo websites aap kholenge, wo yahan dikhengi"
                                : "Menu me ⭐ \"Bookmark karein\" dabakar pasandida page save karein"));
            }
        };
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int x, int y, int z) {}
            public void onTextChanged(CharSequence s, int x, int y, int z) {}
            public void afterTextChanged(Editable s) { render[0].run(); }
        });
        p.d.show();
        render[0].run();
    }

    View row(String title, String host, String sub, View.OnClickListener open, View.OnClickListener del) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(4), Ui.dp(10));
        r.setBackground(Ui.round(0x16FFFFFF, 18));
        r.addView(Ui.siteIcon(a, title, host, 42), sq(42));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
        TextView t = Ui.text(a, TextUtils.isEmpty(title) ? host : title, 15, Color.WHITE, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        TextView s = Ui.text(a, sub, 12, Ui.MUTED, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(s);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView x = Ui.iconButton(a, R.drawable.ic_close, del);
        x.setColorFilter(0xFFFF8A80);
        r.addView(x, sq(42));
        r.setOnClickListener(open);
        Ui.ripple(r, false);
        return r;
    }

    static String dayLabel(long t) {
        if (t <= 0) return "Pehle";
        Calendar now = Calendar.getInstance(), c = Calendar.getInstance();
        c.setTimeInMillis(t);
        if (sameDay(now, c)) return "Aaj";
        now.add(Calendar.DAY_OF_YEAR, -1);
        if (sameDay(now, c)) return "Kal";
        return new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(new Date(t));
    }

    static boolean sameDay(Calendar x, Calendar y) {
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR);
    }

    // ═══════════════════════ DOWNLOADS ═══════════════════════

    static class Dl { long id, total, done, time; String name, mime; int status; }

    static final String[] DL_FILTERS = {"Sab", "Video", "Audio", "Photo", "Docs", "Apps"};

    void downloads() {
        final Page p = page("Downloads");
        p.header.addView(Ui.iconButton(a, R.drawable.ic_folder, v -> {
            try { a.startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { a.toast("Downloads folder nahi khula"); }
        }), sq(48));

        LinearLayout stat = new LinearLayout(a);
        stat.setOrientation(LinearLayout.HORIZONTAL);
        stat.setGravity(Gravity.CENTER_VERTICAL);
        stat.setPadding(Ui.dp(18), Ui.dp(16), Ui.dp(18), Ui.dp(16));
        stat.setBackground(Ui.grad(0xFFFF8A00, 0xFFE91E63, 22));
        stat.setElevation(Ui.dp(6));
        stat.addView(Ui.iconTile(a, R.drawable.ic_download, new int[]{0x33FFFFFF, 0x22FFFFFF}, 48), sq(48));
        LinearLayout sc = new LinearLayout(a);
        sc.setOrientation(LinearLayout.VERTICAL);
        sc.setPadding(Ui.dp(14), 0, 0, 0);
        final TextView statBig = Ui.text(a, "0 files", 20, Color.WHITE, true);
        final TextView statSmall = Ui.text(a, "", 12.5f, 0xFFFFF3E0, false);
        sc.addView(statBig);
        sc.addView(statSmall);
        stat.addView(sc, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(-1, -2);
        stLp.setMargins(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(4));
        p.root.addView(stat, stLp);

        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(6));
        hs.addView(chips);
        p.root.addView(hs);

        ScrollView sv = new ScrollView(a);
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(24));
        sv.addView(list);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final String[] filter = {"Sab"};
        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable[] tick = new Runnable[1];
        final ArrayList<TextView> chipViews = new ArrayList<>();
        final Runnable styleChips = () -> {
            for (TextView c : chipViews) {
                boolean sel = c.getText().toString().equals(filter[0]);
                c.setBackground(sel ? Ui.grad(0xFFFFC107, 0xFFFF8A00, 20) : Ui.stroke(Ui.round(0x14FFFFFF, 20), 0x33FFFFFF, 1));
                c.setTextColor(sel ? Ui.NAVY : Color.WHITE);
            }
        };
        for (String f : DL_FILTERS) {
            TextView c = Ui.text(a, f, 13.5f, Color.WHITE, true);
            c.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
            c.setOnClickListener(v -> {
                filter[0] = f;
                styleChips.run();
                h.removeCallbacksAndMessages(null);
                tick[0].run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(8);
            chips.addView(c, lp);
            chipViews.add(c);
        }
        styleChips.run();

        tick[0] = () -> {
            boolean running = renderDownloads(list, statBig, statSmall, filter[0], () -> {
                h.removeCallbacksAndMessages(null);
                tick[0].run();
            });
            if (running && p.d.isShowing()) h.postDelayed(tick[0], 1000);
        };
        p.d.setOnDismissListener(x -> h.removeCallbacksAndMessages(null));
        p.d.show();
        tick[0].run();
    }

    ArrayList<Dl> queryDownloads() {
        ArrayList<Dl> out = new ArrayList<>();
        JSONArray ids = a.load("dl_ids");
        if (ids.length() == 0) return out;
        long[] arr = new long[ids.length()];
        for (int i = 0; i < ids.length(); i++) arr[i] = ids.optLong(i);
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query().setFilterById(arr));
            while (c != null && c.moveToNext()) {
                Dl d = new Dl();
                d.id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                d.name = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                d.mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
                d.status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                d.total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                d.done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                d.time = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP));
                out.add(d);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        Collections.sort(out, (x, y) -> Long.compare(y.id, x.id));
        return out;
    }

    static String fileType(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase();
        String m = mime == null ? "" : mime.toLowerCase();
        if (m.startsWith("video") || n.matches(".*\\.(mp4|mkv|webm|3gp|mov|avi|m4v)$")) return "Video";
        if (m.startsWith("audio") || n.matches(".*\\.(mp3|m4a|aac|wav|ogg|flac|opus)$")) return "Audio";
        if (m.startsWith("image") || n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp)$")) return "Photo";
        if (n.endsWith(".apk") || m.equals("application/vnd.android.package-archive")) return "Apps";
        if (n.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|zip|rar|7z)$") || m.contains("pdf")) return "Docs";
        return "Other";
    }

    static int typeIcon(String type) {
        switch (type) {
            case "Video": return R.drawable.ic_video;
            case "Audio": return R.drawable.ic_music;
            case "Photo": return R.drawable.ic_image;
            case "Apps": return R.drawable.ic_android;
            case "Docs": return R.drawable.ic_doc;
            default: return R.drawable.ic_file;
        }
    }

    static int[] typeColors(String type) {
        switch (type) {
            case "Video": return P(3);
            case "Audio": return P(4);
            case "Photo": return P(6);
            case "Apps": return new int[]{0xFF69F0AE, 0xFF00A152};
            case "Docs": return P(1);
            default: return P(2);
        }
    }

    boolean renderDownloads(LinearLayout list, TextView statBig, TextView statSmall, String filter, Runnable refresh) {
        list.removeAllViews();
        ArrayList<Dl> all = queryDownloads();
        boolean running = false;
        int doneCount = 0, active = 0;
        long doneBytes = 0;
        for (Dl d : all) {
            if (d.status == DownloadManager.STATUS_SUCCESSFUL) { doneCount++; doneBytes += Math.max(0, d.total); }
            else if (d.status != DownloadManager.STATUS_FAILED) { active++; running = true; }
        }
        statBig.setText(doneCount + " files");
        statSmall.setText(Formatter.formatFileSize(a, doneBytes) + " save hua" + (active > 0 ? "  •  " + active + " chal rahe" : ""));

        final SimpleDateFormat fmt = new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH);
        int shown = 0;
        for (final Dl d : all) {
            String type = fileType(d.name, d.mime);
            if (!filter.equals("Sab") && !filter.equals(type)) continue;
            shown++;
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(4), Ui.dp(12));
            r.setBackground(Ui.round(0x16FFFFFF, 18));
            r.addView(Ui.iconTile(a, typeIcon(type), typeColors(type), 46), sq(46));

            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
            TextView name = Ui.text(a, d.name == null ? "File" : d.name, 14.5f, Color.WHITE, true);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            col.addView(name);

            String status;
            int statusColor = Ui.MUTED;
            int pct = d.total > 0 ? (int) (d.done * 100 / d.total) : 0;
            switch (d.status) {
                case DownloadManager.STATUS_RUNNING:
                    status = pct + "%  •  " + Formatter.formatFileSize(a, d.done) + " / "
                            + (d.total > 0 ? Formatter.formatFileSize(a, d.total) : "?");
                    statusColor = 0xFF80D8FF;
                    break;
                case DownloadManager.STATUS_PENDING:
                    status = "Shuru ho raha hai...";
                    break;
                case DownloadManager.STATUS_PAUSED:
                    status = "Ruka hua — internet ka intezaar";
                    statusColor = 0xFFFFD180;
                    break;
                case DownloadManager.STATUS_SUCCESSFUL:
                    status = Formatter.formatFileSize(a, Math.max(0, d.total)) + "  •  " + fmt.format(new Date(d.time));
                    break;
                default:
                    status = "Download fail ho gaya";
                    statusColor = 0xFFFF8A80;
            }
            boolean inProgress = d.status == DownloadManager.STATUS_RUNNING
                    || d.status == DownloadManager.STATUS_PENDING || d.status == DownloadManager.STATUS_PAUSED;
            if (inProgress) {
                ProgressBar pb = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
                pb.setProgressDrawable(a.getDrawable(R.drawable.progress_bar));
                pb.setBackground(Ui.round(0x26FFFFFF, 3));
                pb.setMax(100);
                pb.setProgress(pct);
                LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-1, Ui.dp(6));
                pl.topMargin = Ui.dp(7);
                pl.bottomMargin = Ui.dp(4);
                col.addView(pb, pl);
            }
            TextView st = Ui.text(a, status, 12, statusColor, false);
            st.setPadding(0, Ui.dp(2), 0, 0);
            col.addView(st);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            ImageView x = Ui.iconButton(a, R.drawable.ic_delete, v -> confirm("File delete karein?",
                    (d.name == null ? "Ye file" : d.name) + " phone se hat jayegi.", "Delete", () -> {
                        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
                        try { dm.remove(d.id); } catch (Exception ignored) {}
                        JSONArray ids = a.load("dl_ids"), keep = new JSONArray();
                        for (int i = 0; i < ids.length(); i++) if (ids.optLong(i) != d.id) keep.put(ids.optLong(i));
                        a.save("dl_ids", keep);
                        refresh.run();
                    }));
            x.setColorFilter(0xFFFF8A80);
            r.addView(x, sq(42));

            r.setOnClickListener(v -> {
                if (d.status == DownloadManager.STATUS_SUCCESSFUL) openDownload(d.id);
                else a.toast(st.getText().toString());
            });
            Ui.ripple(r, false);
            list.addView(r, rowLp(10));
        }
        if (shown == 0) {
            list.addView(empty(R.drawable.ic_download,
                    filter.equals("Sab") ? "Abhi koi download nahi" : "Is type ki koi file nahi",
                    "Kisi website se file, photo ya video download karein — sab yahan dikhega"));
        }
        return running;
    }

    void openDownload(long id) {
        DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        try {
            Uri u = dm.getUriForDownloadedFile(id);
            String mime = dm.getMimeTypeForDownloadedFile(id);
            if (u == null) { a.toast("File nahi mili (shayad delete ho gayi)"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Exception e) {
            a.toast("Is file ko kholne wala app nahi mila");
        }
    }

    void downloadSheet(final String url, final String ua, final String mime, String name, long len) {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("Download karein"));

        String type = fileType(name, mime);
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(Ui.iconTile(a, typeIcon(type), typeColors(type), 56), sq(56));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, 0, 0);
        final EditText nameEdit = new EditText(a);
        nameEdit.setText(name);
        nameEdit.setTextColor(Color.WHITE);
        nameEdit.setTextSize(15);
        nameEdit.setSingleLine(true);
        nameEdit.setBackground(Ui.stroke(Ui.round(0x1FFFFFFF, 12), 0x33FFFFFF, 1));
        nameEdit.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
        col.addView(nameEdit);
        TextView size = Ui.text(a, (len > 0 ? Formatter.formatFileSize(a, len) + "  •  " : "") + type, 12.5f, Ui.MUTED, false);
        size.setPadding(Ui.dp(4), Ui.dp(6), 0, 0);
        col.addView(size);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(r);

        TextView info = Ui.text(a, "📁  Phone ke Download folder me save hoga", 12.5f, Ui.MUTED, false);
        info.setPadding(Ui.dp(4), Ui.dp(14), 0, Ui.dp(16));
        box.addView(info);

        LinearLayout btns = new LinearLayout(a);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, -2, 1f);
        b1.rightMargin = Ui.dp(6);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, -2, 1.4f);
        b2.leftMargin = Ui.dp(6);
        btns.addView(pill("Cancel", Ui.round(0x26FFFFFF, 26), Color.WHITE, v -> dh[0].dismiss()), b1);
        btns.addView(pill("⬇  Download", Ui.grad(0xFFFFC107, 0xFFFF6D00, 26), Ui.NAVY, v -> {
            String n = nameEdit.getText().toString().trim();
            dh[0].dismiss();
            a.startDownload(url, ua, mime, n.isEmpty() ? "Baatora_file" : n);
        }), b2);
        box.addView(btns);
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ VIDEO / AUDIO DOWNLOAD ═══════════════════════

    void videoDownload() {
        final MainActivity.Tab t = a.cur();
        if (t == null) return;
        String u = t.web.getUrl();
        if (MainActivity.isYouTube(u)) { youtubeInfo(); return; }
        if (!MainActivity.isRealUrl(u)) { a.toast("Pehle koi video wali website kholein"); return; }
        a.scanMedia(t, () -> mediaSheet(t));
    }

    void youtubeInfo() {
        new AlertDialog.Builder(a, DARK_DIALOG)
                .setTitle("YouTube video download")
                .setMessage("YouTube apni videos ko kisi bhi browser se download karne ki ijazat nahi deta " +
                        "(unke niyam aur copyright ki wajah se), isliye Baatora me YouTube download nahi hai.\n\n" +
                        "Offline dekhne ke liye YouTube app me video ke neeche ⬇ Download button use karein.\n\n" +
                        "Doosri websites par jahan seedhi video ya audio file hoti hai, wahan Baatora ka " +
                        "⬇ Download button apne aap dikh jayega.")
                .setPositiveButton("Samjh gaya", null).show();
    }

    static int quality(String u) {
        Matcher m = QUALITY.matcher(u);
        int best = 0;
        while (m.find()) {
            int v = Integer.parseInt(m.group(1));
            if (v > best) best = v;
        }
        return best;
    }

    static String ext(String u) {
        String path = Uri.parse(u).getPath();
        if (path == null) return "";
        int dot = path.lastIndexOf('.');
        return dot >= 0 ? path.substring(dot + 1).toUpperCase() : "";
    }

    static boolean isAudio(String u) {
        String e = ext(u);
        return e.equals("MP3") || e.equals("M4A") || e.equals("AAC") || e.equals("OGG")
                || e.equals("WAV") || e.equals("FLAC") || e.equals("OPUS");
    }

    void mediaSheet(final MainActivity.Tab t) {
        if (MainActivity.isYouTube(t.web.getUrl())) { youtubeInfo(); return; }
        ArrayList<String> items;
        synchronized (t.media) { items = new ArrayList<>(t.media); }
        if (items.isEmpty()) {
            a.toast("Is page par koi video/audio file nahi mili. Video chala kar dobara try karein.");
            return;
        }
        Collections.sort(items, (x, y) -> quality(y) - quality(x));

        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheetBox();
        box.addView(sheetTitle("🎬  Video / Audio mila"));
        TextView sub = Ui.text(a, "Quality chunein aur download karein", 13, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, Ui.dp(12));
        box.addView(sub);

        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (final String u : items) {
            boolean audio = isAudio(u);
            int q = quality(u);
            String label = audio ? "Audio  •  " + ext(u)
                    : q > 0 ? q + "p" + (q >= 1080 ? "  Full HD" : q >= 720 ? "  HD" : "") + "  •  " + ext(u)
                    : "Video  •  " + ext(u);
            LinearLayout r = new LinearLayout(a);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
            r.setBackground(Ui.round(0x16FFFFFF, 18));
            r.addView(Ui.iconTile(a, audio ? R.drawable.ic_music : R.drawable.ic_video,
                    audio ? P(4) : P(3), 44), sq(44));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(12), 0, Ui.dp(8), 0);
            col.addView(Ui.text(a, label, 15, Color.WHITE, true));
            TextView fn = Ui.text(a, URLUtil.guessFileName(u, null, null), 11.5f, Ui.MUTED, false);
            fn.setSingleLine(true);
            fn.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            col.addView(fn);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView dl = pill("⬇", Ui.grad(0xFFFFC107, 0xFFFF6D00, 20), Ui.NAVY, v -> {
                dh[0].dismiss();
                a.onDownload(u, t.web.getSettings().getUserAgentString(), null, null, 0);
            });
            dl.setPadding(Ui.dp(18), Ui.dp(8), Ui.dp(18), Ui.dp(8));
            r.addView(dl);
            list.addView(r, rowLp(8));
        }
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, items.size() > 5 ? Ui.dp(360) : -2));
        dh[0] = showSheet(box);
    }

    // ═══════════════════════ ABOUT ═══════════════════════

    void about() {
        final Page p = page("About");
        ScrollView sv = new ScrollView(a);
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(30));
        sv.addView(c);
        p.root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // 3D logo + ghoomti rings
        float den = Ui.density;
        FrameLayout stage = new FrameLayout(a);
        final RingView ra = new RingView(a, Ui.ORANGE, Ui.GOLD, Ui.dp(4));
        final RingView rb = new RingView(a, Ui.CYAN, Ui.BLUE, Ui.dp(3));
        ra.setRotationX(66);
        rb.setRotationX(66);
        rb.setRotation(60);
        ra.setCameraDistance(9000 * den);
        rb.setCameraDistance(9000 * den);
        stage.addView(rb, new FrameLayout.LayoutParams(Ui.dp(220), Ui.dp(220), Gravity.CENTER));
        stage.addView(ra, new FrameLayout.LayoutParams(Ui.dp(185), Ui.dp(185), Gravity.CENTER));
        ImageView logo = logoView();
        logo.setBackground(Ui.round(Ui.NAVY, 30));
        logo.setElevation(Ui.dp(16));
        logo.setCameraDistance(9000 * den);
        stage.addView(logo, new FrameLayout.LayoutParams(Ui.dp(110), Ui.dp(110), Gravity.CENTER));
        c.addView(stage, new LinearLayout.LayoutParams(Ui.dp(230), Ui.dp(230)));

        final ValueAnimator spin = ValueAnimator.ofFloat(0f, 360f);
        spin.setDuration(1800);
        spin.setRepeatCount(ValueAnimator.INFINITE);
        spin.setInterpolator(new LinearInterpolator());
        spin.addUpdateListener(an -> {
            float v = (float) an.getAnimatedValue();
            ra.setPhase(v);
            rb.setPhase(-v * 1.3f);
        });
        spin.start();
        logo.setRotationY(-360);
        logo.animate().rotationY(0).setDuration(1500).setInterpolator(new DecelerateInterpolator(1.6f)).start();

        final TextView name = Ui.text(a, "Baatora", 38, Color.WHITE, true);
        c.addView(name);
        name.post(() -> name.getPaint().setShader(new LinearGradient(0, 0, name.getWidth(), 0,
                new int[]{Ui.GOLD, Ui.ORANGE, Ui.CYAN, Ui.BLUE}, null, Shader.TileMode.CLAMP)));
        c.addView(Ui.text(a, "Tez. Surakshit. Apna Browser.", 14, 0xFFB8F3FF, false));

        LinearLayout pills = new LinearLayout(a);
        pills.setOrientation(LinearLayout.HORIZONTAL);
        pills.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        TextView ver = Ui.text(a, "Version 2.0", 13, Color.WHITE, true);
        ver.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        ver.setBackground(Ui.stroke(Ui.round(0x1FFFFFFF, 20), 0x44FFFFFF, 1));
        pills.addView(ver);
        TextView made = Ui.text(a, "Made in India 🇮🇳", 13, Ui.NAVY, true);
        made.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        GradientDrawable tri = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF138808});
        tri.setCornerRadius(Ui.dp(20));
        made.setBackground(tri);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.leftMargin = Ui.dp(10);
        pills.addView(made, mlp);
        c.addView(pills);

        // Developer card
        LinearLayout dev = card(null);
        dev.setBackground(Ui.stroke(Ui.grad(0xFF1E3FB0, 0xFF3A1670, 24), 0x55FFC107, 1.5f));
        dev.addView(Ui.text(a, "👨‍💻  Created by", 13, 0xFFB8C6FF, false));
        TextView devName = Ui.text(a, "Anil Yadav", 30, Ui.GOLD, true);
        devName.setPadding(0, Ui.dp(2), 0, Ui.dp(10));
        dev.addView(devName);
        LinearLayout loc = new LinearLayout(a);
        loc.setOrientation(LinearLayout.HORIZONTAL);
        loc.addView(Ui.icon(a, R.drawable.ic_location, Ui.ORANGE), sq(22));
        TextView addr = Ui.text(a, "Manorama Nagar, Kolshet Road,\nDhokali Naka, Thane,\nMaharashtra, India", 14, Color.WHITE, false);
        addr.setLineSpacing(0, 1.3f);
        addr.setPadding(Ui.dp(10), 0, 0, 0);
        loc.addView(addr);
        dev.addView(loc);
        c.addView(dev, cardLp());

        LinearLayout me = card("Mere baare me");
        me.addView(para("Namaste! 🙏 Main Anil Yadav hoon, Thane (Maharashtra) se. Mujhe technology aur " +
                "naye apps banane ka shauk hai. Baatora mera apna banaya hua browser hai, jise maine " +
                "Bharat ke logon ke liye bahut mehnat aur pyaar se taiyaar kiya hai."));
        c.addView(me, cardLp());

        LinearLayout vision = card("Baatora ka sapna");
        vision.addView(para("Har Bharatiya ko ek aisa browser dena jo tez ho, surakshit ho, faltu ads se " +
                "bacha ho aur chalane me bilkul aasaan ho — apni bhasha me, apne andaaz me. " +
                "Baatora 100% Made in India hai. 🇮🇳"));
        c.addView(vision, cardLp());

        LinearLayout feat = card("Khaas features");
        String[] fs = {"Chrome jaise Tabs aur Incognito", "Ad Block aur Data Saver", "Night mode aur Desktop site",
                "Video/Audio download (jahan site ijazat de)", "Downloads manager, History, Bookmarks",
                "Voice search, Page me khojna, PDF save", "Full-screen video aur 3D intro"};
        for (String f : fs) {
            LinearLayout fr = new LinearLayout(a);
            fr.setOrientation(LinearLayout.HORIZONTAL);
            fr.setGravity(Gravity.CENTER_VERTICAL);
            fr.setPadding(0, Ui.dp(4), 0, Ui.dp(4));
            ImageView ck = Ui.icon(a, R.drawable.ic_check, Color.WHITE);
            ck.setBackground(Ui.round(0xFF00A152, 10));
            ck.setPadding(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
            fr.addView(ck, sq(20));
            TextView ft = Ui.text(a, f, 14, 0xFFDDE5FF, false);
            ft.setPadding(Ui.dp(10), 0, 0, 0);
            fr.addView(ft);
            feat.addView(fr);
        }
        c.addView(feat, cardLp());

        TextView foot = Ui.text(a, "© 2026 Anil Yadav  •  Sabhi adhikar surakshit\nJai Hind 🇮🇳", 12.5f, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setLineSpacing(0, 1.4f);
        foot.setPadding(0, Ui.dp(22), 0, 0);
        c.addView(foot);

        p.d.setOnDismissListener(x -> spin.cancel());
        p.d.show();
    }

    static LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(14);
        return lp;
    }
}
