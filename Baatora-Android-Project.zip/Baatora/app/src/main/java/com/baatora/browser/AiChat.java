package com.baatora.browser;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Baatora AI Saathi — sawaal poochho (likh kar ya bol kar), page ka saar Hindi me pao, jawab sun bhi sakte ho.
 * Bina key ke free AI (Pollinations) se chalta hai; behtar jawab ke liye apni free Google Gemini key daal sakte hain.
 */
final class AiChat {

    static final String SYS = "Tum 'Baatora AI' ho — Baatora browser (Made in India) ka dostana AI saathi. " +
            "User jis bhasha me poochhe usi me jawab do; Hinglish ya Hindi me poochhe to aasaan Hindi/Hinglish me. " +
            "Jawab saaf, sahi aur chhota rakho (zaroorat ho to points me). Agar pakka pata na ho to saaf bata do. " +
            "Markdown symbols (#, **) kam se kam use karo.";

    final MainActivity a;
    final Screens sc;
    final ExecutorService net = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    final ArrayList<String[]> history = new ArrayList<>(); // {role, text}

    Dialog d;
    LinearLayout list;
    ScrollView scroll;
    EditText input;
    boolean speakNext;
    String pageCtx; // "Is page ke baare me poochho" ke liye

    AiChat(MainActivity a, Screens sc) { this.a = a; this.sc = sc; }

    // ═══════════════════════ UI ═══════════════════════

    void open() {
        if (d != null && d.isShowing()) return;
        Screens.Page p = sc.page("✨  Baatora AI");
        d = p.d;
        p.header.addView(Ui.iconButton(a, R.drawable.ic_delete, v -> { history.clear(); pageCtx = null; list.removeAllViews(); welcome(); }), Screens.sq(48));
        p.header.addView(Ui.iconButton(a, R.drawable.ic_settings, v -> keySheet()), Screens.sq(48));

        scroll = new ScrollView(a);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(16));
        scroll.addView(list);
        p.root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // Jaldi wale buttons
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(6));
        hs.addView(chips);
        addChip(chips, "📄  Is page ka saar", new int[]{0xFF7C4DFF, 0xFF4B3FE0}, this::summarize);
        addChip(chips, "❓  Is page par sawaal", new int[]{0xFF00BFA5, 0xFF00796B}, this::askAboutPage);
        addChip(chips, "🌐  Page Hindi me", new int[]{0xFFFF8A00, 0xFFE65100}, this::translatePage);
        addChip(chips, "🎤  Bol kar poochho", new int[]{0xFFFF4081, 0xFFC51162}, this::listen);
        p.root.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        // Neeche likhne ki patti
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(12));
        input = new EditText(a);
        input.setHint("Kuch bhi poochho…");
        input.setHintTextColor(0xFF8A94C8);
        input.setTextColor(Color.WHITE);
        input.setTextSize(15);
        input.setMaxLines(4);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(12));
        input.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1A), 24), Ui.gl(0x33), 1));
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(roundBtn(R.drawable.ic_mic, new int[]{0xFFFF4081, 0xFFC51162}, v -> listen()), lp48());
        bar.addView(roundBtn(R.drawable.ic_forward, new int[]{0xFF7C4DFF, 0xFF1E5BFF}, v -> sendTyped()), lp48());
        p.root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        Window w = d.getWindow();
        if (w != null) w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (history.isEmpty()) welcome();
        else for (String[] h : history) bubble(h[0].equals("user"), h[1]);
        d.show();
    }

    LinearLayout.LayoutParams lp48() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46));
        l.leftMargin = Ui.dp(8);
        return l;
    }

    View roundBtn(int icon, int[] c, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(a);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, c);
        g.setShape(GradientDrawable.OVAL);
        f.setBackground(g);
        f.setElevation(Ui.dp(4));
        ImageView iv = Ui.icon(a, icon, Color.WHITE);
        iv.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        Ui.ripple(f, true);
        f.setOnClickListener(l);
        return f;
    }

    void addChip(LinearLayout row, String text, int[] c, Runnable r) {
        TextView t = Ui.text(a, text, 13, Ui.ON_COLOR, true);
        t.setPadding(Ui.dp(14), Ui.dp(9), Ui.dp(14), Ui.dp(9));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, c);
        g.setCornerRadius(Ui.dp(18));
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        Ui.ripple(t, false);
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-2, -2);
        l.rightMargin = Ui.dp(8);
        row.addView(t, l);
    }

    void welcome() {
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(18), Ui.dp(22), Ui.dp(18), Ui.dp(20));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF2A1B5E, 0xFF0D1B4F});
        g.setCornerRadius(Ui.dp(26));
        g.setStroke(Ui.dp(1), 0x557C4DFF);
        card.setBackground(g);
        TextView big = Ui.text(a, "✨", 40, Color.WHITE, false);
        card.addView(big);
        TextView t = Ui.text(a, "Namaste! Main Baatora AI hoon", 19, Ui.GOLD, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        card.addView(t);
        TextView s = Ui.text(a, "Mujhse kuch bhi poochhiye — likh kar ya 🎤 bol kar. Main khula hua page padh kar uska saar " +
                "Hindi me bata sakta hoon aur jawab bol kar suna bhi sakta hoon.", 13.5f, 0xFFDDE5FF, false);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(0, 1.3f);
        card.addView(s);
        String[] ex = {"Aaj ka mausam kaisa rehta hai Thane me?", "Mobile shop ke liye 5 business tips do", "Python kya hai, aasaan bhasha me samjhao"};
        for (final String e : ex) {
            TextView x = Ui.text(a, "💬  " + e, 13, Color.WHITE, false);
            x.setPadding(Ui.dp(12), Ui.dp(9), Ui.dp(12), Ui.dp(9));
            x.setBackground(Ui.round(Ui.gl(0x14), 14));
            x.setOnClickListener(v -> ask(e, null));
            Ui.ripple(x, false);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
            l.topMargin = Ui.dp(8);
            card.addView(x, l);
        }
        list.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    TextView bubble(boolean user, String text) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(user ? Gravity.END : Gravity.START);
        TextView t = Ui.text(a, text, 14.5f, Color.WHITE, false);
        t.setTextIsSelectable(true);
        t.setLineSpacing(0, 1.3f);
        t.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                user ? new int[]{0xFF7C4DFF, 0xFF1E5BFF} : new int[]{0xFF1E2A66, 0xFF16204F});
        float r = Ui.dp(18), s = Ui.dp(4);
        g.setCornerRadii(user ? new float[]{r, r, s, s, r, r, r, r} : new float[]{s, s, r, r, r, r, r, r});
        t.setBackground(g);
        t.setMaxWidth((int) (a.getResources().getDisplayMetrics().widthPixels * 0.82f));
        row.addView(t, new LinearLayout.LayoutParams(-2, -2));
        if (!user) {
            LinearLayout acts = new LinearLayout(a);
            acts.setOrientation(LinearLayout.HORIZONTAL);
            acts.setPadding(Ui.dp(4), Ui.dp(4), 0, 0);
            TextView sp = Ui.text(a, "🔊 Sunao", 12, 0xFFB8C6FF, true);
            sp.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(4));
            sp.setOnClickListener(v -> a.say(t.getText().toString()));
            TextView cp = Ui.text(a, "📋 Copy", 12, 0xFFB8C6FF, true);
            cp.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(4));
            cp.setOnClickListener(v -> a.copy(t.getText().toString()));
            acts.addView(sp);
            acts.addView(cp);
            row.addView(acts);
            t.setTag(acts);
        }
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
        l.topMargin = Ui.dp(10);
        list.addView(row, l);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        return t;
    }

    void keySheet() {
        LinearLayout box = sc.sheetBox();
        box.addView(sc.sheetTitle("🔑  Gemini key (optional)"));
        box.addView(sc.para("Baatora AI bina kisi key ke free chalta hai. Aur tez/behtar jawab ke liye Google ki FREE Gemini key " +
                "daal sakte hain: aistudio.google.com/apikey par 'Create API key' dabayein, copy karke yahan paste karein."));
        final EditText k = new EditText(a);
        k.setHint("AIza…");
        k.setText(a.prefs.getString("geminiKey", ""));
        k.setTextColor(Color.WHITE);
        k.setHintTextColor(0xFF8A94C8);
        k.setSingleLine(true);
        k.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        k.setBackground(Ui.stroke(Ui.round(Ui.gl(0x1A), 16), Ui.gl(0x33), 1));
        LinearLayout.LayoutParams kl = new LinearLayout.LayoutParams(-1, -2);
        kl.setMargins(0, Ui.dp(12), 0, Ui.dp(12));
        box.addView(k, kl);
        final Dialog[] sd = new Dialog[1];
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.rightMargin = Ui.dp(6);
        row.addView(sc.pill("Key banayein", Ui.round(Ui.gl(0x26), 22), Color.WHITE, v -> {
            sd[0].dismiss(); d.dismiss(); a.createTab("https://aistudio.google.com/apikey", false, true);
        }), l1);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.leftMargin = Ui.dp(6);
        row.addView(sc.pill("Save", Ui.grad(0xFF69F0AE, 0xFF00A152, 22), Ui.ON_COLOR, v -> {
            a.prefs.edit().putString("geminiKey", k.getText().toString().trim()).apply();
            a.toast(k.getText().toString().trim().isEmpty() ? "Free AI chalega" : "✓ Gemini key save ho gayi");
            sd[0].dismiss();
        }), l2);
        box.addView(row);
        sd[0] = sc.showSheet(box);
    }

    // ═══════════════════════ ACTIONS ═══════════════════════

    void sendTyped() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        input.setText("");
        ask(q, pageCtx);
    }

    void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Baatora AI se poochhiye…");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, L.key().equals("english") ? "en-IN" : "hi-IN");
        try { a.startActivityForResult(i, MainActivity.REQ_AIVOICE); }
        catch (Exception e) { a.toast("Is phone par voice available nahi hai"); }
    }

    /** Bol kar poochha gaya sawaal — jawab bol kar bhi sunayenge. */
    void onVoice(String text) {
        if (TextUtils.isEmpty(text)) return;
        speakNext = true;
        if (d == null || !d.isShowing()) open();
        ask(text, pageCtx);
    }

    void withPage(java.util.function.Consumer<String> done) {
        WebView w = a.web();
        String u = w == null ? null : w.getUrl();
        if (w == null || u == null || !u.startsWith("http")) { a.toast("Pehle koi website kholein"); return; }
        final String title = w.getTitle();
        w.evaluateJavascript("(function(){var a=document.querySelector('article')||document.querySelector('main')||document.body;" +
                "return (a.innerText||'').replace(/\\s+/g,' ').substring(0,6000);})()", v -> {
            String text;
            try { text = (String) new JSONTokener(v).nextValue(); } catch (Exception e) { text = null; }
            if (text == null || text.trim().length() < 40) { a.toast("Is page par padhne layak text nahi mila"); return; }
            done.accept("Page ka naam: " + title + "\nLink: " + u + "\nPage ka text: " + text);
        });
    }

    void summarize() {
        withPage(ctx -> ask("📄 Is page ka saar Hindi me batao",
                "Neeche diye web page ka saar aasaan Hindi me 5-7 chhote points me do, sabse zaroori baat pehle.\n\n" + ctx, true));
    }

    void askAboutPage() {
        withPage(ctx -> {
            pageCtx = ctx;
            a.toast("✓ Page padh liya — ab is page ke baare me kuch bhi poochhiye");
            input.setHint("Is page ke baare me poochhiye…");
            input.requestFocus();
        });
    }

    void translatePage() {
        withPage(ctx -> ask("🌐 Is page ko Hindi me samjhao",
                "Neeche diye web page ki mukhya baatein saral Hindi me anuvad karke batao.\n\n" + ctx, true));
    }

    void ask(String shown, String ctx) {
        ask(shown, ctx == null ? shown : "Is web page ke context me jawab do:\n" + ctx + "\n\nSawaal: " + shown, true);
    }

    void ask(String shown, final String prompt, boolean addShown) {
        if (d == null || !d.isShowing()) open();
        if (addShown) bubble(true, shown);
        final TextView ans = bubble(false, "✨ Soch raha hoon…");
        final View acts = (View) ans.getTag();
        if (acts != null) acts.setVisibility(View.GONE);
        final ArrayList<String[]> past = new ArrayList<>(history);
        history.add(new String[]{"user", shown});
        final boolean speak = speakNext;
        speakNext = false;
        net.execute(() -> {
            String r = reply(past, prompt);
            final String out = r == null
                    ? "😔 Abhi jawab nahi mil paya. Internet check karein ya thodi der baad koshish karein.\n(Settings ⚙ me free Gemini key daalne se AI aur pakka chalega.)"
                    : clean(r);
            ui.post(() -> {
                ans.setText(out);
                if (acts != null) acts.setVisibility(View.VISIBLE);
                if (r != null) {
                    history.add(new String[]{"model", out});
                    while (history.size() > 16) history.remove(0);
                    if (speak) a.say(out);
                }
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            });
        });
    }

    static String clean(String s) {
        return s.replace("**", "").replaceAll("(?m)^#{1,6}\\s*", "").replaceAll("(?m)^\\s*[-*]\\s+", "• ").trim();
    }

    // ═══════════════════════ NETWORK ═══════════════════════

    String reply(ArrayList<String[]> past, String prompt) {
        String key = a.prefs.getString("geminiKey", "").trim();
        if (!key.isEmpty()) {
            for (String m : new String[]{"gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash"}) {
                String r = gemini(key, m, past, prompt);
                if (r != null) return r;
            }
        }
        String r = pollinationsChat(past, prompt);
        if (r != null) return r;
        return pollinationsGet(prompt);
    }

    String gemini(String key, String model, ArrayList<String[]> past, String prompt) {
        try {
            JSONObject body = new JSONObject();
            JSONArray contents = new JSONArray();
            for (String[] h : past) contents.put(new JSONObject().put("role", h[0].equals("user") ? "user" : "model")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", h[1]))));
            contents.put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", prompt))));
            body.put("contents", contents);
            body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", SYS))));
            String res = post("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key="
                    + URLEncoder.encode(key, "UTF-8"), body.toString());
            if (res == null) return null;
            JSONArray parts = new JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text"));
            return sb.length() == 0 ? null : sb.toString();
        } catch (Exception e) { return null; }
    }

    String pollinationsChat(ArrayList<String[]> past, String prompt) {
        try {
            JSONArray msgs = new JSONArray();
            msgs.put(new JSONObject().put("role", "system").put("content", SYS));
            for (String[] h : past) msgs.put(new JSONObject().put("role", h[0].equals("user") ? "user" : "assistant").put("content", h[1]));
            msgs.put(new JSONObject().put("role", "user").put("content", prompt));
            JSONObject body = new JSONObject().put("model", "openai").put("messages", msgs).put("private", true);
            String res = post("https://text.pollinations.ai/openai", body.toString());
            if (res == null) return null;
            res = res.trim();
            if (res.startsWith("{")) {
                JSONObject o = new JSONObject(res);
                if (o.has("choices")) return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", null);
                return null;
            }
            return res.isEmpty() ? null : res;
        } catch (Exception e) { return null; }
    }

    String pollinationsGet(String prompt) {
        try {
            String p = prompt.length() > 1500 ? prompt.substring(0, 1500) : prompt;
            String res = get("https://text.pollinations.ai/" + URLEncoder.encode(p, "UTF-8").replace("+", "%20")
                    + "?private=true&system=" + URLEncoder.encode(SYS, "UTF-8").replace("+", "%20"));
            return res == null || res.trim().isEmpty() || res.trim().startsWith("{\"error") ? null : res.trim();
        } catch (Exception e) { return null; }
    }

    static String post(String url, String json) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream o = c.getOutputStream()) { o.write(json.getBytes("UTF-8")); }
            if (c.getResponseCode() / 100 != 2) return null;
            return read(c.getInputStream());
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    static String get(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            if (c.getResponseCode() / 100 != 2) return null;
            return read(c.getInputStream());
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    static String read(InputStream in) throws Exception {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = i.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        }
    }
}
