package com.baatora.browser;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Baatora AI Saathi — likh kar ya bol kar sawaal, page ka saar Hindi me, jawab bol kar bhi.
 * Free AI (Pollinations) se chalta hai, jawab turant likhta hua aata hai (streaming).
 */
final class AiChat {

    static final String SYS = "Tum 'Baatora AI' ho — Baatora browser (Made in India, banaya Anil Yadav ne) ka dostana AI saathi. " +
            "User jis bhasha me poochhe usi me jawab do; Hinglish ya Hindi me poochhe to aasaan Hindi/Hinglish me. " +
            "Jawab saaf, sahi aur chhota rakho (zaroorat ho to points me). Agar pakka pata na ho to saaf bata do. " +
            "Markdown symbols (#, **) mat lagao.";

    static final String[] LANG_NAME = {"Hinglish (Roman lipi me Hindi)", "Hindi (Devanagari lipi)", "English", "Bhojpuri",
            "Marathi", "Bengali (Bangla)", "Punjabi (Gurmukhi)"};
    static final String[] LANG_CODE = {"hi-IN", "hi-IN", "en-IN", "hi-IN", "mr-IN", "bn-IN", "pa-IN"};

    static String sys() {
        return SYS + " Baatora app ki chuni hui bhasha " + LANG_NAME[L.idx] + " hai — jab tak user kisi aur bhasha me na poochhe, " +
                "isi bhasha me jawab do. Jawab turant aur seedha do, faltu bhoomika mat banao.";
    }

    static String voiceLang() { return LANG_CODE[L.idx]; }

    final MainActivity a;
    final Screens sc;
    final ExecutorService net = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    final ArrayList<String[]> history = new ArrayList<>(); // {role, text}

    Dialog d;
    LinearLayout list;
    ScrollView scroll;
    EditText input;
    boolean speakNext, noEndSpeak;
    String pageCtx;
    ValueAnimator logoSpin;

    AiChat(MainActivity a, Screens sc) { this.a = a; this.sc = sc; }

    boolean autoSpeak() { return a.prefs.getBoolean("aiSpeak", false); }

    // ═══════════════════════ CHAMAKTA LOGO ═══════════════════════

    /** Baatora logo + ghoomti rangeen ring (chamakta hua). */
    View glowLogo(int sizeDp, ValueAnimator[] out) {
        FrameLayout f = new FrameLayout(a);
        View glow = new View(a);
        GradientDrawable gg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0x66FF8A00, 0x667C4DFF, 0x6600E5FF});
        gg.setShape(GradientDrawable.OVAL);
        glow.setBackground(gg);
        f.addView(glow, new FrameLayout.LayoutParams(-1, -1));
        final RingView ring = new RingView(a, 0xFFFFC107, 0xFF00E5FF, Ui.dp(sizeDp > 50 ? 3 : 2.2f));
        f.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        final RingView ring2 = new RingView(a, 0xFFFF4081, 0xFF7C4DFF, Ui.dp(sizeDp > 50 ? 2.2f : 1.6f));
        int pad = Ui.dp(sizeDp * 0.07f);
        FrameLayout.LayoutParams r2 = new FrameLayout.LayoutParams(-1, -1);
        r2.setMargins(pad, pad, pad, pad);
        f.addView(ring2, r2);
        ImageView logo = new ImageView(a);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable lb = new GradientDrawable();
        lb.setShape(GradientDrawable.OVAL);
        lb.setColor(0xFF0A1440);
        logo.setBackground(lb);
        logo.setClipToOutline(true);
        int in = Ui.dp(sizeDp * 0.16f);
        FrameLayout.LayoutParams ll = new FrameLayout.LayoutParams(-1, -1);
        ll.setMargins(in, in, in, in);
        f.addView(logo, ll);
        ValueAnimator va = ValueAnimator.ofFloat(0f, 360f);
        va.setDuration(2600);
        va.setRepeatCount(ValueAnimator.INFINITE);
        va.setInterpolator(new LinearInterpolator());
        va.addUpdateListener(an -> {
            float v = (float) an.getAnimatedValue();
            ring.setPhase(v);
            ring2.setPhase(-v * 1.4f);
            float s = 0.92f + 0.08f * (float) Math.sin(Math.toRadians(v * 2));
            glow.setScaleX(s);
            glow.setScaleY(s);
            glow.setAlpha(0.55f + 0.35f * (float) Math.sin(Math.toRadians(v)));
        });
        va.start();
        if (out != null) out[0] = va;
        return f;
    }

    // ═══════════════════════ CHAT SCREEN ═══════════════════════

    void open() {
        if (d != null && d.isShowing()) return;
        d = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        FrameLayout bg = new FrameLayout(a);
        bg.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0B0F3A, 0xFF120A3A, 0xFF060920}));
        addBlob(bg, 0x557C4DFF, 280, Gravity.TOP | Gravity.START, -90, -60);
        addBlob(bg, 0x4400E5FF, 240, Gravity.TOP | Gravity.END, -80, 220);
        addBlob(bg, 0x33FF4081, 260, Gravity.BOTTOM | Gravity.START, -60, -40);

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        bg.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // ── Header ──
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(6), Ui.dp(10), Ui.dp(6), Ui.dp(10));
        head.addView(Ui.iconButton(a, R.drawable.ic_back, v -> d.dismiss()), Screens.sq(46));
        ValueAnimator[] sp = new ValueAnimator[1];
        head.addView(glowLogo(46, sp), Screens.sq(46));
        logoSpin = sp[0];
        LinearLayout tt = new LinearLayout(a);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setPadding(Ui.dp(10), 0, 0, 0);
        TextView t1 = Ui.text(a, "Baatora AI", 19, 0xFFFFFFFF, true);
        tt.addView(t1);
        TextView t2 = Ui.text(a, "●  Online  •  Aapka free AI saathi", 11.5f, 0xFF69F0AE, false);
        tt.addView(t2);
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(Ui.iconButton(a, R.drawable.ic_mic2, v -> voice()), Screens.sq(46));
        head.addView(Ui.iconButton(a, R.drawable.ic_settings, v -> settingsSheet()), Screens.sq(46));
        root.addView(head);
        View line = new View(a);
        line.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x00FF8A00, 0xFFFF8A00, 0xFF7C4DFF, 0xFF00E5FF, 0x0000E5FF}));
        root.addView(line, new LinearLayout.LayoutParams(-1, Ui.dp(1.5f)));

        scroll = new ScrollView(a);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(16));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ── Jaldi wale buttons ──
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(4));
        hs.addView(chips);
        addChip(chips, R.drawable.ic_doc, "Page ka saar", new int[]{0xFF7C4DFF, 0xFF4B3FE0}, this::summarize);
        addChip(chips, R.drawable.ic_info, "Page par sawaal", new int[]{0xFF00BFA5, 0xFF00796B}, this::askAboutPage);
        addChip(chips, R.drawable.ic_translate, "Page Hindi me", new int[]{0xFFFF8A00, 0xFFE65100}, this::translatePage);
        addChip(chips, R.drawable.ic_mic2, "Voice Assistant", new int[]{0xFFFF4081, 0xFFC51162}, this::voice);
        root.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        // ── Likhne ki patti (glass) ──
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(6), Ui.dp(5), Ui.dp(5), Ui.dp(5));
        GradientDrawable bb = new GradientDrawable();
        bb.setCornerRadius(Ui.dp(30));
        bb.setColor(0x26FFFFFF);
        bb.setStroke(Ui.dp(1.2f), 0x667C4DFF);
        bar.setBackground(bb);
        input = new EditText(a);
        input.setHint("Baatora AI se kuch bhi poochhiye…");
        input.setHintTextColor(0xFF9AA4D8);
        input.setTextColor(Color.WHITE);
        input.setTextSize(15);
        input.setMaxLines(4);
        input.setBackground(null);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(8), Ui.dp(10));
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(roundBtn(R.drawable.ic_mic2, new int[]{0xFFFF4081, 0xFFC51162}, v -> voice()), lp44());
        bar.addView(roundBtn(R.drawable.ic_forward, new int[]{0xFF7C4DFF, 0xFF1E5BFF}, v -> sendTyped()), lp44());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.setMargins(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(12));
        root.addView(bar, bl);

        d.setContentView(bg, new ViewGroup.LayoutParams(-1, -1));
        Window w = d.getWindow();
        if (w != null) {
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            w.setStatusBarColor(0xFF0B0F3A);
            w.setNavigationBarColor(0xFF060920);
        }
        d.setOnDismissListener(x -> { if (logoSpin != null) logoSpin.cancel(); });

        if (history.isEmpty()) welcome();
        else for (String[] h : history) bubble(h[0].equals("user"), h[1]);
        d.show();
    }

    void addBlob(FrameLayout f, int color, int sizeDp, int gravity, int mx, int my) {
        View v = new View(a);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{color, 0x00000000});
        g.setShape(GradientDrawable.OVAL);
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(Ui.dp(sizeDp / 2f));
        v.setBackground(g);
        FrameLayout.LayoutParams l = new FrameLayout.LayoutParams(Ui.dp(sizeDp), Ui.dp(sizeDp), gravity);
        if ((gravity & Gravity.END) == Gravity.END) l.rightMargin = Ui.dp(mx); else l.leftMargin = Ui.dp(mx);
        if ((gravity & Gravity.BOTTOM) == Gravity.BOTTOM) l.bottomMargin = Ui.dp(my); else l.topMargin = Ui.dp(my);
        f.addView(v, l);
    }

    LinearLayout.LayoutParams lp44() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44));
        l.leftMargin = Ui.dp(6);
        return l;
    }

    View roundBtn(int icon, int[] c, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(a);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, c);
        g.setShape(GradientDrawable.OVAL);
        f.setBackground(g);
        f.setElevation(Ui.dp(4));
        ImageView iv = Ui.icon(a, icon, Color.WHITE);
        iv.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        Ui.ripple(f, true);
        f.setOnClickListener(l);
        return f;
    }

    void addChip(LinearLayout row, int icon, String text, int[] c, Runnable r) {
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, c);
        g.setCornerRadius(Ui.dp(18));
        t.setBackground(g);
        t.setElevation(Ui.dp(3));
        t.addView(Ui.icon(a, icon, Color.WHITE), Screens.sq(17));
        TextView tx = Ui.text(a, text, 13, Ui.ON_COLOR, true);
        tx.setPadding(Ui.dp(7), 0, 0, 0);
        t.addView(tx);
        t.setOnClickListener(v -> r.run());
        Ui.ripple(t, false);
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-2, -2);
        l.rightMargin = Ui.dp(8);
        row.addView(t, l);
    }

    void welcome() {
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(18), Ui.dp(22), Ui.dp(18), Ui.dp(18));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0x552A1B5E, 0x330D1B4F});
        g.setCornerRadius(Ui.dp(28));
        g.setStroke(Ui.dp(1), 0x447C4DFF);
        card.setBackground(g);
        card.addView(glowLogo(92, null), Screens.sq(92));
        TextView t = Ui.text(a, "Namaste! Main Baatora AI hoon 🙏", 18, Ui.GOLD, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(12), 0, Ui.dp(6));
        card.addView(t);
        TextView s = Ui.text(a, "Kuch bhi poochhiye — likh kar ya 🎤 bol kar. Khule page ka saar Hindi me bata sakta hoon aur jawab bol kar suna bhi sakta hoon.",
                13.5f, 0xFFDDE5FF, false);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(0, 1.3f);
        card.addView(s);
        String[][] ex = {{"🌦", "Aaj Mumbai me mausam kaisa rahega?"}, {"🏪", "Mobile shop ki sale badhane ke 5 tips do"},
                {"🧠", "AI kya hota hai, aasaan bhasha me samjhao"}, {"✍", "Diwali ki shubhkamna ka message likho"}};
        for (final String[] e : ex) {
            LinearLayout x = new LinearLayout(a);
            x.setOrientation(LinearLayout.HORIZONTAL);
            x.setGravity(Gravity.CENTER_VERTICAL);
            x.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
            GradientDrawable xb = new GradientDrawable();
            xb.setCornerRadius(Ui.dp(16));
            xb.setColor(0x1AFFFFFF);
            xb.setStroke(Ui.dp(1), 0x22FFFFFF);
            x.setBackground(xb);
            x.addView(Ui.text(a, e[0], 16, Color.WHITE, false));
            TextView xt = Ui.text(a, e[1], 13.5f, Color.WHITE, false);
            xt.setPadding(Ui.dp(10), 0, 0, 0);
            x.addView(xt, new LinearLayout.LayoutParams(0, -2, 1f));
            x.addView(Ui.icon(a, R.drawable.ic_forward, 0xFF9AA4D8), Screens.sq(16));
            x.setOnClickListener(v -> ask(e[1], null));
            Ui.ripple(x, false);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
            l.topMargin = Ui.dp(8);
            card.addView(x, l);
        }
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.topMargin = Ui.dp(8);
        list.addView(card, cl);
    }

    /** Ek sundar action pill: icon + naam. */
    TextView actPill(LinearLayout row, int icon, String label, int[] c) {
        LinearLayout p = new LinearLayout(a);
        p.setOrientation(LinearLayout.HORIZONTAL);
        p.setGravity(Gravity.CENTER_VERTICAL);
        p.setPadding(Ui.dp(8), Ui.dp(5), Ui.dp(11), Ui.dp(5));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(Ui.dp(14));
        g.setColor(0x1FFFFFFF);
        g.setStroke(Ui.dp(1), (c[0] & 0x00FFFFFF) | 0x88000000);
        p.setBackground(g);
        FrameLayout ic = new FrameLayout(a);
        GradientDrawable ib = new GradientDrawable(GradientDrawable.Orientation.TL_BR, c);
        ib.setShape(GradientDrawable.OVAL);
        ic.setBackground(ib);
        ImageView iv = Ui.icon(a, icon, Color.WHITE);
        iv.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
        ic.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        p.addView(ic, Screens.sq(22));
        TextView tx = Ui.text(a, label, 12, 0xFFE3E8FF, true);
        tx.setPadding(Ui.dp(6), 0, 0, 0);
        p.addView(tx);
        Ui.ripple(p, false);
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-2, -2);
        l.rightMargin = Ui.dp(8);
        row.addView(p, l);
        tx.setTag(p);
        return tx;
    }

    TextView bubble(boolean user, String text) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(user ? Gravity.END : Gravity.START);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        if (!user) {
            ImageView av = new ImageView(a);
            av.setImageResource(R.drawable.logo);
            GradientDrawable ab = new GradientDrawable();
            ab.setShape(GradientDrawable.OVAL);
            ab.setStroke(Ui.dp(1.5f), 0xFFFFC107);
            ab.setColor(0xFF0A1440);
            av.setBackground(ab);
            av.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2));
            av.setClipToOutline(true);
            LinearLayout.LayoutParams avl = new LinearLayout.LayoutParams(Ui.dp(30), Ui.dp(30));
            avl.rightMargin = Ui.dp(8);
            row.addView(av, avl);
        }
        final TextView t = Ui.text(a, text, 14.5f, Color.WHITE, false);
        t.setTextIsSelectable(true);
        t.setLineSpacing(0, 1.32f);
        t.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                user ? new int[]{0xFF7C4DFF, 0xFF1E5BFF} : new int[]{0xE61E2766, 0xE6141C4E});
        float r = Ui.dp(20), s = Ui.dp(5);
        g.setCornerRadii(user ? new float[]{r, r, s, s, r, r, r, r} : new float[]{s, s, r, r, r, r, r, r});
        if (!user) g.setStroke(Ui.dp(1), 0x337C4DFF);
        t.setBackground(g);
        t.setElevation(Ui.dp(2));
        t.setMaxWidth((int) (a.getResources().getDisplayMetrics().widthPixels * (user ? 0.78f : 0.74f)));
        col.addView(t, new LinearLayout.LayoutParams(-2, -2));
        if (!user) {
            LinearLayout acts = new LinearLayout(a);
            acts.setOrientation(LinearLayout.HORIZONTAL);
            acts.setPadding(0, Ui.dp(6), 0, 0);
            final TextView spk = actPill(acts, R.drawable.ic_speaker, "Sunao", new int[]{0xFFFF8A00, 0xFFFF4081});
            ((View) spk.getTag()).setOnClickListener(v -> {
                if (a.tts != null && a.tts.isSpeaking()) { a.tts.stop(); spk.setText("Sunao"); return; }
                a.say(t.getText().toString());
                spk.setText("Roko");
                ui.postDelayed(new Runnable() {
                    public void run() {
                        if (a.tts != null && a.tts.isSpeaking()) ui.postDelayed(this, 400); else spk.setText("Sunao");
                    }
                }, 1500);
            });
            TextView cp = actPill(acts, R.drawable.ic_copy, "Copy", new int[]{0xFF448AFF, 0xFF1A3FD8});
            ((View) cp.getTag()).setOnClickListener(v -> a.copy(t.getText().toString()));
            TextView sh = actPill(acts, R.drawable.ic_share, "Share", new int[]{0xFF69F0AE, 0xFF00A152});
            ((View) sh.getTag()).setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.getText().toString() + "\n\n— Baatora AI");
                try { a.startActivity(Intent.createChooser(i, "Share")); } catch (Exception ignored) {}
            });
            col.addView(acts);
            t.setTag(acts);
        }
        row.addView(col, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-1, -2);
        l.topMargin = Ui.dp(12);
        list.addView(row, l);
        row.setAlpha(0f);
        row.setTranslationY(Ui.dp(12));
        row.animate().alpha(1f).translationY(0).setDuration(220).start();
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        return t;
    }

    // ═══════════════════════ AI SETTINGS ═══════════════════════

    void settingsSheet() {
        LinearLayout box = sc.sheetBox();
        LinearLayout hd = new LinearLayout(a);
        hd.setOrientation(LinearLayout.HORIZONTAL);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.addView(glowLogo(40, null), Screens.sq(40));
        TextView ht = Ui.text(a, "  Baatora AI Settings", 17, Ui.GOLD, true);
        hd.addView(ht);
        hd.setPadding(0, 0, 0, Ui.dp(10));
        box.addView(hd);
        box.addView(sc.toggleRow(R.drawable.ic_star, new int[]{0xFF7C4DFF, 0xFFFF4081}, "Floating AI button",
                "Screen par chamakta Baatora AI button", a.prefs.getBoolean("aiBtn", true), a::toggleAiButton));
        box.addView(sc.toggleRow(R.drawable.ic_speaker, new int[]{0xFFFF8A00, 0xFFFF4081}, "Jawab bol kar sunayein",
                "Likh kar poochhne par bhi AI bolega", autoSpeak(), () -> a.togglePref("aiSpeak", false)));
        box.addView(sc.actionRow(R.drawable.ic_delete, new int[]{0xFFFF6E6E, 0xFFC62828}, "Baatcheet saaf karein", "", () -> {
            history.clear(); pageCtx = null;
            if (list != null) { list.removeAllViews(); welcome(); }
            a.toast("Nayi baatcheet shuru");
        }));
        TextView n = Ui.text(a, "ℹ Baatora AI free AI service se chalta hai. Page ka saar maangne par page ka text AI ko jaata hai.", 12, Ui.MUTED, false);
        n.setPadding(0, Ui.dp(10), 0, 0);
        box.addView(n);
        sc.showSheet(box);
    }

    // ═══════════════════════ ACTIONS ═══════════════════════

    void sendTyped() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) return;
        input.setText("");
        ask(q, pageCtx);
    }

    /** Google ka voice popup (agar mic permission na mile). */
    void listenIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Baatora AI se poochhiye…");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang());
        try { a.startActivityForResult(i, MainActivity.REQ_AIVOICE); }
        catch (Exception e) { a.toast("Is phone par voice available nahi hai"); }
    }

    void onVoice(String text) {
        if (TextUtils.isEmpty(text)) return;
        speakNext = true;
        if (d == null || !d.isShowing()) open();
        ask(text, pageCtx);
    }

    // ═══════════════════════ VOICE ASSISTANT (apna sundar screen) ═══════════════════════

    Dialog vd;
    SpeechRecognizer rec;
    Runnable onVoiceDone;

    GradientDrawable glass(int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0x26FFFFFF, 0x0FFFFFFF});
        g.setCornerRadius(Ui.dp(radiusDp));
        g.setStroke(Ui.dp(1), 0x33FFFFFF);
        return g;
    }

    View glassIcon(int icon, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(a);
        GradientDrawable g = glass(100);
        g.setShape(GradientDrawable.OVAL);
        f.setBackground(g);
        ImageView iv = Ui.icon(a, icon, Color.WHITE);
        iv.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        Ui.ripple(f, true);
        f.setOnClickListener(l);
        return f;
    }

    /** Button ke neeche uska naam — sab ek seedh me. */
    View labeled(View btn, int sizeDp, Object label) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(btn, new LinearLayout.LayoutParams(Ui.dp(sizeDp), Ui.dp(sizeDp)));
        TextView t = label instanceof TextView ? (TextView) label : Ui.text(a, String.valueOf(label), 12.5f, 0xFFB8C6FF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(8), 0, 0);
        col.addView(t, new LinearLayout.LayoutParams(-2, -2));
        return col;
    }

    void voice() {
        if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(a)) { listenIntent(); return; }
        if (vd != null && vd.isShowing()) return;
        if (d == null || !d.isShowing()) open(); // chat neeche khula rahe, voice screen upar

        vd = new Dialog(a, android.R.style.Theme_Material_NoActionBar);
        FrameLayout bg = new FrameLayout(a);
        bg.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0A0E35, 0xFF150B3F, 0xFF04061A}));
        addBlob(bg, 0x667C4DFF, 320, Gravity.TOP | Gravity.START, -110, 120);
        addBlob(bg, 0x5500E5FF, 280, Gravity.TOP | Gravity.END, -110, 260);
        addBlob(bg, 0x44FF4081, 300, Gravity.BOTTOM | Gravity.END, -120, 60);
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(16));
        bg.addView(c, new FrameLayout.LayoutParams(-1, -1));

        // ── Upar: ✕ | logo + naam | bhasha ──
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(glassIcon(R.drawable.ic_close, v -> vd.dismiss()), Screens.sq(42));
        LinearLayout tc = new LinearLayout(a);
        tc.setOrientation(LinearLayout.HORIZONTAL);
        tc.setGravity(Gravity.CENTER);
        tc.addView(glowLogo(32, null), Screens.sq(32));
        TextView tn = Ui.text(a, "  Baatora Assistant", 16.5f, Color.WHITE, true);
        tc.addView(tn);
        top.addView(tc, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView lang = Ui.text(a, "🌐 " + L.NATIVE[L.idx], 12, 0xFFFFFFFF, true);
        lang.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(6));
        lang.setBackground(glass(16));
        top.addView(lang);
        c.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // ── Beech me orb: rangeen lehrein + chamakta logo ──
        final FrameLayout orb = new FrameLayout(a);
        final View[] waves = new View[3];
        int[] wc = {0xFF7C4DFF, 0xFF00E5FF, 0xFFFF4081};
        for (int i = 0; i < 3; i++) {
            View w = new View(a);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor((wc[i] & 0x00FFFFFF) | 0x22000000);
            g.setStroke(Ui.dp(2), (wc[i] & 0x00FFFFFF) | 0xAA000000);
            w.setBackground(g);
            orb.addView(w, new FrameLayout.LayoutParams(-1, -1));
            waves[i] = w;
        }
        final ValueAnimator[] la = new ValueAnimator[1];
        orb.addView(glowLogo(118, la), new FrameLayout.LayoutParams(Ui.dp(118), Ui.dp(118), Gravity.CENTER));
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(Ui.dp(230), Ui.dp(230));
        ol.topMargin = Ui.dp(14);
        c.addView(orb, ol);

        // Awaaz ki patti (equalizer)
        final LinearLayout eq = new LinearLayout(a);
        eq.setOrientation(LinearLayout.HORIZONTAL);
        eq.setGravity(Gravity.CENTER);
        final View[] bars = new View[9];
        for (int i = 0; i < bars.length; i++) {
            View bar = new View(a);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xFF7C4DFF, 0xFFFF4081, 0xFFFFC107});
            g.setCornerRadius(Ui.dp(3));
            bar.setBackground(g);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(Ui.dp(5), Ui.dp(30));
            bl.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
            eq.addView(bar, bl);
            bar.setScaleY(0.15f);
            bars[i] = bar;
        }
        c.addView(eq, new LinearLayout.LayoutParams(-2, Ui.dp(34)));

        final TextView status = Ui.text(a, "Boliye… main sun raha hoon", 19, Color.WHITE, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, Ui.dp(10), 0, Ui.dp(10));
        c.addView(status, new LinearLayout.LayoutParams(-1, -2));

        // Aapne kya kaha (glass card)
        LinearLayout hc = new LinearLayout(a);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        hc.setBackground(glass(18));
        hc.addView(Ui.text(a, "🗣  AAPNE KAHA", 10.5f, 0xFF9AA4D8, true));
        final TextView heard = Ui.text(a, "…", 15.5f, 0xFFFFD54F, true);
        heard.setPadding(0, Ui.dp(3), 0, 0);
        hc.addView(heard);
        c.addView(hc, new LinearLayout.LayoutParams(-1, -2));

        // Baatora AI ka jawab (glass card, scroll)
        LinearLayout ac = new LinearLayout(a);
        ac.setOrientation(LinearLayout.VERTICAL);
        ac.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        ac.setBackground(glass(18));
        LinearLayout ah = new LinearLayout(a);
        ah.setOrientation(LinearLayout.HORIZONTAL);
        ah.setGravity(Gravity.CENTER_VERTICAL);
        ImageView av = new ImageView(a);
        av.setImageResource(R.drawable.logo);
        av.setClipToOutline(true);
        GradientDrawable avb = new GradientDrawable();
        avb.setShape(GradientDrawable.OVAL);
        av.setBackground(avb);
        ah.addView(av, Screens.sq(18));
        ah.addView(Ui.text(a, "  BAATORA AI", 10.5f, 0xFF9AA4D8, true));
        ac.addView(ah);
        final ScrollView as = new ScrollView(a);
        final TextView answer = Ui.text(a, "", 15, 0xFFE8ECFF, false);
        answer.setLineSpacing(0, 1.32f);
        answer.setPadding(0, Ui.dp(4), 0, 0);
        as.addView(answer);
        ac.addView(as, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams acl = new LinearLayout.LayoutParams(-1, 0, 1f);
        acl.topMargin = Ui.dp(10);
        c.addView(ac, acl);

        // ── Neeche dock: Chat | 🎤 bada mic (ghoomti ring) | Chup ──
        LinearLayout dock = new LinearLayout(a);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8));
        dock.setBackground(glass(40));
        dock.addView(labeled(glassIcon(R.drawable.ic_chat, v -> { vd.dismiss(); open(); }), 48, "Chat"), new LinearLayout.LayoutParams(0, -2, 1f));
        final FrameLayout micBox = new FrameLayout(a);
        final View pulse = new View(a);
        GradientDrawable pg = new GradientDrawable();
        pg.setShape(GradientDrawable.OVAL);
        pg.setColor(0x66FF4081);
        pulse.setBackground(pg);
        micBox.addView(pulse, new FrameLayout.LayoutParams(-1, -1));
        final RingView micRing = new RingView(a, 0xFFFFC107, 0xFF00E5FF, Ui.dp(3));
        micBox.addView(micRing, new FrameLayout.LayoutParams(-1, -1));
        final FrameLayout again = (FrameLayout) roundBtn(R.drawable.ic_mic2, new int[]{0xFFFF4081, 0xFF7C4DFF}, null);
        ((ImageView) again.getChildAt(0)).setPadding(Ui.dp(18), Ui.dp(18), Ui.dp(18), Ui.dp(18));
        again.setElevation(Ui.dp(10));
        micBox.addView(again, new FrameLayout.LayoutParams(Ui.dp(70), Ui.dp(70), Gravity.CENTER));
        final TextView micLbl = Ui.text(a, "Boliye", 12, 0xFFFFFFFF, true);
        dock.addView(labeled(micBox, 90, micLbl), new LinearLayout.LayoutParams(0, -2, 1.3f));
        dock.addView(labeled(glassIcon(R.drawable.ic_speaker, v -> { if (a.tts != null) a.tts.stop(); status.setText("🔇 Chup ho gaya — 🎤 dabakar boliye"); }), 48, "Chup"),
                new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, -2);
        dl.topMargin = Ui.dp(12);
        c.addView(dock, dl);

        final boolean[] listening = {false};
        final ValueAnimator micAnim = ValueAnimator.ofFloat(0f, 1f);
        micAnim.setDuration(1200);
        micAnim.setRepeatCount(ValueAnimator.INFINITE);
        micAnim.setInterpolator(new LinearInterpolator());
        final float[] lvl = {0f};
        micAnim.addUpdateListener(an -> {
            float f = (float) an.getAnimatedValue();
            micRing.setPhase(f * 360f);
            if (listening[0]) { pulse.setScaleX(0.75f + f * 0.4f); pulse.setScaleY(0.75f + f * 0.4f); pulse.setAlpha(1f - f); }
            else pulse.setAlpha(0f);
            boolean talk = a.tts != null && a.tts.isSpeaking();
            long t = System.currentTimeMillis();
            for (int i = 0; i < bars.length; i++) {
                float base = listening[0] ? lvl[0] : talk ? 0.55f : 0.05f;
                float wob = (float) (0.5 + 0.5 * Math.sin(t / (listening[0] ? 90.0 : 120.0) + i * 0.9));
                float target = 0.15f + base * (0.35f + 0.65f * wob);
                bars[i].setScaleY(bars[i].getScaleY() * 0.6f + Math.min(1f, target) * 0.4f);
            }
        });
        micAnim.start();
        final java.util.function.Consumer<Boolean> micState = on -> {
            listening[0] = on;
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    on ? new int[]{0xFFFF1744, 0xFFFF4081} : new int[]{0xFFFF4081, 0xFF7C4DFF});
            g.setShape(GradientDrawable.OVAL);
            again.setBackground(g);
            micRing.setVisibility(on ? View.VISIBLE : View.INVISIBLE);
            micLbl.setText(on ? "Sun raha hoon" : "Boliye");
        };
        micState.accept(false);

        vd.setContentView(bg, new ViewGroup.LayoutParams(-1, -1));
        Window w = vd.getWindow();
        if (w != null) { w.setStatusBarColor(0xFF0A0E35); w.setNavigationBarColor(0xFF04061A); }

        // lehron ka animation (bolne ki awaaz ke hisaab se)
        final float[] level = {0f};
        final ValueAnimator wave = ValueAnimator.ofFloat(0f, 1f);
        wave.setDuration(1800);
        wave.setRepeatCount(ValueAnimator.INFINITE);
        wave.setInterpolator(new LinearInterpolator());
        wave.addUpdateListener(an -> {
            float f = (float) an.getAnimatedValue();
            for (int i = 0; i < 3; i++) {
                float p = (f + i / 3f) % 1f;
                float s = 0.5f + p * (0.45f + level[0] * 0.25f);
                waves[i].setScaleX(s);
                waves[i].setScaleY(s);
                waves[i].setAlpha(1f - p);
            }
        });
        wave.start();

        final Runnable[] startListen = new Runnable[1];
        startListen[0] = () -> {
            try {
                if (a.tts != null) a.tts.stop();
                if (rec != null) { try { rec.destroy(); } catch (Exception ignored) {} }
                rec = SpeechRecognizer.createSpeechRecognizer(a);
                rec.setRecognitionListener(new RecognitionListener() {
                    public void onReadyForSpeech(Bundle b) { status.setText("Boliye… main sun raha hoon"); heard.setText("…"); micState.accept(true); }
                    public void onBeginningOfSpeech() {}
                    public void onRmsChanged(float db) { level[0] = Math.max(0f, Math.min(1f, (db + 2f) / 12f)); lvl[0] = level[0]; }
                    public void onBufferReceived(byte[] b) {}
                    public void onEndOfSpeech() { status.setText("●  ●  ●"); level[0] = 0f; micState.accept(false); }
                    public void onError(int e) {
                        level[0] = 0f;
                        micState.accept(false);
                        status.setText(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                                ? "Kuch sunai nahi diya — 🎤 dabakar phir boliye" : "Mic me dikkat — 🎤 dabakar phir koshish karein");
                    }
                    public void onResults(Bundle r) {
                        ArrayList<String> res = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        String q = res == null || res.isEmpty() ? null : res.get(0);
                        if (TextUtils.isEmpty(q)) { status.setText("Kuch sunai nahi diya — phir boliye"); return; }
                        heard.setText(q);
                        status.setText("●  ●  ●");
                        answer.setText("");
                        askInto(q, pageCtx, answer, status, as);
                    }
                    public void onPartialResults(Bundle r) {
                        ArrayList<String> res = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (res != null && !res.isEmpty()) heard.setText(res.get(0));
                    }
                    public void onEvent(int t, Bundle b) {}
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang());
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 900L);
                i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 700L);
                rec.startListening(i);
            } catch (Exception e) {
                vd.dismiss();
                listenIntent();
            }
        };
        again.setOnClickListener(v -> { if (a.tts != null) a.tts.stop(); startListen[0].run(); });
        // Baat-cheet ki tarah: AI bol chuke to apne aap phir sunna shuru
        onVoiceDone = () -> ui.postDelayed(new Runnable() {
            int waited = 0;
            public void run() {
                if (vd == null || !vd.isShowing() || listening[0]) return;
                boolean speaking = a.tts != null && a.tts.isSpeaking();
                if (speaking || waited < 900) { waited += 300; ui.postDelayed(this, 300); return; }
                startListen[0].run();
            }
        }, 600);
        vd.setOnDismissListener(x -> {
            onVoiceDone = null;
            micAnim.cancel();
            if (a.tts != null) a.tts.stop();
            wave.cancel();
            if (la[0] != null) la[0].cancel();
            if (rec != null) { try { rec.destroy(); } catch (Exception ignored) {} rec = null; }
        });
        vd.show();
        startListen[0].run();
    }

    /** Voice screen ke liye: jawab overlay me likho + bolo, aur chat me bhi jodo. */
    void askInto(String q, String ctx, TextView answer, TextView status, ScrollView as) {
        speakNext = false;
        noEndSpeak = true;
        a.ensureTts();
        if (a.tts != null) a.tts.stop();
        final int[] spoken = {0};
        String prompt = ctx == null ? q : "Is web page ke context me jawab do:\n" + ctx + "\n\nSawaal: " + q;
        run(q, prompt, txt -> {
            if (status.getText().toString().startsWith("●")) status.setText("🔊 Baatora AI");
            answer.setText(txt);
            as.post(() -> as.fullScroll(View.FOCUS_DOWN));
            // jaise-jaise poora vakya aaye, turant bolna shuru (intezaar nahi)
            int end = -1;
            for (int k = txt.length() - 1; k >= spoken[0]; k--) {
                char ch = txt.charAt(k);
                if (ch == '.' || ch == '!' || ch == '?' || ch == '\u0964' || ch == '\n') { end = k + 1; break; }
            }
            if (end > spoken[0]) { a.sayAdd(txt.substring(spoken[0], end)); spoken[0] = end; }
        }, done -> {
            String full = answer.getText().toString();
            if (done && spoken[0] < full.length()) a.sayAdd(full.substring(Math.min(spoken[0], full.length())));
            spoken[0] = full.length();
            status.setText(done ? "🔊 Bol raha hoon…" : "😔 Jawab nahi mila — 🎤 dabakar phir poochhiye");
            if (done && onVoiceDone != null) onVoiceDone.run();
        });
    }

    void withPage(Consumer<String> done) {
        WebView w = a.web();
        final String u = w == null ? null : w.getUrl();
        if (w == null || u == null || !u.startsWith("http")) { a.toast("Pehle koi website kholein"); return; }
        final String title = w.getTitle();
        w.evaluateJavascript("(function(){var a=document.querySelector('article')||document.querySelector('main')||document.body;" +
                "return (a.innerText||'').replace(/\\s+/g,' ').substring(0,6000);})()", v -> {
            String text;
            try { text = (String) new JSONTokener(v).nextValue(); } catch (Exception e) { text = null; }
            if (text == null || text.trim().length() < 40) { a.toast("Is page par padhne layak text nahi mila"); return; }
            done.accept("Page ka naam: " + title + "\nLink: " + u + "\nPage ka text: " + text);
        });
    }

    void summarize() {
        withPage(ctx -> ask("📄 Is page ka saar Hindi me batao",
                "Neeche diye web page ka saar aasaan Hindi me 5-7 chhote points me do, sabse zaroori baat pehle.\n\n" + ctx, true));
    }

    void askAboutPage() {
        withPage(ctx -> {
            pageCtx = ctx;
            a.toast("✓ Page padh liya — ab is page ke baare me poochhiye");
            if (input != null) { input.setHint("Is page ke baare me poochhiye…"); input.requestFocus(); }
        });
    }

    void translatePage() {
        withPage(ctx -> ask("🌐 Is page ko Hindi me samjhao",
                "Neeche diye web page ki mukhya baatein saral Hindi me anuvad karke batao.\n\n" + ctx, true));
    }

    void ask(String shown, String ctx) {
        ask(shown, ctx == null ? shown : "Is web page ke context me jawab do:\n" + ctx + "\n\nSawaal: " + shown, true);
    }

    void ask(String shown, final String prompt, boolean addShown) {
        if (d == null || !d.isShowing()) open();
        run(shown, prompt, null, null);
    }

    /** Chat me sawaal + jawab (turant likhta hua). extra* = voice screen ke liye. */
    /** Kuch sawaalon ka jawab bina internet ke turant. */
    static String instant(String q) {
        String l = q.toLowerCase().trim();
        java.util.Date now = new java.util.Date();
        if (l.matches(".*(time kya|kitne baje|samay kya|what time|time batao|टाइम|समय).*"))
            return "Abhi " + new java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH).format(now) + " baje hain ⏰";
        if (l.matches(".*(aaj (ki )?date|aaj kya tarikh|tarikh kya|today.?s date|what.?s the date|तारीख).*"))
            return "Aaj " + new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.ENGLISH).format(now) + " hai 📅";
        if (l.matches("^(hi|hello|hey|namaste|namaskar|नमस्ते|हेलो|hii+)[!. ]*$"))
            return "Namaste! 🙏 Main Baatora AI hoon. Boliye, aaj main aapki kya madad karun?";
        if (l.matches(".*(tum kaun ho|aap kaun ho|who are you|tumhara naam|aapka naam).*"))
            return "Main Baatora AI hoon ✨ — Baatora browser ka apna AI saathi, jise Anil Yadav ne Bharat ke liye banaya hai. Kuch bhi poochhiye!";
        return null;
    }

    void run(String shown, String prompt, Consumer<String> extraText, Consumer<Boolean> extraDone) {
        if (d == null || !d.isShowing()) open();
        bubble(true, shown);
        final TextView ans = bubble(false, "●  ●  ●");
        final View acts = (View) ans.getTag();
        if (acts != null) acts.setVisibility(View.GONE);
        final ValueAnimator dots = ValueAnimator.ofFloat(0.3f, 1f);
        dots.setDuration(500);
        dots.setRepeatMode(ValueAnimator.REVERSE);
        dots.setRepeatCount(ValueAnimator.INFINITE);
        dots.addUpdateListener(an -> ans.setAlpha((float) an.getAnimatedValue()));
        dots.start();
        final ArrayList<String[]> past = new ArrayList<>(history);
        history.add(new String[]{"user", shown});
        final boolean speak = !noEndSpeak && (speakNext || autoSpeak());
        speakNext = false;
        noEndSpeak = false;
        final boolean[] first = {true};
        final String fast = prompt.equals(shown) ? instant(shown) : null;
        net.execute(() -> {
            String r = fast != null ? fast : reply(past, prompt, part -> ui.post(() -> {
                if (first[0]) { first[0] = false; dots.cancel(); ans.setAlpha(1f); }
                String c = clean(part);
                ans.setText(c);
                if (extraText != null) extraText.accept(c);
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            }));
            final String out = r == null
                    ? "😔 Abhi jawab nahi mil paya. Internet check karke thodi der baad phir poochhiye."
                    : clean(r);
            ui.post(() -> {
                dots.cancel();
                ans.setAlpha(1f);
                ans.setText(out);
                if (extraText != null) extraText.accept(out);
                if (acts != null) acts.setVisibility(View.VISIBLE);
                if (r != null) {
                    history.add(new String[]{"model", out});
                    while (history.size() > 16) history.remove(0);
                    if (speak) a.say(out);
                }
                if (extraDone != null) extraDone.accept(r != null);
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            });
        });
    }

    static String clean(String s) {
        return s.replace("**", "").replaceAll("(?m)^#{1,6}\\s*", "").replaceAll("(?m)^\\s*[-*]\\s+", "• ").trim();
    }

    // ═══════════════════════ NETWORK (free AI, turant jawab) ═══════════════════════

    /** Do raste ek saath: streaming (shabd-shabd) + seedha jawab. Jo pehle aaye wahi dikhao — taaki intezaar na ho. */
    String reply(ArrayList<String[]> past, String prompt, Consumer<String> partial) {
        final java.util.concurrent.atomic.AtomicReference<String> win = new java.util.concurrent.atomic.AtomicReference<>();
        final java.util.concurrent.atomic.AtomicBoolean flowing = new java.util.concurrent.atomic.AtomicBoolean(false);
        final java.util.concurrent.atomic.AtomicInteger fails = new java.util.concurrent.atomic.AtomicInteger();
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        new Thread(() -> {
            String r = streamChat(past, prompt, s -> { flowing.set(true); if (win.get() == null) partial.accept(s); });
            if (r != null && !r.trim().isEmpty()) { if (win.compareAndSet(null, r)) done.countDown(); }
            else if (fails.incrementAndGet() >= 2) done.countDown();
        }).start();
        new Thread(() -> {
            try { Thread.sleep(1800); } catch (InterruptedException ignored) {}
            if (win.get() != null || flowing.get()) { if (fails.incrementAndGet() >= 2) done.countDown(); return; }
            String r = pollinationsGet(prompt);
            if (r == null && !flowing.get()) r = pollinationsChat(past, prompt);
            if (r != null && !r.trim().isEmpty() && !flowing.get()) { if (win.compareAndSet(null, r)) done.countDown(); }
            else if (fails.incrementAndGet() >= 2) done.countDown();
        }).start();
        try { done.await(70, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        return win.get();
    }

    JSONArray messages(ArrayList<String[]> past, String prompt) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", sys()));
        for (int k = Math.max(0, past.size() - 6); k < past.size(); k++) { String[] h = past.get(k); msgs.put(new JSONObject().put("role", h[0].equals("user") ? "user" : "assistant").put("content", h[1])); }
        msgs.put(new JSONObject().put("role", "user").put("content", prompt));
        return msgs;
    }

    /** Jawab shabd-shabd aata hai (streaming) — isliye turant dikhne lagta hai. */
    String streamChat(ArrayList<String[]> past, String prompt, Consumer<String> partial) {
        HttpURLConnection c = null;
        try {
            JSONObject body = new JSONObject().put("model", "openai").put("messages", messages(past, prompt))
                    .put("stream", true).put("private", true);
            c = (HttpURLConnection) new URL("https://text.pollinations.ai/openai").openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(45000);
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "text/event-stream");
            try (OutputStream o = c.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
            if (c.getResponseCode() / 100 != 2) return null;
            String ct = String.valueOf(c.getContentType());
            StringBuilder sb = new StringBuilder();
            long last = 0;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                if (!ct.contains("event-stream")) {
                    String l; StringBuilder all = new StringBuilder();
                    while ((l = br.readLine()) != null) all.append(l).append('\n');
                    String s = all.toString().trim();
                    if (s.startsWith("{")) {
                        JSONObject o = new JSONObject(s);
                        return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", null);
                    }
                    return s.isEmpty() ? null : s;
                }
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.startsWith("data:")) continue;
                    String data = line.substring(5).trim();
                    if (data.equals("[DONE]")) break;
                    try {
                        JSONObject o = new JSONObject(data);
                        JSONArray ch = o.optJSONArray("choices");
                        if (ch == null || ch.length() == 0) continue;
                        JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
                        String piece = delta == null ? null : delta.optString("content", "");
                        if (piece != null && !piece.isEmpty() && !piece.equals("null")) {
                            sb.append(piece);
                            long now = System.currentTimeMillis();
                            if (partial != null && now - last > 70) { last = now; partial.accept(sb.toString()); }
                        }
                    } catch (Exception ignored) {}
                }
            }
            return sb.length() == 0 ? null : sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    String pollinationsChat(ArrayList<String[]> past, String prompt) {
        try {
            JSONObject body = new JSONObject().put("model", "openai").put("messages", messages(past, prompt)).put("private", true);
            String res = post("https://text.pollinations.ai/openai", body.toString());
            if (res == null) return null;
            res = res.trim();
            if (res.startsWith("{")) {
                JSONObject o = new JSONObject(res);
                if (o.has("choices")) return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", null);
                return null;
            }
            return res.isEmpty() ? null : res;
        } catch (Exception e) { return null; }
    }

    String pollinationsGet(String prompt) {
        try {
            String p = prompt.length() > 1500 ? prompt.substring(0, 1500) : prompt;
            String res = get("https://text.pollinations.ai/" + URLEncoder.encode(p, "UTF-8").replace("+", "%20")
                    + "?private=true&system=" + URLEncoder.encode(sys(), "UTF-8").replace("+", "%20"));
            return res == null || res.trim().isEmpty() || res.trim().startsWith("{\"error") ? null : res.trim();
        } catch (Exception e) { return null; }
    }

    static String post(String url, String json) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(60000);
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream o = c.getOutputStream()) { o.write(json.getBytes("UTF-8")); }
            if (c.getResponseCode() / 100 != 2) return null;
            return read(c.getInputStream());
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    static String get(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(60000);
            if (c.getResponseCode() / 100 != 2) return null;
            return read(c.getInputStream());
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    static String read(InputStream in) throws Exception {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = i.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        }
    }
}
