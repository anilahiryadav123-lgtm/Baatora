package com.baatora.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Baatora Browser — Made in India 🇮🇳
 * Multi-tab, Incognito, Ad Block, Night mode, Desktop site, Data saver,
 * Downloads, Bookmarks, History, Voice search, Find in page, PDF save,
 * Full-screen video, File upload, Camera/Mic/Location for websites.
 */
public class MainActivity extends Activity {

    static class Tab {
        WebView web;
        boolean incognito;
        String title = "Home";
    }

    static class MItem {
        final String icon, label; final boolean active; final Runnable run;
        MItem(String i, String l, boolean a, Runnable r) { icon = i; label = l; active = a; run = r; }
    }

    static final String HOME = "file:///android_asset/home.html";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "pagead2.googlesyndication.com", "adnxs.com", "taboola.com", "outbrain.com", "popads.net",
            "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "mgid.com", "revcontent.com",
            "zedo.com", "adcolony.com", "advertising.com", "adform.net", "criteo.com", "media.net",
            "moatads.com", "scorecardresearch.com", "onclickads.net", "trafficjunky.net"
    };
    static final String NIGHT_JS =
            "(function(on){var id='baatora-night';var s=document.getElementById(id);" +
            "if(on){if(!s){s=document.createElement('style');s.id=id;" +
            "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}" +
            "img,video,picture,canvas,iframe,svg image,[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s);}}else if(s){s.remove();}})(%s);";

    static final int REQ_FILE = 1, REQ_VOICE = 2, REQ_WEB_PERM = 10, REQ_GEO = 11, REQ_STORAGE = 12;

    final ArrayList<Tab> tabs = new ArrayList<>();
    int current = -1;
    SharedPreferences prefs;
    String mobileUA;
    volatile boolean adBlock;
    boolean loading, appFull;
    long lastBack;

    View topBar, bottomBar, findBar, splash;
    FrameLayout webContainer, fullscreenContainer;
    SwipeRefreshLayout swipe;
    EditText urlBar, findInput;
    ImageView lockIcon, btnRefresh, btnBack, btnForward;
    ProgressBar progress;
    TextView tabCount, findCount;

    View customView;
    WebChromeClient.CustomViewCallback customCallback;
    ValueCallback<Uri[]> fileCallback;
    PermissionRequest pendingPermission;
    GeolocationPermissions.Callback geoCallback;
    String geoOrigin;

    // ───────────────────────── LIFECYCLE ─────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("baatora", MODE_PRIVATE);
        adBlock = prefs.getBoolean("adblock", true);

        String ua = WebSettings.getDefaultUserAgent(this);
        mobileUA = ua.replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");

        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        findBar = findViewById(R.id.findBar);
        splash = findViewById(R.id.splash);
        webContainer = findViewById(R.id.webContainer);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);
        swipe = findViewById(R.id.swipe);
        urlBar = findViewById(R.id.urlBar);
        findInput = findViewById(R.id.findInput);
        lockIcon = findViewById(R.id.lockIcon);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);
        progress = findViewById(R.id.progress);
        tabCount = findViewById(R.id.tabCount);
        findCount = findViewById(R.id.findCount);

        CookieManager.getInstance().setAcceptCookie(true);
        setupControls();

        String start = HOME;
        Intent in = getIntent();
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            start = in.getDataString();
        }
        createTab(start, false, true);

        splash.postDelayed(() -> splash.animate().alpha(0f).setDuration(450)
                .withEndAction(() -> splash.setVisibility(View.GONE)).start(), 1500);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            createTab(intent.getDataString(), false, true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        WebView w = web();
        if (w != null) w.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebView w = web();
        if (w != null) w.onResume();
    }

    @Override
    protected void onDestroy() {
        webContainer.removeAllViews();
        for (Tab t : tabs) t.web.destroy();
        tabs.clear();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (findBar.getVisibility() == View.VISIBLE) { closeFind(); return; }
        if (appFull) { setAppFull(false); return; }
        if (urlBar.hasFocus()) { urlBar.clearFocus(); hideKeyboard(); return; }
        WebView w = web();
        if (w != null && w.canGoBack()) { w.goBack(); return; }
        if (tabs.size() > 1) { closeTab(current); return; }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { super.onBackPressed(); return; }
        lastBack = now;
        toast("Bahar nikalne ke liye dobara Back dabayein");
    }

    // ───────────────────────── CONTROLS ─────────────────────────

    void setupControls() {
        btnBack.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoBack()) w.goBack(); });
        btnForward.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoForward()) w.goForward(); });
        findViewById(R.id.btnHome).setOnClickListener(v -> { WebView w = web(); if (w != null) w.loadUrl(HOME); });
        findViewById(R.id.btnTabs).setOnClickListener(v -> showTabs());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMenu());
        findViewById(R.id.btnMic).setOnClickListener(v -> voiceSearch());
        findViewById(R.id.topLogo).setOnClickListener(v -> about());
        btnRefresh.setOnClickListener(v -> {
            WebView w = web(); if (w == null) return;
            if (loading) w.stopLoading(); else w.reload();
        });

        swipe.setColorSchemeColors(0xFFFF8A00, 0xFF00E5FF, 0xFF1E5BFF);
        swipe.setOnRefreshListener(() -> { WebView w = web(); if (w != null) w.reload(); else swipe.setRefreshing(false); });
        swipe.setOnChildScrollUpCallback((parent, child) -> { WebView w = web(); return w != null && w.getScrollY() > 0; });
        swipe.setEnabled(prefs.getBoolean("pull", true));

        urlBar.setOnFocusChangeListener((v, has) -> {
            WebView w = web();
            if (has) {
                String u = w == null ? null : w.getUrl();
                if (isRealUrl(u)) urlBar.setText(u);
                urlBar.post(urlBar::selectAll);
            } else if (w != null) {
                updateUrlBar(w.getUrl());
            }
        });
        urlBar.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (id == EditorInfo.IME_ACTION_GO || enter) {
                navigate(urlBar.getText().toString());
                hideKeyboard();
                urlBar.clearFocus();
                return true;
            }
            return false;
        });

        findInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { WebView w = web(); if (w != null) w.findAllAsync(s.toString()); }
        });
        findViewById(R.id.findNext).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(true); });
        findViewById(R.id.findPrev).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(false); });
        findViewById(R.id.findClose).setOnClickListener(v -> closeFind());
    }

    // ───────────────────────── TABS ─────────────────────────

    Tab cur() { return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null; }
    WebView web() { Tab t = cur(); return t == null ? null : t.web; }
    boolean isCurrent(Tab t) { return cur() == t; }

    Tab createTab(String url, boolean incognito, boolean show) {
        Tab t = new Tab();
        t.incognito = incognito;
        t.web = buildWebView(t);
        tabs.add(t);
        if (show) switchTab(tabs.size() - 1); else updateUi();
        if (url != null) t.web.loadUrl(url);
        tabCount.setText(String.valueOf(tabs.size()));
        return t;
    }

    void switchTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab old = cur();
        Tab t = tabs.get(i);
        if (old != null && old != t) old.web.onPause();
        webContainer.removeAllViews();
        current = i;
        if (t.web.getParent() != null) ((ViewGroup) t.web.getParent()).removeView(t.web);
        webContainer.addView(t.web);
        t.web.onResume();
        int p = t.web.getProgress();
        setLoadingState(p < 100);
        progress.setProgress(p);
        updateUi();
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        webContainer.removeView(t.web);
        if (t.incognito) { t.web.clearHistory(); t.web.clearCache(true); t.web.clearFormData(); }
        t.web.destroy();
        if (tabs.isEmpty()) { current = -1; createTab(HOME, false, true); return; }
        int ni = (i == current) ? Math.min(i, tabs.size() - 1) : (current > i ? current - 1 : current);
        current = -1;
        switchTab(ni);
    }

    WebView buildWebView(Tab t) {
        final WebView w = new WebView(this);
        w.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        w.setBackgroundColor(Color.WHITE);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(prefs.getInt("textZoom", 100));
        s.setLoadsImagesAutomatically(!prefs.getBoolean("datasaver", false));
        s.setUserAgentString(prefs.getBoolean("desktop", false) ? DESKTOP_UA : mobileUA);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new BClient(t));
        w.setWebChromeClient(new BChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> onDownload(url, ua, cd, mime, len));
        w.setOnLongClickListener(v -> onLongPress(w));
        w.setFindListener((active, num, done) ->
                findCount.setText(num == 0 ? "0/0" : (active + 1) + "/" + num));
        return w;
    }

    // ───────────────────────── WEB CLIENTS ─────────────────────────

    class BClient extends WebViewClient {
        final Tab t;
        BClient(Tab t) { this.t = t; }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleSpecialUrl(v, r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap fav) {
            if (isCurrent(t)) { setLoadingState(true); updateUi(); }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (isCurrent(t)) { setLoadingState(false); swipe.setRefreshing(false); updateUi(); }
            if (url == null) return;
            if (url.startsWith(HOME)) {
                v.evaluateJavascript("window.setEngine&&setEngine('" + engine() + "');" +
                        (t.incognito ? "window.setIncog&&setIncog();" : ""), null);
            } else {
                applyNight(v, url);
                String title = v.getTitle();
                if (!t.incognito && url.startsWith("http") && (title == null || !title.startsWith("Baatora Error"))) {
                    addHistory(title, url);
                }
            }
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean reload) {
            if (isCurrent(t)) updateUi();
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            if (adBlock && isAd(r.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String failing = r.getUrl().toString();
                v.loadDataWithBaseURL(null, errorPage(failing, String.valueOf(e.getDescription())),
                        "text/html", "UTF-8", failing);
            }
        }
    }

    class BChrome extends WebChromeClient {
        final Tab t;
        BChrome(Tab t) { this.t = t; }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (isCurrent(t)) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
        }

        @Override
        public void onReceivedTitle(WebView v, String title) { t.title = title; }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) { showCustom(view, cb); }

        @Override
        public void onHideCustomView() { hideCustom(); }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            try {
                Intent i = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                startActivityForResult(Intent.createChooser(i, "File chunein"), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                toast("File chooser nahi khula");
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            ArrayList<String> missing = new ArrayList<>();
            for (String r : request.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !granted(Manifest.permission.CAMERA))
                    missing.add(Manifest.permission.CAMERA);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !granted(Manifest.permission.RECORD_AUDIO))
                    missing.add(Manifest.permission.RECORD_AUDIO);
            }
            if (missing.isEmpty()) {
                request.grant(request.getResources());
            } else {
                pendingPermission = request;
                requestPermissions(missing.toArray(new String[0]), REQ_WEB_PERM);
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                cb.invoke(origin, true, false);
            } else {
                geoOrigin = origin;
                geoCallback = cb;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            Tab nt = createTab(null, t.incognito, true);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nt.web);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView w) {
            for (int i = 0; i < tabs.size(); i++) {
                if (tabs.get(i).web == w) { closeTab(i); break; }
            }
        }
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    boolean handleSpecialUrl(WebView v, String url) {
        String low = url.toLowerCase();
        if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("file://")
                || low.startsWith("about:") || low.startsWith("javascript:") || low.startsWith("data:")
                || low.startsWith("blob:")) {
            return false;
        }
        try {
            if (low.startsWith("intent://") || low.startsWith("intent:")) {
                Intent it = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                it.addCategory(Intent.CATEGORY_BROWSABLE);
                it.setComponent(null);
                try {
                    startActivity(it);
                } catch (ActivityNotFoundException e) {
                    String fb = it.getStringExtra("browser_fallback_url");
                    if (fb != null) v.loadUrl(fb);
                    else if (it.getPackage() != null)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + it.getPackage())));
                }
                return true;
            }
            // tel:, mailto:, whatsapp:, upi:, market:, etc.
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Is link ke liye koi app nahi mila");
        }
        return true;
    }

    void navigate(String input) {
        String q = input.trim();
        if (q.isEmpty()) return;
        String url;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || q.startsWith("about:")) url = q;
        else if (!q.contains(" ") && (q.matches("^[^\\s]+\\.[a-zA-Z]{2,}(/.*)?(:\\d+)?.*$") || q.startsWith("localhost")))
            url = "https://" + q;
        else url = searchUrl(q);
        WebView w = web();
        if (w != null) w.loadUrl(url);
    }

    String engine() { return prefs.getString("engine", "google"); }

    String searchUrl(String q) {
        String enc;
        try { enc = URLEncoder.encode(q, "UTF-8"); } catch (Exception e) { enc = q; }
        switch (engine()) {
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "duckduckgo": return "https://duckduckgo.com/?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://www.google.com/search?q=" + enc;
        }
    }

    boolean isAd(String host) {
        if (host == null) return false;
        for (String a : AD_HOSTS) if (host.equals(a) || host.endsWith("." + a)) return true;
        return false;
    }

    static boolean isRealUrl(String u) {
        return u != null && !u.startsWith("file:///android_asset") && !u.startsWith("data:") && !u.equals("about:blank");
    }

    // ───────────────────────── UI STATE ─────────────────────────

    void updateUi() {
        Tab t = cur();
        if (t == null) return;
        updateUrlBar(t.web.getUrl());
        btnBack.setAlpha(t.web.canGoBack() ? 1f : 0.35f);
        btnForward.setAlpha(t.web.canGoForward() ? 1f : 0.35f);
        tabCount.setText(String.valueOf(tabs.size()));
        int[] colors = t.incognito
                ? new int[]{0xFF1A0B2E, 0xFF3D1670, 0xFF6A1FB0}
                : new int[]{0xFF06103A, 0xFF0D2A8A, 0xFF1E5BFF};
        topBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors));
        getWindow().setStatusBarColor(colors[0]);
        urlBar.setHint(t.incognito ? "🕶 Incognito search ya URL" : "Search ya URL likhein");
    }

    void updateUrlBar(String url) {
        if (urlBar.hasFocus()) return;
        if (!isRealUrl(url)) {
            urlBar.setText("");
            lockIcon.setVisibility(View.GONE);
            return;
        }
        lockIcon.setVisibility(View.VISIBLE);
        lockIcon.setColorFilter(url.startsWith("https://") ? 0xFF2E7D32 : 0xFFD32F2F);
        urlBar.setText(url.replaceFirst("^https?://(www\\.)?", ""));
    }

    void setLoadingState(boolean l) {
        loading = l;
        btnRefresh.setImageResource(l ? R.drawable.ic_close : R.drawable.ic_refresh);
        progress.setVisibility(l ? View.VISIBLE : View.GONE);
    }

    void applyNight(WebView w, String url) {
        if (w == null || !isRealUrl(url)) return;
        w.evaluateJavascript(String.format(NIGHT_JS, prefs.getBoolean("night", false) ? "true" : "false"), null);
    }

    // ───────────────────────── FULL SCREEN ─────────────────────────

    void showCustom(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) { cb.onCustomViewHidden(); return; }
        customView = v;
        customCallback = cb;
        fullscreenContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullscreenContainer.setVisibility(View.VISIBLE);
        hideSystemUi();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    void hideCustom() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        if (!appFull) showSystemUi();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    void setAppFull(boolean f) {
        appFull = f;
        topBar.setVisibility(f ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(f ? View.GONE : View.VISIBLE);
        if (f) { hideSystemUi(); toast("Full screen band karne ke liye Back dabayein"); }
        else showSystemUi();
    }

    @SuppressWarnings("deprecation")
    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressWarnings("deprecation")
    void showSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ───────────────────────── MENU ─────────────────────────

    boolean on(String key, boolean def) { return prefs.getBoolean(key, def); }

    void showMenu() {
        ArrayList<MItem> m = new ArrayList<>();
        m.add(new MItem("➕", "Naya Tab", false, () -> createTab(HOME, false, true)));
        m.add(new MItem("🕶️", "Incognito", false, () -> { createTab(HOME, true, true); toast("Incognito: history save nahi hogi"); }));
        m.add(new MItem("🔖", "Bookmarks", false, () -> showList("bookmarks", "Bookmarks")));
        m.add(new MItem("⭐", "Bookmark karein", false, this::addBookmark));
        m.add(new MItem("🕘", "History", false, () -> showList("history", "History")));
        m.add(new MItem("⬇️", "Downloads", false, this::openDownloads));
        m.add(new MItem("🔍", "Page me khojein", false, this::openFind));
        m.add(new MItem("📤", "Share", false, () -> { WebView w = web(); if (w != null) share(w.getUrl()); }));
        m.add(new MItem("📋", "Link copy", false, () -> { WebView w = web(); if (w != null) copy(w.getUrl()); }));
        m.add(new MItem("🖥️", "Desktop site", on("desktop", false), this::toggleDesktop));
        m.add(new MItem("🌙", "Night mode", on("night", false), this::toggleNight));
        m.add(new MItem("🛡️", "Ad Block", adBlock, this::toggleAdBlock));
        m.add(new MItem("📉", "Data Saver", on("datasaver", false), this::toggleDataSaver));
        m.add(new MItem("🔃", "Pull refresh", on("pull", true), this::togglePull));
        m.add(new MItem("🔠", "Text size", false, this::chooseTextSize));
        m.add(new MItem("🔎", "Search engine", false, this::chooseEngine));
        m.add(new MItem("📄", "PDF save", false, this::savePdf));
        m.add(new MItem("⛶", "Full screen", false, () -> setAppFull(true)));
        m.add(new MItem("🧹", "Data clear", false, this::clearData));
        m.add(new MItem("🚪", "Exit", false, this::finish));

        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheet();
        box.addView(header("Baatora  •  Made in India 🇮🇳"));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        int[] tile = {0xFFFF8A00, 0xFF1E5BFF, 0xFF00B8D4, 0xFFE91E63, 0xFF7C4DFF, 0xFFFFB300, 0xFF00897B, 0xFFFF5252};
        for (int i = 0; i < m.size(); i++) {
            final MItem it = m.get(i);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(8), dp(2), dp(8));

            TextView ic = new TextView(this);
            ic.setText(it.icon);
            ic.setTextSize(21);
            ic.setGravity(Gravity.CENTER);
            GradientDrawable c = new GradientDrawable();
            c.setShape(GradientDrawable.OVAL);
            c.setColor(it.active ? 0xFF00C853 : tile[i % tile.length]);
            if (it.active) c.setStroke(dp(2), Color.WHITE);
            ic.setBackground(c);
            cell.addView(ic, new LinearLayout.LayoutParams(dp(48), dp(48)));

            TextView lb = new TextView(this);
            lb.setText(it.active ? it.label + " ✓" : it.label);
            lb.setTextColor(it.active ? 0xFF69F0AE : Color.WHITE);
            lb.setTextSize(11);
            lb.setGravity(Gravity.CENTER);
            lb.setMaxLines(2);
            lb.setPadding(0, dp(5), 0, 0);
            cell.addView(lb);

            cell.setOnClickListener(v -> { dh[0].dismiss(); it.run.run(); });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            grid.addView(cell, lp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(grid);
        box.addView(sv);
        dh[0] = bottomDialog(box);
    }

    void showTabs() {
        final Dialog[] dh = new Dialog[1];
        LinearLayout box = sheet();
        box.addView(header("🗂  Tabs (" + tabs.size() + ")"));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(10), dp(6), dp(10));
            GradientDrawable bg = round(i == current ? 0xFF1E5BFF : 0xFF13235F, 16);
            if (i == current) bg.setStroke(dp(2), 0xFFFFB300);
            row.setBackground(bg);

            String u = t.web.getUrl();
            String title = (u == null || u.startsWith(HOME)) ? "Home" : (TextUtils.isEmpty(t.title) ? u : t.title);
            String host = isRealUrl(u) ? Uri.parse(u).getHost() : "Baatora Home";
            TextView tv = new TextView(this);
            tv.setText((t.incognito ? "🕶  " : "🌐  ") + title + "\n" + host);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(13);
            tv.setMaxLines(2);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView x = new TextView(this);
            x.setText("✕");
            x.setTextColor(0xFFFF8A80);
            x.setTextSize(18);
            x.setPadding(dp(14), dp(4), dp(10), dp(4));
            row.addView(x);

            row.setOnClickListener(v -> { dh[0].dismiss(); switchTab(idx); });
            x.setOnClickListener(v -> { dh[0].dismiss(); closeTab(idx); showTabs(); });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(8);
            list.addView(row, lp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, tabs.size() > 5 ? dp(330) : -2));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, dp(8), 0, 0);
        btns.addView(pill("➕ Naya Tab", 0xFFFF8A00, v -> { dh[0].dismiss(); createTab(HOME, false, true); }), weightLp());
        btns.addView(pill("🕶 Incognito", 0xFF6A1FB0, v -> { dh[0].dismiss(); createTab(HOME, true, true); }), weightLp());
        btns.addView(pill("🗑 Sab band", 0xFFD32F2F, v -> {
            dh[0].dismiss();
            while (tabs.size() > 1) closeTab(tabs.size() - 1);
            closeTab(0);
        }), weightLp());
        box.addView(btns);
        dh[0] = bottomDialog(box);
    }

    // ───────────────────────── MENU ACTIONS ─────────────────────────

    void toggleDesktop() {
        boolean d = !on("desktop", false);
        prefs.edit().putBoolean("desktop", d).apply();
        for (Tab t : tabs) t.web.getSettings().setUserAgentString(d ? DESKTOP_UA : mobileUA);
        WebView w = web(); if (w != null) w.reload();
        toast(d ? "🖥 Desktop site ON" : "📱 Mobile site ON");
    }

    void toggleNight() {
        boolean n = !on("night", false);
        prefs.edit().putBoolean("night", n).apply();
        for (Tab t : tabs) applyNight(t.web, t.web.getUrl());
        toast(n ? "🌙 Night mode ON" : "☀️ Night mode OFF");
    }

    void toggleAdBlock() {
        adBlock = !adBlock;
        prefs.edit().putBoolean("adblock", adBlock).apply();
        WebView w = web(); if (w != null) w.reload();
        toast(adBlock ? "🛡 Ad Block ON" : "Ad Block OFF");
    }

    void toggleDataSaver() {
        boolean d = !on("datasaver", false);
        prefs.edit().putBoolean("datasaver", d).apply();
        for (Tab t : tabs) t.web.getSettings().setLoadsImagesAutomatically(!d);
        WebView w = web(); if (w != null) w.reload();
        toast(d ? "📉 Data Saver ON (images band)" : "Data Saver OFF");
    }

    void togglePull() {
        boolean p = !on("pull", true);
        prefs.edit().putBoolean("pull", p).apply();
        swipe.setEnabled(p);
        toast(p ? "Pull-to-refresh ON" : "Pull-to-refresh OFF");
    }

    void chooseTextSize() {
        final int[] sizes = {75, 90, 100, 115, 130, 150};
        String[] names = {"75% (Chhota)", "90%", "100% (Normal)", "115%", "130%", "150% (Bada)"};
        int now = prefs.getInt("textZoom", 100), sel = 2;
        for (int i = 0; i < sizes.length; i++) if (sizes[i] == now) sel = i;
        new AlertDialog.Builder(this).setTitle("🔠 Text size")
                .setSingleChoiceItems(names, sel, (d, w) -> {
                    prefs.edit().putInt("textZoom", sizes[w]).apply();
                    for (Tab t : tabs) t.web.getSettings().setTextZoom(sizes[w]);
                    d.dismiss();
                }).show();
    }

    void chooseEngine() {
        final String[] keys = {"google", "bing", "duckduckgo", "yahoo"};
        String[] names = {"Google", "Bing", "DuckDuckGo", "Yahoo"};
        int sel = 0;
        for (int i = 0; i < keys.length; i++) if (keys[i].equals(engine())) sel = i;
        new AlertDialog.Builder(this).setTitle("🔎 Search engine")
                .setSingleChoiceItems(names, sel, (d, w) -> {
                    prefs.edit().putString("engine", keys[w]).apply();
                    WebView wv = web();
                    if (wv != null) wv.evaluateJavascript("window.setEngine&&setEngine('" + keys[w] + "')", null);
                    toast(names[w] + " select ho gaya");
                    d.dismiss();
                }).show();
    }

    void savePdf() {
        WebView w = web();
        if (w == null || !isRealUrl(w.getUrl())) { toast("Pehle koi website kholein"); return; }
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            String name = "Baatora_" + System.currentTimeMillis();
            PrintDocumentAdapter a = w.createPrintDocumentAdapter(name);
            pm.print(name, a, new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast("PDF save nahi ho saka");
        }
    }

    void clearData() {
        new AlertDialog.Builder(this).setTitle("🧹 Data clear karein?")
                .setMessage("Cache, cookies, history aur site data hat jayega. Bookmarks safe rahenge.")
                .setPositiveButton("Clear", (d, w) -> {
                    for (Tab t : tabs) { t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData(); }
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    save("history", new JSONArray());
                    toast("✅ Sab saaf ho gaya");
                    updateUi();
                })
                .setNegativeButton("Cancel", null).show();
    }

    void about() {
        new AlertDialog.Builder(this).setTitle("Baatora Browser")
                .setMessage("Version 1.0\n\n🇮🇳 Made in India\n\n" +
                        "Tez, surakshit aur smart browser.\n\n" +
                        "✓ Multi Tabs aur Incognito\n✓ Ad Block aur Data Saver\n" +
                        "✓ Night Mode aur Desktop Site\n✓ Downloads, Bookmarks, History\n" +
                        "✓ Voice Search aur Find in Page\n✓ PDF Save aur Full Screen Video")
                .setPositiveButton("OK", null).show();
    }

    void openDownloads() {
        try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
        catch (Exception e) { toast("Downloads folder: Internal storage > Download"); }
    }

    void openFind() {
        findBar.setVisibility(View.VISIBLE);
        findInput.setText("");
        findInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
    }

    void closeFind() {
        findBar.setVisibility(View.GONE);
        WebView w = web(); if (w != null) w.clearMatches();
        hideKeyboard();
    }

    void voiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye... 🎤");
        try { startActivityForResult(i, REQ_VOICE); }
        catch (ActivityNotFoundException e) { toast("Voice search is phone par available nahi hai"); }
    }

    boolean onLongPress(WebView w) {
        WebView.HitTestResult h = w.getHitTestResult();
        final String extra = h.getExtra();
        int type = h.getType();
        if (extra == null) return false;
        final boolean isImg = type == WebView.HitTestResult.IMAGE_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE;
        boolean isLink = type == WebView.HitTestResult.SRC_ANCHOR_TYPE;
        if (!isImg && !isLink) return false;
        Tab owner = cur();
        final boolean inc = owner != null && owner.incognito;
        String[] opts = isImg
                ? new String[]{"🆕 Image naye tab me kholein", "⬇️ Image download karein", "📋 Image link copy", "📤 Share karein"}
                : new String[]{"🆕 Naye tab me kholein", "🕶️ Incognito tab me kholein", "📋 Link copy karein", "📤 Share karein"};
        new AlertDialog.Builder(this)
                .setTitle(extra.length() > 80 ? extra.substring(0, 80) + "…" : extra)
                .setItems(opts, (d, which) -> {
                    switch (which) {
                        case 0: createTab(extra, inc, false); toast("Naye tab me khul gaya"); break;
                        case 1:
                            if (isImg) onDownload(extra, w.getSettings().getUserAgentString(), null, null, 0);
                            else createTab(extra, true, true);
                            break;
                        case 2: copy(extra); break;
                        case 3: share(extra); break;
                    }
                }).show();
        return true;
    }

    // ───────────────────────── DOWNLOADS ─────────────────────────

    void onDownload(String url, String ua, String cd, String mime, long len) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Is tarah ka download abhi support nahi hai");
            return;
        }
        final String name = URLUtil.guessFileName(url, cd, mime);
        String size = len > 0 ? "\nSize: " + Formatter.formatFileSize(this, len) : "";
        new AlertDialog.Builder(this).setTitle("⬇️ Download")
                .setMessage(name + size)
                .setPositiveButton("Download", (d, w) -> startDownload(url, ua, mime, name))
                .setNegativeButton("Cancel", null).show();
    }

    void startDownload(String url, String ua, String mime, String name) {
        if (Build.VERSION.SDK_INT < 29 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("Storage permission dein, phir dobara download karein");
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            r.setTitle(name);
            r.setDescription("Baatora Browser");
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("⬇️ Download shuru: " + name);
        } catch (Exception e) {
            toast("Download fail: " + e.getMessage());
        }
    }

    // ───────────────────────── BOOKMARKS / HISTORY ─────────────────────────

    JSONArray load(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void save(String key, JSONArray arr) { prefs.edit().putString(key, arr.toString()).apply(); }

    void addHistory(String title, String url) {
        try {
            JSONArray old = load("history");
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(title) ? url : title);
            o.put("u", url);
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 500; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !url.equals(x.optString("u"))) arr.put(x);
            }
            save("history", arr);
        } catch (Exception ignored) {}
    }

    void addBookmark() {
        WebView w = web();
        String u = w == null ? null : w.getUrl();
        if (!isRealUrl(u)) { toast("Pehle koi website kholein"); return; }
        try {
            JSONArray arr = load("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.optJSONObject(i);
                if (x != null && u.equals(x.optString("u"))) { toast("Ye pehle se bookmark hai ⭐"); return; }
            }
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(w.getTitle()) ? u : w.getTitle());
            o.put("u", u);
            arr.put(o);
            save("bookmarks", arr);
            toast("⭐ Bookmark ho gaya");
        } catch (Exception e) {
            toast("Bookmark nahi ho saka");
        }
    }

    void showList(String key, String title) {
        final JSONArray arr = load(key);
        if (arr.length() == 0) { toast(title + " abhi khaali hai"); return; }
        String[] items = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            String u = o == null ? "" : o.optString("u");
            String t = o == null ? "" : o.optString("t");
            items[i] = t + "\n" + (u.length() > 60 ? u.substring(0, 60) + "…" : u);
        }
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle((key.equals("bookmarks") ? "🔖 " : "🕘 ") + title)
                .setItems(items, (d, w) -> {
                    JSONObject o = arr.optJSONObject(w);
                    WebView wv = web();
                    if (o != null && wv != null) wv.loadUrl(o.optString("u"));
                })
                .setNeutralButton("Sab hatao", (d, w) -> { save(key, new JSONArray()); toast(title + " saaf ho gaya"); })
                .setNegativeButton("Band", null)
                .create();
        dlg.show();
        ListView lv = dlg.getListView();
        if (lv != null) {
            lv.setOnItemLongClickListener((p, v, pos, id) -> {
                arr.remove(pos);
                save(key, arr);
                dlg.dismiss();
                toast("Hata diya");
                return true;
            });
        }
        toast("Hatane ke liye item ko dabaye rakhein");
    }

    // ───────────────────────── RESULTS / PERMISSIONS ─────────────────────────

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    results = new Uri[cd.getItemCount()];
                    for (int i = 0; i < cd.getItemCount(); i++) results[i] = cd.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (req == REQ_VOICE && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) navigate(r.get(0));
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        boolean all = results.length > 0, any = false;
        for (int r : results) { if (r == PackageManager.PERMISSION_GRANTED) any = true; else all = false; }
        if (req == REQ_WEB_PERM && pendingPermission != null) {
            if (all) pendingPermission.grant(pendingPermission.getResources());
            else pendingPermission.deny();
            pendingPermission = null;
        } else if (req == REQ_GEO && geoCallback != null) {
            geoCallback.invoke(geoOrigin, any, false);
            geoCallback = null;
        }
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    // ───────────────────────── HELPERS ─────────────────────────

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void copy(String s) {
        if (s == null) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("link", s));
        toast("📋 Copy ho gaya");
    }

    void share(String s) {
        if (!isRealUrl(s)) { toast("Share karne ke liye koi page kholein"); return; }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, s);
        startActivity(Intent.createChooser(i, "Share karein"));
    }

    GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    LinearLayout sheet() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(18));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF0D2A8A, 0xFF06103A});
        float r = dp(26);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bg);
        View handle = new View(this);
        handle.setBackground(round(0x66FFFFFF, 3));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(dp(44), dp(5));
        hl.gravity = Gravity.CENTER_HORIZONTAL;
        hl.bottomMargin = dp(10);
        box.addView(handle, hl);
        return box;
    }

    TextView header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFFFC107);
        t.setTextSize(15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, dp(12));
        return t;
    }

    TextView pill(String s, int color, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(12), dp(6), dp(12));
        t.setBackground(round(color, 22));
        t.setOnClickListener(l);
        return t;
    }

    LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    Dialog bottomDialog(View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
        }
        return d;
    }

    static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    String errorPage(String url, String desc) {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<title>Baatora Error</title><style>" +
                "body{margin:0;font-family:sans-serif;background:linear-gradient(160deg,#06103A,#1E5BFF);color:#fff;" +
                "display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;" +
                "text-align:center;padding:24px;box-sizing:border-box}" +
                "h1{font-size:64px;margin:0}h2{margin:12px 0 6px}p{opacity:.85;font-size:14px;word-break:break-all;margin:6px 0}" +
                "a{display:inline-block;margin-top:22px;padding:14px 34px;border-radius:30px;" +
                "background:linear-gradient(90deg,#FF8A00,#FFC107);color:#06103A;font-weight:bold;text-decoration:none}" +
                "</style></head><body><h1>📡</h1><h2>Page nahi khul paya</h2>" +
                "<p>Internet connection check karein, phir dobara try karein.</p>" +
                "<p style='opacity:.6'>" + esc(desc) + "</p>" +
                "<a href=\"" + esc(url) + "\">🔄 Dobara try karein</a>" +
                "<p style='margin-top:34px;color:#FFC107;opacity:1'>Made in India 🇮🇳</p></body></html>";
    }
}
