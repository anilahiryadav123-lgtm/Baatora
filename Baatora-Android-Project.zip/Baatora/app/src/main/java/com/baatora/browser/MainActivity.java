package com.baatora.browser;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Baatora Browser — Made in India 🇮🇳
 * Created by Anil Yadav, Thane.
 */
public class MainActivity extends Activity {

    static class Tab {
        WebView web;
        boolean incognito;
        String title = "Home";
        Bitmap thumb;
        final ArrayList<String> media = new ArrayList<>();
    }

    static final String HOME = "file:///android_asset/home.html";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
            "adsterra.com", "exoclick.com", "mgid.com", "revcontent.com", "zedo.com", "adcolony.com",
            "advertising.com", "adform.net", "criteo.com", "moatads.com", "scorecardresearch.com",
            "onclickads.net", "trafficjunky.net", "inmobi.com", "applovin.com", "unityads.unity3d.com"
    };
    static final String[] MEDIA_EXT = {".mp4", ".webm", ".mkv", ".3gp", ".mov", ".m4v",
            ".mp3", ".m4a", ".aac", ".ogg", ".wav", ".flac", ".opus"};
    static final String NIGHT_JS =
            "(function(on){var id='baatora-night';var s=document.getElementById(id);" +
            "if(on){if(!s){s=document.createElement('style');s.id=id;" +
            "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}" +
            "img,video,picture,canvas,iframe,svg image,[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg)!important}';" +
            "(document.head||document.documentElement).appendChild(s);}}else if(s){s.remove();}})(%s);";
    static final String MEDIA_JS =
            "(function(){var o=[];function a(u){if(u&&/^https?:/i.test(u)&&o.indexOf(u)<0)o.push(u);}" +
            "document.querySelectorAll('video,audio,source').forEach(function(e){a(e.currentSrc);a(e.src);});" +
            "document.querySelectorAll('a[href]').forEach(function(e){" +
            "if(/\\.(mp4|webm|mkv|3gp|mov|m4v|mp3|m4a|aac|ogg|wav|flac|opus)(\\?|$)/i.test(e.href))a(e.href);});" +
            "return JSON.stringify(o.slice(0,30));})()";

    static final int REQ_FILE = 1, REQ_VOICE = 2, REQ_WEB_PERM = 10, REQ_GEO = 11, REQ_STORAGE = 12;

    final ArrayList<Tab> tabs = new ArrayList<>();
    int current = -1;
    SharedPreferences prefs;
    String mobileUA;
    volatile boolean adBlock;
    boolean loading, appFull;
    long lastBack;
    Screens screens;

    View topBar, bottomBar, findBar;
    FrameLayout webContainer, fullscreenContainer, splash;
    SwipeRefreshLayout swipe;
    EditText urlBar, findInput;
    ImageView lockIcon, btnRefresh, btnBack, btnForward;
    ProgressBar progress;
    TextView tabCount, findCount, mediaFab;

    View customView;
    WebChromeClient.CustomViewCallback customCallback;
    ValueCallback<Uri[]> fileCallback;
    PermissionRequest pendingPermission;
    GeolocationPermissions.Callback geoCallback;
    String geoOrigin;

    // ───────────────────────── LIFECYCLE ─────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.density = getResources().getDisplayMetrics().density;
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("baatora", MODE_PRIVATE);
        adBlock = prefs.getBoolean("adblock", true);
        screens = new Screens(this);

        String ua = WebSettings.getDefaultUserAgent(this);
        mobileUA = ua.replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");

        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        findBar = findViewById(R.id.findBar);
        splash = findViewById(R.id.splash);
        webContainer = findViewById(R.id.webContainer);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);
        swipe = findViewById(R.id.swipe);
        urlBar = findViewById(R.id.urlBar);
        findInput = findViewById(R.id.findInput);
        lockIcon = findViewById(R.id.lockIcon);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);
        progress = findViewById(R.id.progress);
        tabCount = findViewById(R.id.tabCount);
        findCount = findViewById(R.id.findCount);
        mediaFab = findViewById(R.id.mediaFab);

        CookieManager.getInstance().setAcceptCookie(true);
        setupControls();

        String start = HOME;
        Intent in = getIntent();
        if (in != null && Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            start = in.getDataString();
        }
        createTab(start, false, true);
        playIntro();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            createTab(intent.getDataString(), false, true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        WebView w = web();
        if (w != null) w.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebView w = web();
        if (w != null) w.onResume();
    }

    @Override
    protected void onDestroy() {
        webContainer.removeAllViews();
        for (Tab t : tabs) t.web.destroy();
        tabs.clear();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (findBar.getVisibility() == View.VISIBLE) { closeFind(); return; }
        if (appFull) { setAppFull(false); return; }
        if (urlBar.hasFocus()) { urlBar.clearFocus(); hideKeyboard(); return; }
        WebView w = web();
        if (w != null && w.canGoBack()) { w.goBack(); return; }
        if (tabs.size() > 1) { closeTab(current); return; }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { super.onBackPressed(); return; }
        lastBack = now;
        toast("Bahar nikalne ke liye dobara Back dabayein");
    }

    // ───────────────────────── 3D INTRO ─────────────────────────

    void playIntro() {
        float d = Ui.density;
        GradientDrawable bg = new GradientDrawable();
        bg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        bg.setGradientRadius(Ui.dp(460));
        bg.setColors(new int[]{0xFF1E4BD8, 0xFF0A1A5C, 0xFF040A26});
        splash.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        colLp.bottomMargin = Ui.dp(60);
        splash.addView(col, colLp);

        FrameLayout stage = new FrameLayout(this);
        col.addView(stage, new LinearLayout.LayoutParams(Ui.dp(300), Ui.dp(300)));

        RingView ringA = new RingView(this, Ui.ORANGE, Ui.GOLD, Ui.dp(5));
        RingView ringB = new RingView(this, Ui.CYAN, Ui.BLUE, Ui.dp(4));
        ringA.setRotationX(66);
        ringB.setRotationX(66);
        ringB.setRotation(60);
        ringA.setCameraDistance(9000 * d);
        ringB.setCameraDistance(9000 * d);
        stage.addView(ringB, new FrameLayout.LayoutParams(Ui.dp(290), Ui.dp(290), Gravity.CENTER));
        stage.addView(ringA, new FrameLayout.LayoutParams(Ui.dp(240), Ui.dp(240), Gravity.CENTER));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setBackground(Ui.round(0x00000000, 40));
        logo.setClipToOutline(true);
        logo.setElevation(Ui.dp(20));
        stage.addView(logo, new FrameLayout.LayoutParams(Ui.dp(140), Ui.dp(140), Gravity.CENTER));

        final TextView title = Ui.text(this, "Baatora", 46, Color.WHITE, true);
        title.setLetterSpacing(0.04f);
        col.addView(title);
        TextView tag = Ui.text(this, "Tez. Surakshit. Apna Browser.", 15, 0xFFB8F3FF, false);
        tag.setPadding(0, Ui.dp(2), 0, 0);
        col.addView(tag);

        TextView made = Ui.text(this, "  Made in India 🇮🇳  ", 15, Ui.NAVY, true);
        made.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
        GradientDrawable tri = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF138808});
        tri.setCornerRadius(Ui.dp(24));
        made.setBackground(tri);
        FrameLayout.LayoutParams madeLp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        madeLp.bottomMargin = Ui.dp(70);
        splash.addView(made, madeLp);

        TextView credit = Ui.text(this, "Created by Anil Yadav", 12, 0xFF9FB3FF, false);
        FrameLayout.LayoutParams crLp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        crLp.bottomMargin = Ui.dp(40);
        splash.addView(credit, crLp);

        title.post(() -> title.getPaint().setShader(new LinearGradient(0, 0, title.getWidth(), 0,
                new int[]{Ui.GOLD, Ui.ORANGE, Ui.CYAN, Ui.BLUE}, null, Shader.TileMode.CLAMP)));

        // Logo: 3D flip ke saath andar aata hai
        logo.setCameraDistance(9000 * d);
        logo.setRotationY(-540);
        logo.setScaleX(0.15f);
        logo.setScaleY(0.15f);
        logo.setAlpha(0f);
        logo.animate().rotationY(0).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(1400).setInterpolator(new DecelerateInterpolator(1.8f)).start();

        ringA.setAlpha(0f); ringB.setAlpha(0f);
        ringA.setScaleX(0.4f); ringA.setScaleY(0.4f);
        ringB.setScaleX(0.4f); ringB.setScaleY(0.4f);
        ringA.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(900)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
        ringB.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(400).setDuration(900)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();

        final ValueAnimator spin = ValueAnimator.ofFloat(0f, 360f);
        spin.setDuration(1600);
        spin.setRepeatCount(ValueAnimator.INFINITE);
        spin.setInterpolator(new LinearInterpolator());
        spin.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            ringA.setPhase(v);
            ringB.setPhase(-v * 1.4f);
        });
        spin.start();

        title.setCameraDistance(9000 * d);
        title.setRotationX(90);
        title.setAlpha(0f);
        title.animate().rotationX(0).alpha(1f).setStartDelay(1000).setDuration(700)
                .setInterpolator(new DecelerateInterpolator()).start();
        tag.setAlpha(0f);
        tag.setTranslationY(Ui.dp(20));
        tag.animate().alpha(1f).translationY(0).setStartDelay(1350).setDuration(600).start();
        made.setAlpha(0f);
        made.setTranslationY(Ui.dp(40));
        made.animate().alpha(1f).translationY(0).setStartDelay(1550).setDuration(600)
                .setInterpolator(new OvershootInterpolator()).start();
        credit.setAlpha(0f);
        credit.animate().alpha(1f).setStartDelay(1800).setDuration(500).start();

        splash.postDelayed(() -> splash.animate().alpha(0f).scaleX(1.25f).scaleY(1.25f).setDuration(500)
                .withEndAction(() -> {
                    spin.cancel();
                    splash.removeAllViews();
                    splash.setVisibility(View.GONE);
                }).start(), 3000);
    }

    // ───────────────────────── CONTROLS ─────────────────────────

    void setupControls() {
        btnBack.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoBack()) w.goBack(); });
        btnForward.setOnClickListener(v -> { WebView w = web(); if (w != null && w.canGoForward()) w.goForward(); });
        findViewById(R.id.btnHome).setOnClickListener(v -> { WebView w = web(); if (w != null) w.loadUrl(HOME); });
        findViewById(R.id.btnTabs).setOnClickListener(v -> screens.tabs());
        findViewById(R.id.btnMenu).setOnClickListener(v -> screens.menu());
        findViewById(R.id.btnMic).setOnClickListener(v -> voiceSearch());
        findViewById(R.id.topLogo).setOnClickListener(v -> screens.about());
        btnRefresh.setOnClickListener(v -> {
            WebView w = web(); if (w == null) return;
            if (loading) w.stopLoading(); else w.reload();
        });

        mediaFab.setBackground(Ui.grad(0xFFFF8A00, 0xFFE91E63, 26));
        mediaFab.setOnClickListener(v -> { Tab t = cur(); if (t != null) screens.mediaSheet(t); });

        swipe.setColorSchemeColors(0xFFFF8A00, 0xFF00E5FF, 0xFF1E5BFF);
        swipe.setOnRefreshListener(() -> { WebView w = web(); if (w != null) w.reload(); else swipe.setRefreshing(false); });
        swipe.setOnChildScrollUpCallback((parent, child) -> { WebView w = web(); return w != null && w.getScrollY() > 0; });
        swipe.setEnabled(prefs.getBoolean("pull", true));

        urlBar.setOnFocusChangeListener((v, has) -> {
            WebView w = web();
            if (has) {
                String u = w == null ? null : w.getUrl();
                if (isRealUrl(u)) urlBar.setText(u);
                urlBar.post(urlBar::selectAll);
            } else if (w != null) {
                updateUrlBar(w.getUrl());
            }
        });
        urlBar.setOnEditorActionListener((v, id, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (id == EditorInfo.IME_ACTION_GO || enter) {
                navigate(urlBar.getText().toString());
                hideKeyboard();
                urlBar.clearFocus();
                return true;
            }
            return false;
        });

        findInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { WebView w = web(); if (w != null) w.findAllAsync(s.toString()); }
        });
        findViewById(R.id.findNext).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(true); });
        findViewById(R.id.findPrev).setOnClickListener(v -> { WebView w = web(); if (w != null) w.findNext(false); });
        findViewById(R.id.findClose).setOnClickListener(v -> closeFind());
    }

    // ───────────────────────── TABS ─────────────────────────

    Tab cur() { return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null; }
    WebView web() { Tab t = cur(); return t == null ? null : t.web; }
    boolean isCurrent(Tab t) { return cur() == t; }

    Tab createTab(String url, boolean incognito, boolean show) {
        Tab t = new Tab();
        t.incognito = incognito;
        t.web = buildWebView(t);
        tabs.add(t);
        if (show) switchTab(tabs.size() - 1); else updateUi();
        if (url != null) t.web.loadUrl(url);
        tabCount.setText(String.valueOf(tabs.size()));
        return t;
    }

    void switchTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab old = cur();
        Tab t = tabs.get(i);
        if (old != null && old != t) { captureThumb(old); old.web.onPause(); }
        webContainer.removeAllViews();
        current = i;
        if (t.web.getParent() != null) ((ViewGroup) t.web.getParent()).removeView(t.web);
        webContainer.addView(t.web);
        t.web.onResume();
        int p = t.web.getProgress();
        setLoadingState(p < 100);
        progress.setProgress(p);
        updateUi();
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        webContainer.removeView(t.web);
        if (t.incognito) { t.web.clearHistory(); t.web.clearCache(true); t.web.clearFormData(); }
        t.web.destroy();
        if (tabs.isEmpty()) { current = -1; createTab(HOME, false, true); return; }
        int ni = (i == current) ? Math.min(i, tabs.size() - 1) : (current > i ? current - 1 : current);
        current = -1;
        switchTab(ni);
    }

    /** Tab ki chhoti photo (Chrome jaisi tab list ke liye). */
    void captureThumb(Tab t) {
        if (t == null) return;
        try {
            WebView w = t.web;
            int W = w.getWidth(), H = w.getHeight();
            if (W <= 0 || H <= 0) return;
            float s = 0.4f;
            Bitmap b = Bitmap.createBitmap((int) (W * s), (int) (H * s), Bitmap.Config.RGB_565);
            Canvas c = new Canvas(b);
            c.scale(s, s);
            c.translate(-w.getScrollX(), -w.getScrollY());
            w.draw(c);
            t.thumb = b;
        } catch (Throwable ignored) {}
    }

    WebView buildWebView(Tab t) {
        final WebView w = new WebView(this);
        w.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        w.setBackgroundColor(Color.WHITE);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(prefs.getInt("textZoom", 100));
        s.setLoadsImagesAutomatically(!prefs.getBoolean("datasaver", false));
        s.setUserAgentString(prefs.getBoolean("desktop", false) ? DESKTOP_UA : mobileUA);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new BClient(t));
        w.setWebChromeClient(new BChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> onDownload(url, ua, cd, mime, len));
        w.setOnLongClickListener(v -> onLongPress(w));
        w.setFindListener((active, num, done) ->
                findCount.setText(num == 0 ? "0/0" : (active + 1) + "/" + num));
        return w;
    }

    // ───────────────────────── WEB CLIENTS ─────────────────────────

    class BClient extends WebViewClient {
        final Tab t;
        BClient(Tab t) { this.t = t; }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleSpecialUrl(v, r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap fav) {
            synchronized (t.media) { t.media.clear(); }
            if (isCurrent(t)) { setLoadingState(true); updateUi(); }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (isCurrent(t)) { setLoadingState(false); swipe.setRefreshing(false); updateUi(); }
            if (url == null) return;
            if (url.startsWith(HOME)) {
                v.evaluateJavascript("window.setEngine&&setEngine('" + engine() + "');" +
                        (t.incognito ? "window.setIncog&&setIncog();" : ""), null);
            } else {
                applyNight(v, url);
                scanMedia(t, null);
                String title = v.getTitle();
                if (!t.incognito && url.startsWith("http") && (title == null || !title.startsWith("Baatora Error"))) {
                    addHistory(title, url);
                }
            }
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean reload) {
            if (isCurrent(t)) updateUi();
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (adBlock && isAd(u.getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            String s = u.toString();
            if (isMediaUrl(s)) addMedia(t, s);
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String failing = r.getUrl().toString();
                v.loadDataWithBaseURL(null, errorPage(failing, String.valueOf(e.getDescription())),
                        "text/html", "UTF-8", failing);
            }
        }
    }

    class BChrome extends WebChromeClient {
        final Tab t;
        BChrome(Tab t) { this.t = t; }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (isCurrent(t)) {
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
        }

        @Override
        public void onReceivedTitle(WebView v, String title) { t.title = title; }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) { showCustom(view, cb); }

        @Override
        public void onHideCustomView() { hideCustom(); }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            try {
                Intent i = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                startActivityForResult(Intent.createChooser(i, "File chunein"), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                toast("File chooser nahi khula");
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            ArrayList<String> missing = new ArrayList<>();
            for (String r : request.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !granted(Manifest.permission.CAMERA))
                    missing.add(Manifest.permission.CAMERA);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !granted(Manifest.permission.RECORD_AUDIO))
                    missing.add(Manifest.permission.RECORD_AUDIO);
            }
            if (missing.isEmpty()) {
                request.grant(request.getResources());
            } else {
                pendingPermission = request;
                requestPermissions(missing.toArray(new String[0]), REQ_WEB_PERM);
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                cb.invoke(origin, true, false);
            } else {
                geoOrigin = origin;
                geoCallback = cb;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            Tab nt = createTab(null, t.incognito, true);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nt.web);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView w) {
            for (int i = 0; i < tabs.size(); i++) {
                if (tabs.get(i).web == w) { closeTab(i); break; }
            }
        }
    }

    // ───────────────────────── MEDIA (video/audio files) ─────────────────────────

    static boolean isMediaUrl(String url) {
        try {
            String path = Uri.parse(url).getPath();
            if (path == null) return false;
            path = path.toLowerCase();
            for (String e : MEDIA_EXT) if (path.endsWith(e)) return true;
        } catch (Exception ignored) {}
        return false;
    }

    /** YouTube apni videos download karne ki ijazat nahi deta, isliye inhe chhod dete hain. */
    static boolean isYouTube(String url) {
        if (url == null) return false;
        String h = Uri.parse(url).getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        return h.endsWith("youtube.com") || h.equals("youtu.be") || h.endsWith("googlevideo.com")
                || h.endsWith("ytimg.com") || h.endsWith("youtube-nocookie.com");
    }

    void addMedia(Tab t, String url) {
        if (isYouTube(url)) return;
        synchronized (t.media) {
            if (t.media.contains(url) || t.media.size() >= 30) return;
            t.media.add(url);
        }
        runOnUiThread(() -> { if (isCurrent(t)) updateMediaFab(); });
    }

    void scanMedia(Tab t, Runnable after) {
        t.web.evaluateJavascript(MEDIA_JS, val -> {
            try {
                Object o = new JSONTokener(val).nextValue();
                JSONArray a = new JSONArray(String.valueOf(o));
                for (int i = 0; i < a.length(); i++) {
                    String u = a.optString(i);
                    if (isMediaUrl(u)) addMedia(t, u);
                }
            } catch (Exception ignored) {}
            if (after != null) after.run();
        });
    }

    void updateMediaFab() {
        Tab t = cur();
        if (t == null) { mediaFab.setVisibility(View.GONE); return; }
        int n;
        synchronized (t.media) { n = t.media.size(); }
        boolean show = n > 0 && !isYouTube(t.web.getUrl());
        mediaFab.setVisibility(show ? View.VISIBLE : View.GONE);
        mediaFab.setText("⬇  Download (" + n + ")");
    }

    // ───────────────────────── NAVIGATION ─────────────────────────

    boolean handleSpecialUrl(WebView v, String url) {
        String low = url.toLowerCase();
        if (low.startsWith("baatora://")) {
            String cmd = low.substring(10);
            if (cmd.startsWith("voice")) voiceSearch();
            else if (cmd.startsWith("downloads")) screens.downloads();
            else if (cmd.startsWith("history")) screens.list("history", "History");
            else if (cmd.startsWith("bookmarks")) screens.list("bookmarks", "Bookmarks");
            else if (cmd.startsWith("incognito")) createTab(HOME, true, true);
            else if (cmd.startsWith("tabs")) screens.tabs();
            else if (cmd.startsWith("about")) screens.about();
            return true;
        }
        if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("file://")
                || low.startsWith("about:") || low.startsWith("javascript:") || low.startsWith("data:")
                || low.startsWith("blob:")) {
            return false;
        }
        try {
            if (low.startsWith("intent:")) {
                Intent it = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                it.addCategory(Intent.CATEGORY_BROWSABLE);
                it.setComponent(null);
                try {
                    startActivity(it);
                } catch (ActivityNotFoundException e) {
                    String fb = it.getStringExtra("browser_fallback_url");
                    if (fb != null) v.loadUrl(fb);
                    else if (it.getPackage() != null)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + it.getPackage())));
                }
                return true;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("Is link ke liye koi app nahi mila");
        }
        return true;
    }

    void navigate(String input) {
        String q = input.trim();
        if (q.isEmpty()) return;
        String url;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") || q.startsWith("about:")) url = q;
        else if (!q.contains(" ") && (q.matches("^[^\\s]+\\.[a-zA-Z]{2,}(/.*)?(:\\d+)?.*$") || q.startsWith("localhost")))
            url = "https://" + q;
        else url = searchUrl(q);
        WebView w = web();
        if (w != null) w.loadUrl(url);
    }

    String engine() { return prefs.getString("engine", "google"); }

    String searchUrl(String q) {
        String enc;
        try { enc = URLEncoder.encode(q, "UTF-8"); } catch (Exception e) { enc = q; }
        switch (engine()) {
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "duckduckgo": return "https://duckduckgo.com/?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://www.google.com/search?q=" + enc;
        }
    }

    boolean isAd(String host) {
        if (host == null) return false;
        for (String a : AD_HOSTS) if (host.equals(a) || host.endsWith("." + a)) return true;
        return false;
    }

    static boolean isRealUrl(String u) {
        return u != null && !u.startsWith("file:///android_asset") && !u.startsWith("data:") && !u.equals("about:blank");
    }

    // ───────────────────────── UI STATE ─────────────────────────

    void updateUi() {
        Tab t = cur();
        if (t == null) return;
        updateUrlBar(t.web.getUrl());
        btnBack.setAlpha(t.web.canGoBack() ? 1f : 0.35f);
        btnForward.setAlpha(t.web.canGoForward() ? 1f : 0.35f);
        tabCount.setText(String.valueOf(tabs.size()));
        int[] colors = t.incognito
                ? new int[]{0xFF1A0B2E, 0xFF3D1670, 0xFF6A1FB0}
                : new int[]{0xFF06103A, 0xFF0D2A8A, 0xFF1E5BFF};
        topBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors));
        getWindow().setStatusBarColor(colors[0]);
        urlBar.setHint(t.incognito ? "🕶 Incognito search ya URL" : "Search ya URL likhein");
        updateMediaFab();
    }

    void updateUrlBar(String url) {
        if (urlBar.hasFocus()) return;
        if (!isRealUrl(url)) {
            urlBar.setText("");
            lockIcon.setVisibility(View.GONE);
            return;
        }
        lockIcon.setVisibility(View.VISIBLE);
        lockIcon.setColorFilter(url.startsWith("https://") ? 0xFF2E7D32 : 0xFFD32F2F);
        urlBar.setText(url.replaceFirst("^https?://(www\\.)?", ""));
    }

    void setLoadingState(boolean l) {
        loading = l;
        btnRefresh.setImageResource(l ? R.drawable.ic_close : R.drawable.ic_refresh);
        progress.setVisibility(l ? View.VISIBLE : View.GONE);
    }

    void applyNight(WebView w, String url) {
        if (w == null || !isRealUrl(url)) return;
        w.evaluateJavascript(String.format(NIGHT_JS, prefs.getBoolean("night", false) ? "true" : "false"), null);
    }

    // ───────────────────────── FULL SCREEN ─────────────────────────

    void showCustom(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) { cb.onCustomViewHidden(); return; }
        customView = v;
        customCallback = cb;
        fullscreenContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fullscreenContainer.setVisibility(View.VISIBLE);
        hideSystemUi();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    void hideCustom() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        if (!appFull) showSystemUi();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    void setAppFull(boolean f) {
        appFull = f;
        topBar.setVisibility(f ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(f ? View.GONE : View.VISIBLE);
        if (f) { hideSystemUi(); toast("Full screen band karne ke liye Back dabayein"); }
        else showSystemUi();
    }

    @SuppressWarnings("deprecation")
    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressWarnings("deprecation")
    void showSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ───────────────────────── MENU ACTIONS ─────────────────────────

    boolean on(String key, boolean def) { return prefs.getBoolean(key, def); }

    void toggleDesktop() {
        boolean d = !on("desktop", false);
        prefs.edit().putBoolean("desktop", d).apply();
        for (Tab t : tabs) t.web.getSettings().setUserAgentString(d ? DESKTOP_UA : mobileUA);
        WebView w = web(); if (w != null) w.reload();
        toast(d ? "Desktop site ON" : "Mobile site ON");
    }

    void toggleNight() {
        boolean n = !on("night", false);
        prefs.edit().putBoolean("night", n).apply();
        for (Tab t : tabs) applyNight(t.web, t.web.getUrl());
        toast(n ? "Night mode ON 🌙" : "Night mode OFF");
    }

    void toggleAdBlock() {
        adBlock = !adBlock;
        prefs.edit().putBoolean("adblock", adBlock).apply();
        WebView w = web(); if (w != null) w.reload();
        toast(adBlock ? "Ad Block ON 🛡" : "Ad Block OFF");
    }

    void toggleDataSaver() {
        boolean d = !on("datasaver", false);
        prefs.edit().putBoolean("datasaver", d).apply();
        for (Tab t : tabs) t.web.getSettings().setLoadsImagesAutomatically(!d);
        WebView w = web(); if (w != null) w.reload();
        toast(d ? "Data Saver ON (images band)" : "Data Saver OFF");
    }

    void togglePull() {
        boolean p = !on("pull", true);
        prefs.edit().putBoolean("pull", p).apply();
        swipe.setEnabled(p);
        toast(p ? "Pull-to-refresh ON" : "Pull-to-refresh OFF");
    }

    void chooseTextSize() {
        final int[] sizes = {75, 90, 100, 115, 130, 150};
        String[] names = {"75% (Chhota)", "90%", "100% (Normal)", "115%", "130%", "150% (Bada)"};
        int now = prefs.getInt("textZoom", 100), sel = 2;
        for (int i = 0; i < sizes.length; i++) if (sizes[i] == now) sel = i;
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Text size")
                .setSingleChoiceItems(names, sel, (d, w) -> {
                    prefs.edit().putInt("textZoom", sizes[w]).apply();
                    for (Tab t : tabs) t.web.getSettings().setTextZoom(sizes[w]);
                    d.dismiss();
                }).show();
    }

    void chooseEngine() {
        final String[] keys = {"google", "bing", "duckduckgo", "yahoo"};
        String[] names = {"Google", "Bing", "DuckDuckGo", "Yahoo"};
        int sel = 0;
        for (int i = 0; i < keys.length; i++) if (keys[i].equals(engine())) sel = i;
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Search engine")
                .setSingleChoiceItems(names, sel, (d, w) -> {
                    prefs.edit().putString("engine", keys[w]).apply();
                    WebView wv = web();
                    if (wv != null) wv.evaluateJavascript("window.setEngine&&setEngine('" + keys[w] + "')", null);
                    toast(names[w] + " select ho gaya");
                    d.dismiss();
                }).show();
    }

    void savePdf() {
        WebView w = web();
        if (w == null || !isRealUrl(w.getUrl())) { toast("Pehle koi website kholein"); return; }
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            String name = "Baatora_" + System.currentTimeMillis();
            PrintDocumentAdapter a = w.createPrintDocumentAdapter(name);
            pm.print(name, a, new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast("PDF save nahi ho saka");
        }
    }

    void clearData() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Data clear karein?")
                .setMessage("Cache, cookies, history aur site data hat jayega. Bookmarks aur downloads safe rahenge.")
                .setPositiveButton("Clear", (d, w) -> {
                    for (Tab t : tabs) { t.web.clearCache(true); t.web.clearHistory(); t.web.clearFormData(); }
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    save("history", new JSONArray());
                    toast("Sab saaf ho gaya ✅");
                    updateUi();
                })
                .setNegativeButton("Cancel", null).show();
    }

    void openFind() {
        findBar.setVisibility(View.VISIBLE);
        findInput.setText("");
        findInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
    }

    void closeFind() {
        findBar.setVisibility(View.GONE);
        WebView w = web(); if (w != null) w.clearMatches();
        hideKeyboard();
    }

    void voiceSearch() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye... 🎤");
        try { startActivityForResult(i, REQ_VOICE); }
        catch (ActivityNotFoundException e) { toast("Voice search is phone par available nahi hai"); }
    }

    boolean onLongPress(WebView w) {
        WebView.HitTestResult h = w.getHitTestResult();
        final String extra = h.getExtra();
        int type = h.getType();
        if (extra == null) return false;
        final boolean isImg = type == WebView.HitTestResult.IMAGE_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE;
        boolean isLink = type == WebView.HitTestResult.SRC_ANCHOR_TYPE;
        if (!isImg && !isLink) return false;
        Tab owner = cur();
        final boolean inc = owner != null && owner.incognito;
        String[] opts = isImg
                ? new String[]{"Image naye tab me kholein", "Image download karein", "Image link copy", "Share karein"}
                : new String[]{"Naye tab me kholein", "Incognito tab me kholein", "Link copy karein", "Share karein"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(extra.length() > 80 ? extra.substring(0, 80) + "…" : extra)
                .setItems(opts, (d, which) -> {
                    switch (which) {
                        case 0: createTab(extra, inc, false); toast("Naye tab me khul gaya"); break;
                        case 1:
                            if (isImg) onDownload(extra, w.getSettings().getUserAgentString(), null, null, 0);
                            else createTab(extra, true, true);
                            break;
                        case 2: copy(extra); break;
                        case 3: share(extra); break;
                    }
                }).show();
        return true;
    }

    // ───────────────────────── DOWNLOADS ─────────────────────────

    void onDownload(String url, String ua, String cd, String mime, long len) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Is tarah ka download abhi support nahi hai");
            return;
        }
        if (isYouTube(url)) { screens.youtubeInfo(); return; }
        String name = URLUtil.guessFileName(url, cd, mime);
        screens.downloadSheet(url, ua, mime, name, len);
    }

    void startDownload(String url, String ua, String mime, String name) {
        if (Build.VERSION.SDK_INT < 29 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("Storage permission dein, phir dobara download karein");
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.addRequestHeader("User-Agent", ua != null ? ua : mobileUA);
            WebView w = web();
            if (w != null && isRealUrl(w.getUrl())) r.addRequestHeader("Referer", w.getUrl());
            r.setTitle(name);
            r.setDescription("Baatora Browser");
            r.setAllowedOverMetered(true);
            r.setAllowedOverRoaming(true);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = dm.enqueue(r);
            JSONArray ids = load("dl_ids");
            ids.put(id);
            save("dl_ids", ids);
            toast("Download shuru ⬇ " + name);
        } catch (Exception e) {
            toast("Download fail: " + e.getMessage());
        }
    }

    // ───────────────────────── BOOKMARKS / HISTORY ─────────────────────────

    JSONArray load(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    void save(String key, JSONArray arr) { prefs.edit().putString(key, arr.toString()).apply(); }

    void addHistory(String title, String url) {
        try {
            JSONArray old = load("history");
            JSONArray arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(title) ? url : title);
            o.put("u", url);
            o.put("time", System.currentTimeMillis());
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 500; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !url.equals(x.optString("u"))) arr.put(x);
            }
            save("history", arr);
        } catch (Exception ignored) {}
    }

    void addBookmark() {
        WebView w = web();
        String u = w == null ? null : w.getUrl();
        if (!isRealUrl(u)) { toast("Pehle koi website kholein"); return; }
        try {
            JSONArray arr = load("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.optJSONObject(i);
                if (x != null && u.equals(x.optString("u"))) { toast("Ye pehle se bookmark hai ⭐"); return; }
            }
            JSONObject o = new JSONObject();
            o.put("t", TextUtils.isEmpty(w.getTitle()) ? u : w.getTitle());
            o.put("u", u);
            o.put("time", System.currentTimeMillis());
            JSONArray out = new JSONArray();
            out.put(o);
            for (int i = 0; i < arr.length(); i++) out.put(arr.get(i));
            save("bookmarks", out);
            toast("Bookmark ho gaya ⭐");
        } catch (Exception e) {
            toast("Bookmark nahi ho saka");
        }
    }

    // ───────────────────────── RESULTS / PERMISSIONS ─────────────────────────

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    results = new Uri[cd.getItemCount()];
                    for (int i = 0; i < cd.getItemCount(); i++) results[i] = cd.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        } else if (req == REQ_VOICE && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) navigate(r.get(0));
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        boolean all = results.length > 0, any = false;
        for (int r : results) { if (r == PackageManager.PERMISSION_GRANTED) any = true; else all = false; }
        if (req == REQ_WEB_PERM && pendingPermission != null) {
            if (all) pendingPermission.grant(pendingPermission.getResources());
            else pendingPermission.deny();
            pendingPermission = null;
        } else if (req == REQ_GEO && geoCallback != null) {
            geoCallback.invoke(geoOrigin, any, false);
            geoCallback = null;
        }
    }

    boolean granted(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    // ───────────────────────── HELPERS ─────────────────────────

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void copy(String s) {
        if (s == null) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("link", s));
        toast("Copy ho gaya 📋");
    }

    void share(String s) {
        if (!isRealUrl(s)) { toast("Share karne ke liye koi page kholein"); return; }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, s);
        startActivity(Intent.createChooser(i, "Share karein"));
    }

    static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    String errorPage(String url, String desc) {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<title>Baatora Error</title><style>" +
                "body{margin:0;font-family:sans-serif;background:linear-gradient(160deg,#06103A,#1E5BFF);color:#fff;" +
                "display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;" +
                "text-align:center;padding:24px;box-sizing:border-box}" +
                "h1{font-size:64px;margin:0}h2{margin:12px 0 6px}p{opacity:.85;font-size:14px;word-break:break-all;margin:6px 0}" +
                "a{display:inline-block;margin-top:22px;padding:14px 34px;border-radius:30px;" +
                "background:linear-gradient(90deg,#FF8A00,#FFC107);color:#06103A;font-weight:bold;text-decoration:none}" +
                "</style></head><body><h1>📡</h1><h2>Page nahi khul paya</h2>" +
                "<p>Internet connection check karein, phir dobara try karein.</p>" +
                "<p style='opacity:.6'>" + esc(desc) + "</p>" +
                "<a href=\"" + esc(url) + "\">Dobara try karein</a>" +
                "<p style='margin-top:34px;color:#FFC107;opacity:1'>Made in India 🇮🇳</p></body></html>";
    }
}
