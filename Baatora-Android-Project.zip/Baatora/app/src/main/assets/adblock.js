(function(){
if(window.__btgen)return;window.__btgen=1;
try{Notification.requestPermission=function(){return Promise.resolve('denied')};}catch(e){}
try{Object.defineProperty(Notification,'permission',{get:function(){return 'denied'}});}catch(e){}
var host=(location.hostname||'').toLowerCase();
if(/(^|\.)(youtube\.com|google\.[a-z.]+|instagram\.com|facebook\.com|twitter\.com|x\.com|wikipedia\.org|amazon\.[a-z.]+|flipkart\.com|whatsapp\.com|github\.com)$/.test(host))return;
var adHost=/(doubleclick|googlesyndication|adservice\.google|exoclick|exosrv|exdynsrv|juicyads|trafficstars|clickadu|hilltopads|adcash|popcash|propellerads|onclkds|clickaine|realsrv|magsrv|tsyndicate|adsterra|a-ads|adskeeper|richpush|admaven|ad-maven|bidvertiser|plugrush|ero-advertising|yllix|popads|monetag|profitableratecpm|highperformanceformat|effectivegatecpm|oclasrv|taboola|outbrain|mgid|revcontent|zedo|criteo|moatads|adnxs|4rabet|1xbet|mostbet|1win|melbet|parimatch|linebet|betwinner)/i;
var bad=/(welcome pack|welcome bonus|bonus up to|\u20b9\s?[\d,]+\s?(welcome )?bonus|\d{2,4}\s?% bonus|casino|jackpot|you(?:'|\u2019)?ve won|you have won|congratulations.{0,40}(prize|won|winner)|click allow|press allow|allow notifications|your (phone|device) (is|has been) (infected|hacked)|virus detected)/i;
var fakeHuman=/(verify you.?re human|i.?m human|i am human)/i;
function kill(e){try{e.style.setProperty('display','none','important');e.style.setProperty('pointer-events','none','important');}catch(x){}}
function rect(e){return e.getBoundingClientRect();}
var adLbl=/^(ad|ads|advert|advertisement|sponsored|\u0935\u093f\u091c\u094d\u091e\u093e\u092a\u0928|\u092a\u094d\u0930\u093e\u092f\u094b\u091c\u093f\u0924)$/i;
var skipRe=/^(skip|skip ad|skip ads|skip in \d+|\u091b\u094b\u0921\u093c\u0947\u0902|\u0938\u094d\u0915\u093f\u092a)/i;
var sped=null;
function hasAdLabel(c){
 try{var els=c.querySelectorAll('span,div,a,p,b,small,button');var m=Math.min(els.length,400);
  for(var i=0;i<m;i++){var e=els[i];if(e.children.length)continue;var t=(e.textContent||'').trim();
   if(t&&t.length<24&&adLbl.test(t)){var r=e.getBoundingClientRect();if(r.width>0&&r.height>0)return e;}}
 }catch(x){}
 return null;
}
/* Video player ke andar ad chal raha ho to use mute + tez + skip karo */
function playerAd(){
 try{
  var vs=document.querySelectorAll('video');
  for(var k=0;k<vs.length;k++){
   var v=vs[k];var r=v.getBoundingClientRect();if(r.width<120||r.height<80)continue;
   var c=v.parentElement;
   for(var u=0;u<4&&c&&c.parentElement&&c.parentElement!==document.body;u++)c=c.parentElement;
   if(!c)continue;
   if(hasAdLabel(c)){
    v.muted=true;sped=v;
    try{v.playbackRate=16;}catch(e){}
    if(isFinite(v.duration)&&v.duration>0&&v.duration<150&&v.currentTime<v.duration-0.3){try{v.currentTime=v.duration-0.1;}catch(e){}}
    var bs=c.querySelectorAll('button,div,a,span');
    for(var b=0;b<bs.length&&b<300;b++){var bt=(bs[b].textContent||'').trim();if(bt.length<30&&skipRe.test(bt)){try{bs[b].click();}catch(e){}break;}}
   }else if(sped===v){try{v.muted=false;v.playbackRate=1;}catch(e){}sped=null;}
  }
 }catch(x){}
}
setInterval(playerAd,400);
/* "Ad / Sponsored / Vigyapan" likha hua dabba (player ke bahar) hata do */
function killSponsored(){
 try{
  if(!document.body)return;
  var els=document.body.querySelectorAll('span,div,a,p,small');var m=Math.min(els.length,1500);
  for(var i=0;i<m;i++){var e=els[i];if(e.children.length||e.__bts)continue;
   var t=(e.textContent||'').trim();if(!t||t.length>20||!adLbl.test(t))continue;
   e.__bts=1;
   if(e.closest('video')||e.closest('[class*=player],[id*=player]'))continue;
   var c=e;
   for(var u=0;u<3&&c.parentElement&&c.parentElement!==document.body;u++){
    var p=c.parentElement;
    if(p.getBoundingClientRect().height>innerHeight*0.85||p.querySelector('video,input,nav,form')||p.querySelectorAll('a[href]').length>6)break;
    c=p;
   }
   kill(c);
  }
 }catch(x){}
}
function killPromoLinks(){
 try{document.querySelectorAll('a[href*="faphouse.com"]').forEach(function(a){
  kill(a);var p=a.parentElement;if(p&&p!==document.body&&(p.innerText||'').length<90)kill(p);
 });}catch(x){}
}
var pending=0;
function scan(){
 pending=0;
 try{
  var killed=0;
 killSponsored();killPromoLinks();
  document.querySelectorAll('iframe').forEach(function(f){var s=f.src||'';if(s&&adHost.test(s)){kill(f);killed++;}});
  document.querySelectorAll('ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[class*="pop-under"],[id*="popunder"],[class*="ad-overlay"],[id*="ad-overlay"],a[href*="exoclick"],a[href*="juicyads"],a[href*="clickadu"],a[href*="adsterra"],a[href*="hilltopads"]').forEach(function(e){kill(e);});
  if(!document.body)return;
  var all=document.body.querySelectorAll('div,section,aside,a,iframe,ins,span');
  var lim=Math.min(all.length,1800);
  for(var i=0;i<lim;i++){
   var e=all[i];
   if(e.style&&e.style.display==='none')continue;
   var cs=getComputedStyle(e);
   var pos=cs.position;
   if(pos!=='fixed'&&pos!=='absolute'&&pos!=='sticky')continue;
   var z=parseInt(cs.zIndex)||0;
   if(z<100)continue;
   var r=rect(e);
   if(r.width<40||r.height<20)continue;
   var t=(e.innerText||'').slice(0,800);
   if(t){
     if(bad.test(t)){kill(e);killed++;continue;}
     if(fakeHuman.test(t)&&e.querySelector('input[type=password]')){kill(e);killed++;continue;}
   }else if(pos==='fixed'||pos==='absolute'){
     var full=r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9;
     var clear=parseFloat(cs.opacity)<=0.05||cs.backgroundColor==='rgba(0, 0, 0, 0)'||cs.backgroundColor==='transparent';
     if(full&&z>=1000&&clear&&(e.tagName==='A'||e.tagName==='DIV'||e.tagName==='IFRAME')&&!e.querySelector('video,canvas')){kill(e);killed++;}
   }
  }
  if(killed>0){
   for(var j=0;j<lim;j++){
    var b=all[j];var c2=getComputedStyle(b);
    if(c2.position==='fixed'&&!(b.innerText||'').trim()&&(parseInt(c2.zIndex)||0)>=100){
     var rr=rect(b);
     if(rr.width>=innerWidth*0.9&&rr.height>=innerHeight*0.9&&!b.querySelector('video,canvas,img')) kill(b);
    }
   }
   document.body.style.setProperty('overflow','auto','important');
   document.documentElement.style.setProperty('overflow','auto','important');
  }
 }catch(x){}
}
function later(){if(!pending){pending=1;setTimeout(scan,700);}}
document.addEventListener('click',function(ev){
 try{var a=ev.target&&ev.target.closest&&ev.target.closest('a[href]');
  if(a&&a.target==='_blank'&&adHost.test(a.href)){ev.preventDefault();ev.stopPropagation();}}catch(e){}
},true);
try{new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
var n=0,iv=setInterval(function(){scan();if(++n>20)clearInterval(iv);},1500);
scan();
})();
