/* Baatora YouTube Ad Block — page ke shuru me hi chalta hai.
   YouTube ke player data se ads ki jaankari hata deta hai, isliye ad load hi nahi hota. */
(function(){
if(window.__btyt)return;window.__btyt=1;
try{if(window.BaatoraCfg&&!BaatoraCfg.ad())return;}catch(e){}

var removed=0,repT=0;
function report(){if(!removed||repT)return;repT=setTimeout(function(){try{if(window.BaatoraCfg)BaatoraCfg.blocked(removed);}catch(e){}removed=0;repT=0;},1500);}
/* Note: video (player) ke data ko nahi chhedte — warna YouTube video ghoomta rehta hai (loading).
   Sirf home/search/related list se ad cards hatate hain, aur video ke ad ko turant skip karte hain. */
var AD_ITEM=/^(adSlotRenderer|promotedSparklesWebRenderer|promotedSparklesTextSearchRenderer|promotedVideoRenderer|compactPromotedVideoRenderer|displayAdRenderer|searchPyvRenderer|inFeedAdLayoutRenderer|bannerPromoRenderer|statementBannerRenderer|brandVideoSingletonRenderer|brandVideoShelfRenderer|primetimePromoRenderer|mealbarPromoRenderer|textAdRenderer|carouselAdRenderer|movingThumbnailAdRenderer)$/;
function isAdItem(x){
 if(!x||typeof x!=='object'||Array.isArray(x))return false;
 for(var k in x){
  if(AD_ITEM.test(k))return true;
  if(k==='richItemRenderer'||k==='itemSectionRenderer'||k==='richSectionRenderer'){
   var c=x[k]&&(x[k].content||(x[k].contents&&x[k].contents.length===1&&x[k].contents[0]));
   if(c&&typeof c==='object')for(var j in c)if(AD_ITEM.test(j))return true;
  }
 }
 return false;
}
function strip(o,depth){
 if(!o||typeof o!=='object'||depth>30)return;
 if(o.streamingData||o.playerConfig||o.videoDetails)return; /* player data: haath nahi lagana */
 if(Array.isArray(o)){
  for(var i=o.length-1;i>=0;i--){if(isAdItem(o[i])){o.splice(i,1);removed++;}else strip(o[i],depth+1);}
  return;
 }
 for(var k in o){if(k==='playerResponse')continue;var v=o[k];if(v&&typeof v==='object')strip(v,depth+1);}
}
function clean(o){try{if(o&&typeof o==='object'&&!o.streamingData){strip(o,0);report();}}catch(e){}return o;}

/* list wala data (home / search / related) */
try{
 var jp=JSON.parse;
 JSON.parse=function(){var r=jp.apply(this,arguments);
  try{var s=arguments[0];if(typeof s==='string'&&s.length>500&&!/"streamingData"/.test(s)&&/"(adSlotRenderer|promotedSparklesWebRenderer|displayAdRenderer|inFeedAdLayoutRenderer|promotedVideoRenderer|compactPromotedVideoRenderer)"/.test(s))clean(r);}catch(e){}
  return r;};
}catch(e){}
try{var val;Object.defineProperty(window,'ytInitialData',{configurable:true,get:function(){return val;},set:function(v){val=clean(v);}});}catch(e){}

/* 5) Bache hue ad dabbe CSS se chhupao */
var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,'+
'ad-slot-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytm-promoted-sparkles-text-search-renderer,'+
'ytm-statement-banner-renderer,ytd-statement-banner-renderer,ytm-paid-content-overlay-renderer,ytm-mealbar-promo-renderer,'+
'ytm-companion-slot,ytm-display-ad-renderer,ytm-in-feed-ad-layout-renderer,ytm-brand-video-singleton-renderer,ytm-search-pyv-renderer,'+
'ytm-rich-item-renderer:has(ytm-ad-slot-renderer),ytm-rich-item-renderer:has(ad-slot-renderer),ytm-item-section-renderer:has(ytm-ad-slot-renderer),'+
'ytm-rich-section-renderer:has(ytm-statement-banner-renderer),ytd-rich-item-renderer:has(ytd-ad-slot-renderer),'+
'ytm-reel-shelf-renderer:has(ad-slot-renderer),ytm-merch-shelf-renderer,ytm-product-list-item-renderer,'+
'.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-module .ytp-ad-overlay-slot,#player-ads,#masthead-ad,'+
'.ytm-promoted-sparkles-web-renderer,.video-ads .ytp-ad-overlay-slot,ytm-engagement-panel-section-list-renderer[target-id*=ads],'+
'#tads,#tadsb,#bottomads,[data-text-ad],.commercial-unit-mobile-top,.uEierd,.ytp-ad-player-overlay,.ytp-ad-player-overlay-layout,'+
'.ytp-ad-text,.ytp-ad-preview-container,.ytp-ad-visit-advertiser-button,.ytm-ad-overlay,ytm-companion-ad-renderer{display:none!important}'+
'.ad-showing video,.ad-interrupting video{opacity:0!important}'+
'.html5-video-player.ad-showing:after,.html5-video-player.ad-interrupting:after{content:"\\23E9  Ad hata rahe hain\\2026";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#000;color:#FFC107;font:700 15px Roboto,sans-serif;z-index:99;pointer-events:none}';
function addCss(){try{if(document.getElementById('bt-ytcss'))return;var s=document.createElement('style');s.id='bt-ytcss';s.textContent=css;
 (document.head||document.documentElement).appendChild(s);}catch(e){}}
addCss();document.addEventListener('DOMContentLoaded',addCss);

/* 6) Agar phir bhi koi ad chal jaye to turant skip */
var muted=false;
setInterval(function(){try{
 var p=document.querySelector('.ad-showing,.ad-interrupting');
 var v=document.querySelector('.html5-video-player video,video');
 if(p&&v){
  if(!muted){removed++;report();}muted=true;v.muted=true;
  try{v.playbackRate=16;}catch(e){}
  if(isFinite(v.duration)&&v.duration>0&&v.duration<200&&v.currentTime<v.duration-0.2){try{v.currentTime=v.duration-0.05;}catch(e){}}
  var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-slot button,'+
   '.ytm-skip-ad-button,button[class*=skip-ad],button[class*=skip_ad],.ytp-ad-skip-button-container button');
  if(b)b.click();
 }else if(muted&&v){muted=false;v.muted=false;try{v.playbackRate=1;}catch(e){}}
 var c=document.querySelector('.ytp-ad-overlay-close-button');if(c)c.click();
 /* "Video paused. Continue watching?" ko apne aap haan */
 var cw=document.querySelector('ytm-dialog-renderer .yt-spec-button-shape-next, yt-confirm-dialog-renderer #confirm-button');
 if(cw&&/continue|jaari|haan|yes/i.test(cw.textContent||''))cw.click();
}catch(e){}},300);

/* Naya video khule to turant chalu ho (rukna na pade) */
var lastSrc='',srcAt=0,nudged=false;
setInterval(function(){try{
 if(!/\/(watch|shorts)/.test(location.pathname))return;
 var v=document.querySelector('.html5-video-player video,video');if(!v)return;
 var src=v.currentSrc||v.src||'';
 if(src!==lastSrc){lastSrc=src;srcAt=Date.now();nudged=false;}
 if(nudged||document.querySelector('.ad-showing'))return;
 var age=Date.now()-srcAt;
 if(age>1200&&age<8000&&v.paused&&v.currentTime<1&&v.readyState>=2){
  nudged=true;
  try{var mp=document.getElementById('movie_player');if(mp&&mp.playVideo)mp.playVideo();else v.play();}catch(e){try{v.play();}catch(x){}}
 }
}catch(e){}},500);
})();
