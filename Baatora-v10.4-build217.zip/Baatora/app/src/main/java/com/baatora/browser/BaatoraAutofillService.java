package com.baatora.browser;

import android.app.assist.AssistStructure;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveInfo;
import android.service.autofill.SaveRequest;
import android.text.InputType;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * Baatora ko Android ki "Autofill service" banata hai (Settings → Passwords & autofill → Preferred service me
 * Baatora apne logo ke saath dikhta hai). Doosri apps aur browsers me bhi Baatora ke saved password bhar sakta hai,
 * aur naya login save kar sakta hai. Data wahi encrypted vault hai jo Baatora Password Manager use karta hai.
 */
@android.annotation.TargetApi(26)
public class BaatoraAutofillService extends AutofillService {

    static class Found {
        AutofillId user, pass;
        String webDomain, pkg, userVal, passVal;
    }

    @Override
    public void onFillRequest(FillRequest req, CancellationSignal cancel, FillCallback cb) {
        try {
            List<FillContext> ctx = req.getFillContexts();
            AssistStructure st = ctx.get(ctx.size() - 1).getStructure();
            Found f = scan(st);
            if (f.pass == null) { cb.onSuccess(null); return; }
            String site = siteKey(f);
            Passwords pw = vault();
            JSONArray list = site == null ? new JSONArray() : pw.forSite(site);
            FillResponse.Builder rb = new FillResponse.Builder();
            int n = 0;
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.optJSONObject(i);
                if (o == null) continue;
                String u = o.optString("u"), p = pw.dec(o.optString("p"));
                if (p == null) continue;
                RemoteViews rv = row("🔑 " + (u.isEmpty() ? "Saved password" : u), site);
                Dataset.Builder db = new Dataset.Builder(rv);
                db.setValue(f.pass, AutofillValue.forText(p), row("🔑 " + (u.isEmpty() ? "Saved password" : u), site));
                if (f.user != null && !u.isEmpty()) db.setValue(f.user, AutofillValue.forText(u), row("👤 " + u, site));
                rb.addDataset(db.build());
                n++;
            }
            AutofillId[] ids = f.user != null ? new AutofillId[]{f.user, f.pass} : new AutofillId[]{f.pass};
            rb.setSaveInfo(new SaveInfo.Builder(
                    f.user != null ? (SaveInfo.SAVE_DATA_TYPE_USERNAME | SaveInfo.SAVE_DATA_TYPE_PASSWORD) : SaveInfo.SAVE_DATA_TYPE_PASSWORD,
                    ids).build());
            cb.onSuccess(rb.build());
        } catch (Throwable e) {
            cb.onSuccess(null);
        }
    }

    @Override
    public void onSaveRequest(SaveRequest req, SaveCallback cb) {
        try {
            List<FillContext> ctx = req.getFillContexts();
            Found f = scan(ctx.get(ctx.size() - 1).getStructure());
            String site = siteKey(f);
            if (site != null && f.passVal != null && f.passVal.length() >= 3) {
                vault().save(site, f.userVal == null ? "" : f.userVal.trim(), f.passVal);
            }
            cb.onSuccess();
        } catch (Throwable e) {
            cb.onFailure("Baatora could not save this password");
        }
    }

    Passwords vault() { return new Passwords(this, true); }

    RemoteViews row(String text, String site) {
        RemoteViews rv = new RemoteViews(getPackageName(), android.R.layout.simple_list_item_2);
        rv.setTextViewText(android.R.id.text1, text);
        rv.setTextViewText(android.R.id.text2, "Baatora • " + (site == null ? "" : site));
        return rv;
    }

    /** Website ka domain ho to wahi, warna app ka package naam (jaise "app:com.example"). */
    static String siteKey(Found f) {
        if (f.webDomain != null && !f.webDomain.isEmpty()) return Passwords.site(f.webDomain);
        if (f.pkg != null && !f.pkg.isEmpty()) return "app:" + f.pkg;
        return null;
    }

    Found scan(AssistStructure st) {
        Found f = new Found();
        try { f.pkg = st.getActivityComponent().getPackageName(); } catch (Exception ignored) {}
        if (getPackageName().equals(f.pkg)) f.pkg = null;   // Baatora khud ka form — page domain se chalega
        for (int i = 0; i < st.getWindowNodeCount(); i++) walk(st.getWindowNodeAt(i).getRootViewNode(), f);
        return f;
    }

    void walk(AssistStructure.ViewNode n, Found f) {
        if (n == null) return;
        if (n.getWebDomain() != null && !n.getWebDomain().isEmpty()) f.webDomain = n.getWebDomain();
        if (n.getAutofillId() != null && n.getAutofillType() == View.AUTOFILL_TYPE_TEXT) {
            String hints = "";
            if (n.getAutofillHints() != null) for (String h : n.getAutofillHints()) hints += h.toLowerCase() + " ";
            String meta = (hints + " " + n.getIdEntry() + " " + n.getHint() + " "
                    + (n.getHtmlInfo() != null ? n.getHtmlInfo().getAttributes() : "")).toLowerCase();
            int it = n.getInputType();
            boolean isPass = hints.contains("password") || meta.contains("type=password")
                    || (it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || (it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                    || (it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
            boolean isUser = !isPass && (hints.contains("username") || hints.contains("email") || hints.contains("phone")
                    || meta.contains("user") || meta.contains("email") || meta.contains("login") || meta.contains("mobile")
                    || (it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    || (it & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
            CharSequence val = n.getAutofillValue() != null && n.getAutofillValue().isText() ? n.getAutofillValue().getTextValue() : null;
            if (isPass && f.pass == null) { f.pass = n.getAutofillId(); f.passVal = val == null ? null : val.toString(); }
            else if (isUser && f.user == null) { f.user = n.getAutofillId(); f.userVal = val == null ? null : val.toString(); }
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChildAt(i), f);
    }
}
