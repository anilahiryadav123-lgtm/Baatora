package com.baatora.browser;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

/**
 * Home screen se khulne wali "App" — bina address bar ke, poori screen par sirf website (Chrome ki installed app jaisi).
 * Har website ka apna alag task (recents me apna naam + logo).
 */
public class WebAppActivity extends Activity {

    static final String EXTRA_NAME = "bt_app_name", EXTRA_COLOR = "bt_app_color";
    WebView web;
    ProgressBar bar;
    String homeHost;
    ValueCallback<Uri[]> fileCb;
    FrameLayout root, full;
    View customView;
    WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Uri data = getIntent().getData();
        if (data == null) { finish(); return; }
        homeHost = host(data.getHost());
        String name = getIntent().getStringExtra(EXTRA_NAME);
        int color = getIntent().getIntExtra(EXTRA_COLOR, Color.WHITE);

        Window w = getWindow();
        w.setStatusBarColor(color);
        w.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 23 && light(color))
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Recents me website ka naam + logo (Baatora nahi)
        try {
            Bitmap ic = iconFor(homeHost);
            setTaskDescription(new ActivityManager.TaskDescription(name != null ? name : homeHost, ic, color));
        } catch (Exception ignored) {}

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new FrameLayout.LayoutParams(-1, (int) (3 * getResources().getDisplayMetrics().density)));
        full = new FrameLayout(this);
        full.setBackgroundColor(Color.BLACK);
        full.setVisibility(View.GONE);
        root.addView(full, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        try { s.setUserAgentString(WebSettings.getDefaultUserAgent(this).replace("; wv", "")); } catch (Exception ignored) {}
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) return false;              // website ke andar hi chalo
                try { startActivity(Intent.parseUri(u, Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Exception e) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception ignored) {}
                }
                return true;                                         // upi:, tel:, intent: wagaira → phone ki app
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                bar.setProgress(p);
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public void onReceivedIcon(WebView v, Bitmap icon) {
                try { Ui.putIcon(Uri.parse(v.getUrl()).getHost(), icon); } catch (Exception ignored) {}
            }
            @Override public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                // Naya window → isi app me khol do
                WebView tmp = new WebView(WebAppActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView t, WebResourceRequest r) {
                        web.loadUrl(r.getUrl().toString()); t.destroy(); return true;
                    }
                });
                ((WebView.WebViewTransport) msg.obj).setWebView(tmp);
                msg.sendToTarget();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 7); return true; }
                catch (Exception e) { fileCb = null; return false; }
            }
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                customView = view; customCb = cb;
                full.addView(view, new FrameLayout.LayoutParams(-1, -1));
                full.setVisibility(View.VISIBLE);
            }
            @Override public void onHideCustomView() {
                if (customView != null) full.removeView(customView);
                full.setVisibility(View.GONE);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
            }
            @Override public void onPermissionRequest(android.webkit.PermissionRequest r) { r.grant(r.getResources()); }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                String fn = URLUtil.guessFileName(url, cd, mime);
                r.setMimeType(mime);
                r.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                r.addRequestHeader("User-Agent", ua);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "⬇ " + fn, Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show(); }
        });
        if (b != null) web.restoreState(b); else web.loadUrl(data.toString());
    }

    static String host(String h) { return h == null ? "" : h.toLowerCase().replaceFirst("^www\\.", ""); }

    static boolean light(int c) {
        return (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 > 150;
    }

    Bitmap iconFor(String h) {
        Bitmap b = Ui.CACHE.get(Ui.key(h));
        if (b != null) return b;
        try {
            java.io.File f = new java.io.File(new java.io.File(getCacheDir(), "fav"), Ui.key(h) + ".png");
            if (f.exists()) return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 7 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { if (customCb != null) customCb.onCustomViewHidden(); full.removeAllViews(); full.setVisibility(View.GONE); customView = null; return; }
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); if (web != null) web.saveState(o); }
    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() {
        if (web != null) { ((ViewGroup) web.getParent()).removeView(web); web.destroy(); }
        super.onDestroy();
    }
}
