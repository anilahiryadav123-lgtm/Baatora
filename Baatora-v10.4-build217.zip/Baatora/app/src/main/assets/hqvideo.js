/* Baatora HD Video — har website par video sabse achhi quality (1080p tak) me chalaye.
   Kaam: (1) network ko "tez 4G/WiFi" batata hai, (2) hls.js / dash.js / Shaka / video.js / JW Player
   ko player ke size ke hisaab se quality kam karne se rokta hai aur sabse oonchi quality chunta hai,
   (3) YouTube par HD lagata hai, (4) <video> me kai <source> hon to sabse achha chunta hai. */
(function(){
if(window.__bthq)return;window.__bthq=1;
try{if(window.BaatoraCfg&&BaatoraCfg.hq&&!BaatoraCfg.hq())return;}catch(e){}
var CAP=1080, BIG=5e7, host=(location.hostname||'').toLowerCase();
var isYT=/(^|\.)youtube(-nocookie)?\.com$/.test(host);

// ── 1) Network: "tez connection" (player shuruaat 144p/240p se na kare) ──
try{
 var defs={effectiveType:'4g',downlink:50,downlinkMax:Infinity,rtt:50,saveData:false,type:'wifi'};
 var c=navigator.connection;
 if(c){for(var k in defs)(function(k,v){try{Object.defineProperty(c,k,{get:function(){return v},configurable:true})}catch(e){}})(k,defs[k]);}
}catch(e){}

// ── helpers ──
function qn(s){s=String(s||'');if(/\b(4k|uhd)\b/i.test(s))return 2160;
 var m=s.match(/(?:^|[^0-9])(4320|2160|1440|1080|720|540|480|360|240|144)\s*p?(?![0-9])/i);return m?+m[1]:-1;}
function bestIdx(list,h){var bi=-1,bh=-1,bb=-1,ai=-1,ah=-1,ab=-1;
 for(var i=0;i<list.length;i++){var x=h(list[i]);if(!x)continue;var hh=x[0]||0,bw=x[1]||0;
  if(hh>ah||(hh===ah&&bw>ab)){ai=i;ah=hh;ab=bw;}
  if(hh<=CAP&&(hh>bh||(hh===bh&&bw>bb))){bi=i;bh=hh;bb=bw;}}
 return bi>=0?bi:ai;}
function trap(name,fn){
 try{
  if(window[name]){var p=fn(window[name]);if(p&&p!==window[name])try{window[name]=p}catch(e){}return;}
  var val;Object.defineProperty(window,name,{configurable:true,enumerable:true,
   get:function(){return val},set:function(v){try{val=v?fn(v)||v:v}catch(e){val=v}}});
 }catch(e){}
}

// ── 2) hls.js ──
function pickHls(h){
 try{if(!h||h.__btDone||!h.levels||!h.levels.length)return;
  var i=bestIdx(h.levels,function(l){return [l.height||qn(l.name||l.url),l.bitrate||0]});
  if(i<0)return;h.__btDone=1;
  try{h.autoLevelCapping=-1}catch(e){}
  try{h.startLevel=i}catch(e){}
  if(h.currentLevel!==i)try{h.nextLevel=i}catch(e){}
 }catch(e){}
}
function hookHls(h){try{if(h&&h.on){h.on('hlsManifestParsed',function(){pickHls(h)});h.on('hlsLevelsUpdated',function(){pickHls(h)});}}catch(e){}}
function patchHls(H){
 if(typeof H!=='function'||H.__bt)return H;
 var W=function(cfg){
  var c={};try{for(var k in (cfg||{}))c[k]=cfg[k]}catch(e){}
  c.capLevelToPlayerSize=false;c.abrEwmaDefaultEstimate=BIG;c.testBandwidth=false;
  var o=Reflect.construct(H,[c],H);hookHls(o);return o;};
 try{W.prototype=H.prototype;Object.setPrototypeOf(W,H);W.__bt=1;}catch(e){return H;}
 return W;
}
trap('Hls',patchHls);

// ── 3) dash.js ──
function pickDash(p){
 try{if(p.__btDone)return;
  var reps=null,v5=false;
  try{reps=p.getRepresentationsByType&&p.getRepresentationsByType('video');v5=!!(reps&&reps.length);}catch(e){}
  if(!v5)try{reps=p.getBitrateInfoListFor('video')}catch(e){}
  if(!reps||!reps.length)return;
  var i=bestIdx(reps,function(r){return [r.height||0,r.bandwidth||r.bitrate||r.bitrateInKbit||0]});if(i<0)return;
  p.__btDone=1;
  try{p.updateSettings({streaming:{abr:{autoSwitchBitrate:{video:false}}}})}catch(e){}
  try{if(v5)p.setRepresentationForTypeByIndex('video',i,true);else p.setQualityFor('video',i,true);}catch(e){}
 }catch(e){}
}
function hookDash(p){
 try{p.updateSettings({streaming:{abr:{limitBitrateByPortal:false,initialBitrate:{video:BIG/1000}}}})}catch(e){}
 try{p.on('streamInitialized',function(){pickDash(p)});p.on('qualityChangeRendered',function(){pickDash(p)});}catch(e){}
}
function patchDash(d){
 try{if(!d||d.__bt||typeof d.MediaPlayer!=='function')return d;d.__bt=1;
  var MP=d.MediaPlayer;
  var W=function(){var f=MP.apply(this,arguments);try{var cr=f.create;f.create=function(){var p=cr.apply(this,arguments);hookDash(p);return p;};}catch(e){}return f;};
  for(var k in MP)try{W[k]=MP[k]}catch(e){}
  d.MediaPlayer=W;
 }catch(e){}
 return d;
}
trap('dashjs',patchDash);

// ── 4) Shaka Player ──
function pickShaka(p){
 try{var t=(p.getVariantTracks()||[]).filter(function(x){return x.height});if(!t.length)return;
  var i=bestIdx(t,function(x){return [x.height,x.bandwidth||0]});if(i<0)return;
  p.configure({abr:{enabled:false}});p.selectVariantTrack(t[i],true);
 }catch(e){}
}
function patchShaka(s){
 try{var P=s&&s.Player&&s.Player.prototype;if(!P||P.__bt)return s;P.__bt=1;
  var ld=P.load;
  P.load=function(){var self=this;
   try{self.configure({abr:{defaultBandwidthEstimate:BIG,restrictToElementSize:false,restrictToScreenSize:false}})}catch(e){}
   var r=ld.apply(this,arguments);try{Promise.resolve(r).then(function(){pickShaka(self)},function(){})}catch(e){}
   return r;};
 }catch(e){}
 return s;
}
trap('shaka',patchShaka);

// ── 5) video.js (VHS) ──
function pickVjs(p){
 try{if(!p||p.__btDone)return;
  var q=p.qualityLevels&&p.qualityLevels();
  if(q&&q.length){var arr=[];for(var j=0;j<q.length;j++)arr.push(q[j]);
   var i=bestIdx(arr,function(l){return [l.height||0,l.bitrate||0]});
   if(i>=0){p.__btDone=1;for(var j2=0;j2<arr.length;j2++)arr[j2].enabled=(j2===i);return;}}
  var t=p.tech&&p.tech({IWillNotUseThisInPlugins:true}),v=t&&(t.vhs||t.hls);
  var reps=v&&v.representations&&v.representations();
  if(reps&&reps.length){var k=bestIdx(reps,function(r){return [r.height||0,r.bandwidth||0]});
   if(k>=0){p.__btDone=1;for(var m=0;m<reps.length;m++)reps[m].enabled(m===k);}}
 }catch(e){}
}
function patchVjs(V){
 try{if(typeof V!=='function'||V.__bt)return V;V.__bt=1;
  var h5=V.options.html5=V.options.html5||{};
  var o=h5.vhs=h5.vhs||{};o.limitRenditionByPlayerDimensions=false;o.useDevicePixelRatio=true;o.bandwidth=BIG;o.useBandwidthFromLocalStorage=false;
  h5.hls=o;
  V.hook&&V.hook('setup',function(p){try{p.on('loadedmetadata',function(){setTimeout(function(){pickVjs(p)},200)})}catch(e){}});
 }catch(e){}
 return V;
}
trap('videojs',patchVjs);

// ── 6) JW Player ──
function pickJw(){
 try{if(typeof window.jwplayer!=='function')return;var j=window.jwplayer();if(!j||!j.getQualityLevels)return;
  if(!j.__btHook&&j.on){j.__btHook=1;j.on('levels',function(){j.__btDone=0;pickJw()});}
  if(j.__btDone)return;var ls=j.getQualityLevels()||[];if(ls.length<2)return;
  var i=bestIdx(ls,function(l){if(/auto/i.test(l.label||''))return null;return [l.height||qn(l.label),l.bitrate||0]});
  if(i>=0){j.__btDone=1;if(j.getCurrentQuality()!==i)j.setCurrentQuality(i);}
 }catch(e){}
}

// ── 7) YouTube ──
function ytPref(){
 try{var n=Date.now(),d=JSON.stringify({quality:CAP,previousQuality:CAP});
  localStorage.setItem('yt-player-quality',JSON.stringify({data:d,expiration:n+31536e6,creation:n}));}catch(e){}
}
function pickYt(){
 try{var p=document.getElementById('movie_player')||document.querySelector('.html5-video-player');
  if(!p||!p.getAvailableQualityLevels)return;var av=p.getAvailableQualityLevels()||[];if(!av.length)return;
  var map={highres:4320,hd2160:2160,hd1440:1440,hd1080:1080,hd720:720,large:480,medium:360,small:240,tiny:144};
  var i=bestIdx(av,function(q){return map[q]?[map[q],0]:null});if(i<0)return;var q=av[i];
  if(p.getPlaybackQuality&&p.getPlaybackQuality()===q)return;
  p.setPlaybackQualityRange&&p.setPlaybackQualityRange(q,q);p.setPlaybackQuality&&p.setPlaybackQuality(q);
 }catch(e){}
}
if(isYT){ytPref();document.addEventListener('yt-navigate-finish',function(){setTimeout(pickYt,800)});}

// ── 8) <video> ke andar kai <source> (360p/720p/1080p) → sabse achhi ──
function pickSource(v){
 try{if(v.__btSrc)return;var ss=v.querySelectorAll('source');if(ss.length<2)return;v.__btSrc=1;
  var arr=[],cur=v.currentSrc||v.src;
  for(var i=0;i<ss.length;i++){var s=ss[i];if(!s.src)continue;if(s.type&&v.canPlayType&&!v.canPlayType(s.type))continue;
   var q=Math.max(qn(s.getAttribute('size')),qn(s.getAttribute('res')),qn(s.getAttribute('label')),qn(s.getAttribute('data-res')),
     qn(s.getAttribute('data-quality')),qn(s.getAttribute('title')),qn(s.getAttribute('data-label')),qn(s.src));
   arr.push({s:s.src,q:q});}
  var b=bestIdx(arr,function(x){return x.q>0?[x.q,0]:null});if(b<0)return;
  var curQ=-1;for(var j=0;j<arr.length;j++)if(arr[j].s===cur)curQ=arr[j].q;
  if(curQ<0||arr[b].q<=curQ||arr[b].s===cur)return;
  var t=v.currentTime||0,pl=!v.paused;v.src=arr[b].s;
  if(t>0)v.addEventListener('loadedmetadata',function f(){v.removeEventListener('loadedmetadata',f);try{v.currentTime=t}catch(e){}});
  if(pl){var pr=v.play();pr&&pr.catch&&pr.catch(function(){});}
 }catch(e){}
}

// ── page me chhupe hls / player dhoondo (jo site ne apne code me bandh rakhe hain) ──
function check(o){
 try{if(!o||typeof o!=='object')return;
  if(Array.isArray(o.levels)&&('currentLevel' in o)&&('nextLevel' in o)){hookHls(o);pickHls(o);return;}
  if(typeof o.getBitrateInfoListFor==='function'||typeof o.getRepresentationsByType==='function'){pickDash(o);return;}
  if(typeof o.getVariantTracks==='function'&&typeof o.selectVariantTrack==='function'){pickShaka(o);return;}
 }catch(e){}
}
function scan(){
 try{if(window.shaka)patchShaka(window.shaka);}catch(e){}
 try{if(window.videojs&&window.videojs.getPlayers){var ps=window.videojs.getPlayers();for(var id in ps)pickVjs(ps[id]);}}catch(e){}
 pickJw();if(isYT)pickYt();
 var ks;try{ks=Object.keys(window)}catch(e){return}
 for(var i=0;i<ks.length&&i<3000;i++){var o;try{o=window[ks[i]]}catch(e){continue}
  if(!o||typeof o!=='object'||o===window||o===document)continue;check(o);
  try{check(o.hls);check(o.hlsjs);check(o.player);check(o._hls);check(o.dash);}catch(e){}}
}
var tmr=0;
function onVid(e){
 var v=e&&e.target;if(v&&v.tagName==='VIDEO')pickSource(v);
 clearTimeout(tmr);tmr=setTimeout(scan,350);setTimeout(scan,2500);
}
['loadedmetadata','playing','loadeddata'].forEach(function(n){document.addEventListener(n,onVid,true)});
if(document.readyState!=='loading')setTimeout(scan,500);
})();
