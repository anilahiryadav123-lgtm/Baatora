/* Baatora Video Gesture — video par ungli left/right khiskao to video aage/peeche ho jaye.
   Neeche ki patti (bottom strip) par khiskane se bareek control milta hai. */
(function(){
if(window.__btvg)return;window.__btvg=1;
var host=(location.hostname||'').toLowerCase();
var isYT=/(^|\.)youtube\.com$/.test(host);
var st=null,box=null,hideT=0,blockClick=0;

function fmt(s){s=Math.max(0,Math.floor(s||0));var h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;
 return (h?h+':'+(m<10?'0':''):'')+m+':'+(x<10?'0':'')+x;}
function ui(){
 if(!box){box=document.createElement('div');box.id='bt-vg';
  box.style.cssText='position:fixed;z-index:2147483647;left:50%;top:50%;transform:translate(-50%,-50%);pointer-events:none;'+
  'background:rgba(6,16,58,.82);color:#fff;font:700 15px/1.25 Roboto,system-ui,sans-serif;padding:12px 18px;border-radius:18px;'+
  'text-align:center;box-shadow:0 8px 24px rgba(0,0,0,.45);border:1.5px solid rgba(255,193,7,.6);display:none;min-width:150px';}
 var root=document.fullscreenElement||document.webkitFullscreenElement;
 var par=(root&&root.tagName!=='VIDEO')?root:(document.body||document.documentElement);
 if(box.parentNode!==par)par.appendChild(box);
 return box;
}
function show(r,html){var b=ui();b.innerHTML=html;b.style.display='block';
 if(r){b.style.left=(r.left+r.width/2)+'px';b.style.top=(r.top+r.height/2)+'px';}
 clearTimeout(hideT);}
function hide(d){clearTimeout(hideT);hideT=setTimeout(function(){if(box)box.style.display='none';},d||600);}
function bar(p){p=Math.max(0,Math.min(1,p));
 return '<div style="margin-top:8px;height:5px;border-radius:3px;background:rgba(255,255,255,.25);overflow:hidden">'+
  '<div style="height:100%;width:'+(p*100).toFixed(1)+'%;background:linear-gradient(90deg,#FF8A00,#FFC107)"></div></div>';}

function videoAt(x,y){
 var vs=document.querySelectorAll('video'),best=null,area=0;
 for(var i=0;i<vs.length;i++){var r=vs[i].getBoundingClientRect();
  if(r.width<100||r.height<60)continue;
  if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom){var a=r.width*r.height;if(a>area){area=a;best=vs[i];}}}
 return best;
}
function seek(v,t){
 if(!isFinite(t))return;
 if(isFinite(v.duration)&&v.duration>0)t=Math.max(0,Math.min(v.duration-0.5,t));else t=Math.max(0,t);
 try{var mp=document.getElementById('movie_player');
  if(isYT&&mp&&typeof mp.seekTo==='function'){mp.seekTo(t,true);return;}}catch(e){}
 try{v.currentTime=t;}catch(e){}
}
function isControl(el){
 try{return !!(el&&el.closest&&el.closest('input,textarea,select,[role=slider],.ytp-progress-bar,.ytm-progress-bar,ytm-progress-bar,.progress-bar,[class*=progress-bar]'));}catch(e){return false;}
}

document.addEventListener('touchstart',function(e){
 st=null;
 if(e.touches.length!==1)return;
 var t=e.touches[0],v=videoAt(t.clientX,t.clientY);
 if(!v||isControl(e.target))return;
 var r=v.getBoundingClientRect();
 var dur=v.duration;
 if(!isFinite(dur)||dur<=0)return; /* live stream: seek nahi */
 var bottom=(t.clientY>r.bottom-r.height*0.28); /* neeche ki patti = bareek control */
 st={v:v,x:t.clientX,y:t.clientY,r:r,t0:v.currentTime,dur:dur,on:false,bottom:bottom,target:v.currentTime};
},{capture:true,passive:true});

document.addEventListener('touchmove',function(e){
 if(!st||e.touches.length!==1)return;
 var t=e.touches[0],dx=t.clientX-st.x,dy=t.clientY-st.y;
 if(!st.on){
  if(Math.abs(dx)>22&&Math.abs(dx)>Math.abs(dy)*1.4){st.on=true;st.x=t.clientX;dx=0;}
  else if(Math.abs(dy)>22){st=null;return;}
  else return;
 }
 e.preventDefault();e.stopPropagation();
 /* poori chaudai khiskane par: neeche ki patti = poora video, baaki jagah = 2 minute tak */
 var span=st.bottom?st.dur:Math.min(st.dur,Math.max(60,Math.min(180,st.dur/3)));
 var delta=dx/Math.max(200,st.r.width)*span;
 st.target=Math.max(0,Math.min(st.dur-0.5,st.t0+delta));
 var d=st.target-st.t0,sign=d>=0?'+':'-';
 show(st.r,'<div style="font-size:22px">'+(d>=0?'\u23E9':'\u23EA')+' '+sign+fmt(Math.abs(d))+'</div>'+
  '<div style="font-size:13px;opacity:.9;margin-top:4px">'+fmt(st.target)+' / '+fmt(st.dur)+'</div>'+bar(st.target/st.dur));
},{capture:true,passive:false});

function end(e){
 if(!st)return;
 if(st.on){
  try{e.preventDefault();e.stopPropagation();}catch(x){}
  seek(st.v,st.target);
  blockClick=Date.now();
  hide(700);
 }
 st=null;
}
document.addEventListener('touchend',end,{capture:true,passive:false});
document.addEventListener('touchcancel',function(){if(st&&st.on)hide(300);st=null;},{capture:true,passive:true});
document.addEventListener('click',function(e){if(Date.now()-blockClick<450){e.preventDefault();e.stopPropagation();}},true);

/* YouTube ke alawa: double-tap left = 10 sec peeche, right = 10 sec aage */
if(!isYT){
 var lastTap=0,lastX=0;
 document.addEventListener('touchend',function(e){
  if(e.changedTouches.length!==1)return;
  var t=e.changedTouches[0],v=videoAt(t.clientX,t.clientY);if(!v||isControl(e.target))return;
  var now=Date.now();
  if(now-lastTap<300&&Math.abs(t.clientX-lastX)<60){
   var r=v.getBoundingClientRect(),rel=(t.clientX-r.left)/r.width;
   if(rel<0.35||rel>0.65){var fw=rel>0.5;seek(v,v.currentTime+(fw?10:-10));
    show(r,'<div style="font-size:22px">'+(fw?'\u23E9 +10s':'\u23EA -10s')+'</div>');hide(600);blockClick=now;lastTap=0;return;}
  }
  lastTap=now;lastX=t.clientX;
 },{capture:true,passive:true});
}

/* Video chal raha hai ya nahi — Baatora ko batao (Home dabane par chhota video / PiP) */
var lastSent='';
function report(){try{
 var vs=document.querySelectorAll('video'),pl=null;
 for(var i=0;i<vs.length;i++){var v=vs[i];if(!v.paused&&!v.ended&&v.readyState>1&&v.videoWidth>0){pl=v;break;}}
 var k=pl?('1:'+pl.videoWidth+'x'+pl.videoHeight):'0';
 if(k===lastSent)return;lastSent=k;
 if(window.BaatoraCfg&&BaatoraCfg.video)BaatoraCfg.video(!!pl,pl?pl.videoWidth:0,pl?pl.videoHeight:0);
}catch(e){}}
['play','playing','pause','ended','emptied','loadedmetadata'].forEach(function(t){document.addEventListener(t,function(){setTimeout(report,50);},true);});
window.addEventListener('pagehide',function(){try{if(window.BaatoraCfg&&BaatoraCfg.video)BaatoraCfg.video(false,0,0);}catch(e){}});
})();
