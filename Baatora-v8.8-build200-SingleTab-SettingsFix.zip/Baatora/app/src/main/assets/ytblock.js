/* Baatora YouTube Ad Block — page ke shuru me hi chalta hai.
   YouTube ke player data se ads ki jaankari hata deta hai, isliye ad load hi nahi hota. */
(function(){
if(window.__btyt)return;window.__btyt=1;
try{if(window.BaatoraCfg&&!BaatoraCfg.ad())return;}catch(e){}

var removed=0,repT=0;
function report(){if(!removed||repT)return;repT=setTimeout(function(){try{if(window.BaatoraCfg)BaatoraCfg.blocked(removed);}catch(e){}removed=0;repT=0;},1500);}
/* Note: video (player) ke data ko nahi chhedte — warna YouTube video ghoomta rehta hai (loading).
   Sirf home/search/related list se ad cards hatate hain, aur video ke ad ko turant skip karte hain. */
var AD_ITEM=/^(adSlotRenderer|promotedSparklesWebRenderer|promotedSparklesTextSearchRenderer|promotedVideoRenderer|compactPromotedVideoRenderer|displayAdRenderer|searchPyvRenderer|inFeedAdLayoutRenderer|bannerPromoRenderer|statementBannerRenderer|brandVideoSingletonRenderer|brandVideoShelfRenderer|primetimePromoRenderer|mealbarPromoRenderer|textAdRenderer|carouselAdRenderer|movingThumbnailAdRenderer)$/;
function isAdItem(x){
 if(!x||typeof x!=='object'||Array.isArray(x))return false;
 for(var k in x){
  if(AD_ITEM.test(k))return true;
  if(k==='richItemRenderer'||k==='itemSectionRenderer'||k==='richSectionRenderer'){
   var c=x[k]&&(x[k].content||(x[k].contents&&x[k].contents.length===1&&x[k].contents[0]));
   if(c&&typeof c==='object')for(var j in c)if(AD_ITEM.test(j))return true;
  }
 }
 return false;
}
function strip(o,depth){
 if(!o||typeof o!=='object'||depth>30)return;
 if(o.streamingData||o.playerConfig||o.videoDetails)return; /* player data: haath nahi lagana */
 if(Array.isArray(o)){
  for(var i=o.length-1;i>=0;i--){if(isAdItem(o[i])){o.splice(i,1);removed++;}else strip(o[i],depth+1);}
  return;
 }
 for(var k in o){if(k==='playerResponse')continue;var v=o[k];if(v&&typeof v==='object')strip(v,depth+1);}
}
function clean(o){try{if(o&&typeof o==='object'&&!o.streamingData){strip(o,0);report();}}catch(e){}return o;}

/* Player ke data se SIRF ad ki list hatao (uBlock jaisa halka tareeka).
   Agar isse video atke, to app apne aap ise band karke page dobara khol deti hai. */
var NOPRUNE=false;try{NOPRUNE=sessionStorage.getItem('bt_noprune')==='1';}catch(e){}
var PKEYS=['adPlacements','playerAds','adSlots'];
function pprune(o){
 try{if(NOPRUNE||!o||typeof o!=='object')return o;
  var t=[o];if(o.playerResponse&&typeof o.playerResponse==='object')t.push(o.playerResponse);
  for(var i=0;i<t.length;i++)for(var k=0;k<PKEYS.length;k++)if(PKEYS[k] in t[i]){delete t[i][PKEYS[k]];removed++;}
  report();
 }catch(e){}
 return o;
}
/* Pehle video (page ke andar likha data) ko nahi chhedte — warna pehla video atakta tha */
try{var rj0=Response.prototype.json;
 Response.prototype.json=function(){var u=this.url||'';return rj0.apply(this,arguments).then(function(o){return /\/youtubei\/v1\/(player|next)/.test(u)?pprune(o):o;});};}catch(e){}

/* list wala data (home / search / related) */
try{
 var jp=JSON.parse;
 JSON.parse=function(){var r=jp.apply(this,arguments);
  try{var s0=arguments[0];if(typeof s0==='string'&&s0.length>500&&/"(adPlacements|playerAds|adSlots)"/.test(s0))pprune(r);}catch(e){}
  try{var s=arguments[0];if(typeof s==='string'&&s.length>500&&!/"streamingData"/.test(s)&&/"(adSlotRenderer|promotedSparklesWebRenderer|displayAdRenderer|inFeedAdLayoutRenderer|promotedVideoRenderer|compactPromotedVideoRenderer)"/.test(s))clean(r);}catch(e){}
  return r;};
}catch(e){}
try{var val;Object.defineProperty(window,'ytInitialData',{configurable:true,get:function(){return val;},set:function(v){val=clean(v);}});}catch(e){}

/* 5) Bache hue ad dabbe CSS se chhupao */
var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,'+
'ad-slot-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytm-promoted-sparkles-text-search-renderer,'+
'ytm-statement-banner-renderer,ytd-statement-banner-renderer,ytm-paid-content-overlay-renderer,ytm-mealbar-promo-renderer,'+
'ytm-companion-slot,ytm-display-ad-renderer,ytm-in-feed-ad-layout-renderer,ytm-brand-video-singleton-renderer,ytm-search-pyv-renderer,'+
'ytm-rich-item-renderer:has(ytm-ad-slot-renderer),ytm-rich-item-renderer:has(ad-slot-renderer),ytm-item-section-renderer:has(ytm-ad-slot-renderer),'+
'ytm-rich-section-renderer:has(ytm-statement-banner-renderer),ytd-rich-item-renderer:has(ytd-ad-slot-renderer),'+
'ytm-reel-shelf-renderer:has(ad-slot-renderer),ytm-merch-shelf-renderer,ytm-product-list-item-renderer,'+
'.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-module .ytp-ad-overlay-slot,#player-ads,#masthead-ad,'+
'.ytm-promoted-sparkles-web-renderer,.video-ads .ytp-ad-overlay-slot,ytm-engagement-panel-section-list-renderer[target-id*=ads],'+
'#tads,#tadsb,#bottomads,[data-text-ad],.commercial-unit-mobile-top,.uEierd,.ytp-ad-player-overlay,.ytp-ad-player-overlay-layout,'+
'.ytp-ad-text,.ytp-ad-preview-container,.ytp-ad-visit-advertiser-button,.ytm-ad-overlay,ytm-companion-ad-renderer{display:none!important}'+
'.ad-showing video,.ad-interrupting video{opacity:0!important}'+
''
function addCss(){try{if(document.getElementById('bt-ytcss'))return;var s=document.createElement('style');s.id='bt-ytcss';s.textContent=css;
 (document.head||document.documentElement).appendChild(s);}catch(e){}}
addCss();document.addEventListener('DOMContentLoaded',addCss);

/* 6) Ad aaye to: awaaz band, thoda tez, "Skip" aate hi dabao.
   Seedha end par kudane (seek) se ya bahut tez chalane se pehla video atak jaata tha — isliye ab nahi karte. */
var muted=false,lastT=-1,stuckAt=0,slow=false,adStart=0;
setInterval(function(){try{
 var p=document.querySelector('.ad-showing,.ad-interrupting');
 var v=document.querySelector('.html5-video-player video,video');
 if(p&&v){
  if(!muted){removed++;report();muted=true;slow=false;lastT=-1;stuckAt=Date.now();adStart=Date.now();}
  if(Date.now()-adStart>20000){adStart=Date.now()+1e9;try{var k='bt_adrl_'+(location.search||'');if(!sessionStorage.getItem(k)){sessionStorage.setItem(k,'1');location.reload();}}catch(e){}}
  v.muted=true;
  /* atak gaya? to speed normal karke chalao */
  if(Math.abs(v.currentTime-lastT)>0.05){lastT=v.currentTime;stuckAt=Date.now();}
  else if(Date.now()-stuckAt>1500){slow=true;try{v.playbackRate=1;}catch(e){}if(v.paused){try{v.play();}catch(e){}}stuckAt=Date.now();}
  if(!slow){try{var ahead=0;for(var i=0;i<v.buffered.length;i++)if(v.buffered.start(i)<=v.currentTime&&v.buffered.end(i)>v.currentTime)ahead=v.buffered.end(i)-v.currentTime;
   v.playbackRate=ahead>3?4:2;}catch(e){}}
  var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-slot button,'+
   '.ytm-skip-ad-button,button[class*=skip-ad],button[class*=skip_ad],.ytp-ad-skip-button-container button');
  if(b){try{b.click();}catch(e){}}
 }else if(muted&&v){muted=false;v.muted=false;try{v.playbackRate=1;}catch(e){}if(v.paused){try{v.play();}catch(e){}}}
 var c=document.querySelector('.ytp-ad-overlay-close-button');if(c)c.click();
 var cw=document.querySelector('ytm-dialog-renderer .yt-spec-button-shape-next, yt-confirm-dialog-renderer #confirm-button');
 if(cw&&/continue|jaari|haan|yes/i.test(cw.textContent||''))cw.click();
}catch(e){}},250);

/* 7) Atke video ka ilaaj (har video ke liye): 3 sec par dobara "play", 6 sec par page dobara kholo (ek baar) */
var wUrl='',wAt=0,wOk=false,wKick=false;
setInterval(function(){try{
 if(!/\/(watch|shorts)/.test(location.pathname))return;
 if(location.href!==wUrl){wUrl=location.href;wAt=Date.now();wOk=false;wKick=false;return;}
 if(wOk||document.visibilityState!=='visible'||document.querySelector('.ad-showing,.ad-interrupting')){if(document.querySelector('.ad-showing'))wAt=Date.now();return;}
 var v=document.querySelector('.html5-video-player video,video');
 if(v&&v.currentTime>0.5&&!v.paused){wOk=true;return;}
 if(v&&v.paused&&v.readyState>=3&&v.currentTime>0.5){wOk=true;return;} /* user ne roka */
 var age=Date.now()-wAt;
 if(age>3000&&!wKick){wKick=true;
  try{var mp=document.getElementById('movie_player');if(mp&&mp.playVideo)mp.playVideo();}catch(e){}
  try{if(v){v.muted=false;v.play();}}catch(e){}
 }
 if(age>6500){
  wOk=true;
  var key='bt_rl_'+(location.search||'');
  try{if(sessionStorage.getItem(key))return;sessionStorage.setItem(key,'1');sessionStorage.setItem('bt_noprune','1');}catch(e){}
  location.reload();
 }
}catch(e){}},600);

/* Naya video khule to turant chalu ho (rukna na pade) */
var lastSrc='',srcAt=0,nudged=false;
setInterval(function(){try{
 if(!/\/(watch|shorts)/.test(location.pathname))return;
 var v=document.querySelector('.html5-video-player video,video');if(!v)return;
 var src=v.currentSrc||v.src||'';
 if(src!==lastSrc){lastSrc=src;srcAt=Date.now();nudged=false;}
 if(nudged||document.querySelector('.ad-showing'))return;
 var age=Date.now()-srcAt;
 if(age>1200&&age<8000&&v.paused&&v.currentTime<1&&v.readyState>=2){
  nudged=true;
  try{var mp=document.getElementById('movie_player');if(mp&&mp.playVideo)mp.playVideo();else v.play();}catch(e){try{v.play();}catch(x){}}
 }
}catch(e){}},500);
})();
