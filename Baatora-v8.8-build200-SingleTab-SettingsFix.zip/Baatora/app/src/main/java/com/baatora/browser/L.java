package com.baatora.browser;

import java.util.HashMap;

/**
 * Baatora ki bhashayein.
 * Kram: Hinglish, हिन्दी, English, भोजपुरी, मराठी, বাংলা, ਪੰਜਾਬੀ
 */
final class L {

    static final String[] KEYS = {"hinglish", "hindi", "english", "bhojpuri", "marathi", "bengali", "punjabi"};
    static final String[] NATIVE = {"Hinglish", "हिन्दी", "English", "भोजपुरी", "मराठी", "বাংলা", "ਪੰਜਾਬੀ"};
    static final String[] SUB = {"Roman Hindi", "Hindi", "Default ✓", "Bhojpuri", "Marathi", "Bengali", "Punjabi"};
    static final String[] BADGE = {"Aa", "अ", "A", "भो", "म", "অ", "ਪ"};

    static int idx = 0;
    private static final HashMap<String, String[]> M = new HashMap<>();

    private L() {}

    static void set(String key) {
        idx = 0;
        for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(key)) idx = i;
    }

    static String key() { return KEYS[idx]; }

    static String t(String k) {
        String[] v = M.get(k);
        if (v == null) return k;
        return idx < v.length ? v[idx] : v[0];
    }

    private static void p(String k, String... v) { M.put(k, v); }

    static {
        p("new_tab", "Naya Tab", "नया टैब", "New Tab", "नया टैब", "नवीन टॅब", "নতুন ট্যাব", "ਨਵੀਂ ਟੈਬ");
        p("incognito", "Incognito", "गुप्त टैब", "Incognito", "गुपचुप टैब", "गुप्त टॅब", "গোপন ট্যাব", "ਗੁਪਤ ਟੈਬ");
        p("bookmarks", "Bookmarks", "बुकमार्क", "Bookmarks", "बुकमार्क", "बुकमार्क", "বুকমার্ক", "ਬੁੱਕਮਾਰਕ");
        p("add_bookmark", "Bookmark karein", "बुकमार्क करें", "Add bookmark", "बुकमार्क करीं", "बुकमार्क करा", "বুকমার্ক করুন", "ਬੁੱਕਮਾਰਕ ਕਰੋ");
        p("history", "History", "इतिहास", "History", "इतिहास", "इतिहास", "ইতিহাস", "ਇਤਿਹਾਸ");
        p("downloads", "Downloads", "डाउनलोड", "Downloads", "डाउनलोड", "डाउनलोड", "ডাউনলোড", "ਡਾਊਨਲੋਡ");
        p("video_dl", "Video download", "वीडियो डाउनलोड", "Video download", "वीडियो डाउनलोड", "व्हिडिओ डाउनलोड", "ভিডিও ডাউনলোড", "ਵੀਡੀਓ ਡਾਊਨਲੋਡ");
        p("find", "Page me khojein", "पेज में खोजें", "Find in page", "पेज में खोजीं", "पानावर शोधा", "পেজে খুঁজুন", "ਪੰਨੇ ਵਿੱਚ ਲੱਭੋ");
        p("share", "Share", "शेयर करें", "Share", "शेयर करीं", "शेअर करा", "শেয়ার", "ਸ਼ੇਅਰ");
        p("copy_link", "Link copy", "लिंक कॉपी", "Copy link", "लिंक कॉपी", "लिंक कॉपी", "লিংক কপি", "ਲਿੰਕ ਕਾਪੀ");
        p("desktop", "Desktop site", "डेस्कटॉप साइट", "Desktop site", "डेस्कटॉप साइट", "डेस्कटॉप साइट", "ডেস্কটপ সাইট", "ਡੈਸਕਟਾਪ ਸਾਈਟ");
        p("night", "Night mode", "नाइट मोड", "Night mode", "रात वाला मोड", "नाईट मोड", "নাইট মোড", "ਨਾਈਟ ਮੋਡ");
        p("datasaver", "Data Saver", "डेटा बचत", "Data Saver", "डेटा बचाईं", "डेटा बचत", "ডেটা সেভার", "ਡਾਟਾ ਬਚਤ");
        p("pull", "Pull refresh", "खींचकर रिफ्रेश", "Pull to refresh", "खींच के रिफ्रेश", "ओढून रिफ्रेश", "টেনে রিফ্রেশ", "ਖਿੱਚ ਕੇ ਰਿਫ੍ਰੈਸ਼");
        p("settings", "Settings", "सेटिंग्स", "Settings", "सेटिंग", "सेटिंग्ज", "সেটিংস", "ਸੈਟਿੰਗਾਂ");
        p("textsize", "Text size", "अक्षर का आकार", "Text size", "अक्षर के साइज", "अक्षरांचा आकार", "লেখার আকার", "ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ");
        p("pdf", "PDF save", "PDF सेव करें", "Save as PDF", "PDF सेव करीं", "PDF सेव्ह करा", "PDF সেভ", "PDF ਸੇਵ");
        p("fullscreen", "Full screen", "फुल स्क्रीन", "Full screen", "फुल स्क्रीन", "फुल स्क्रीन", "ফুল স্ক্রিন", "ਫੁੱਲ ਸਕਰੀਨ");
        p("clear", "Data clear", "डेटा साफ़ करें", "Clear data", "डेटा साफ करीं", "डेटा साफ करा", "ডেটা মুছুন", "ਡਾਟਾ ਸਾਫ਼ ਕਰੋ");
        p("about", "About", "हमारे बारे में", "About", "हमनी के बारे में", "माहिती", "সম্পর্কে", "ਬਾਰੇ");
        p("exit", "Exit", "बाहर निकलें", "Exit", "बाहर निकलीं", "बाहेर पडा", "বেরিয়ে যান", "ਬਾਹਰ ਨਿਕਲੋ");

        p("theme", "Theme", "थीम", "Theme", "थीम", "थीम", "থিম", "ਥੀਮ");
        p("theme_sub", "Browser ka rang badlein", "ब्राउज़र का रंग बदलें", "Change browser colours", "ब्राउज़र के रंग बदलीं", "ब्राउझरचा रंग बदला", "ব্রাউজারের রং বদলান", "ਬ੍ਰਾਊਜ਼ਰ ਦਾ ਰੰਗ ਬਦਲੋ");
        p("language", "Bhasha (Language)", "भाषा", "Language", "भाषा", "भाषा", "ভাষা", "ਭਾਸ਼ਾ");
        p("choose_theme", "Theme chunein", "थीम चुनें", "Choose theme", "थीम चुनीं", "थीम निवडा", "থিম বেছে নিন", "ਥੀਮ ਚੁਣੋ");
        p("choose_lang", "Bhasha chunein", "भाषा चुनें", "Choose language", "भाषा चुनीं", "भाषा निवडा", "ভাষা বেছে নিন", "ਭਾਸ਼ਾ ਚੁਣੋ");
        p("s_look", "Dikhawat", "दिखावट", "Appearance", "रूप-रंग", "दिसणे", "চেহারা", "ਦਿੱਖ");
        p("s_browsing", "Browsing", "ब्राउज़िंग", "Browsing", "ब्राउज़िंग", "ब्राउझिंग", "ব্রাউজিং", "ਬ੍ਰਾਊਜ਼ਿੰਗ");
        p("s_privacy", "Privacy aur Suraksha", "गोपनीयता और सुरक्षा", "Privacy & Security", "गोपनीयता आ सुरक्षा", "गोपनीयता आणि सुरक्षा", "গোপনীয়তা ও নিরাপত্তা", "ਪਰਦੇਦਾਰੀ ਅਤੇ ਸੁਰੱਖਿਆ");
        p("s_info", "Jaankari", "जानकारी", "Information", "जानकारी", "माहिती", "তথ্য", "ਜਾਣਕਾਰੀ");
        p("bar_bottom", "Address bar neeche", "एड्रेस बार नीचे", "Address bar at bottom", "एड्रेस बार नीचे", "ॲड्रेस बार खाली", "অ্যাড্রেস বার নিচে", "ਐਡਰੈੱਸ ਬਾਰ ਹੇਠਾਂ");
        p("bar_bottom_sub", "Search bar neeche aa jayega", "सर्च बार नीचे आ जाएगा", "Search bar moves to the bottom", "सर्च बार नीचे आ जाई", "सर्च बार खाली येईल", "সার্চ বার নিচে চলে যাবে", "ਸਰਚ ਬਾਰ ਹੇਠਾਂ ਆ ਜਾਵੇਗੀ");
        p("night_sub", "Websites ko dark me dikhaye", "वेबसाइट को डार्क में दिखाए", "Show websites in dark", "वेबसाइट के अन्हार में देखाईं", "वेबसाइट डार्कमध्ये दाखवा", "ওয়েবসাইট ডার্কে দেখান", "ਵੈੱਬਸਾਈਟਾਂ ਡਾਰਕ ਵਿੱਚ ਦਿਖਾਓ");
        p("engine", "Search engine", "सर्च इंजन", "Search engine", "सर्च इंजन", "सर्च इंजिन", "সার্চ ইঞ্জিন", "ਸਰਚ ਇੰਜਣ");
        p("desktop_sub", "Computer jaisi website", "कंप्यूटर जैसी वेबसाइट", "Computer-style websites", "कंप्यूटर जइसन वेबसाइट", "संगणकासारखी वेबसाइट", "কম্পিউটারের মতো ওয়েবসাইট", "ਕੰਪਿਊਟਰ ਵਰਗੀ ਵੈੱਬਸਾਈਟ");
        p("datasaver_sub", "Images band karke data bachaye", "तस्वीरें बंद कर डेटा बचाए", "Save data by hiding images", "फोटो बंद क के डेटा बचाईं", "फोटो बंद करून डेटा वाचवा", "ছবি বন্ধ রেখে ডেটা বাঁচান", "ਤਸਵੀਰਾਂ ਬੰਦ ਕਰਕੇ ਡਾਟਾ ਬਚਾਓ");
        p("pull_sub", "Neeche kheenchkar refresh", "नीचे खींचकर रिफ्रेश", "Pull down to refresh", "नीचे खींच के रिफ्रेश", "खाली ओढून रिफ्रेश", "নিচে টেনে রিফ্রেশ", "ਹੇਠਾਂ ਖਿੱਚ ਕੇ ਰਿਫ੍ਰੈਸ਼");
        p("clear_sub", "Cache, cookies aur history saaf", "कैश, कुकीज़ और इतिहास साफ़", "Clear cache, cookies & history", "कैश, कुकीज़ आ इतिहास साफ", "कॅशे, कुकीज व इतिहास साफ", "ক্যাশ, কুকি ও ইতিহাস মুছুন", "ਕੈਸ਼, ਕੁਕੀਜ਼ ਤੇ ਇਤਿਹਾਸ ਸਾਫ਼");

        p("cancel", "Cancel", "रद्द करें", "Cancel", "रहे दीं", "रद्द करा", "বাতিল", "ਰੱਦ ਕਰੋ");
        p("clear_btn", "Saaf karein", "साफ़ करें", "Clear", "साफ करीं", "साफ करा", "মুছুন", "ਸਾਫ਼ ਕਰੋ");
        p("delete", "Delete", "हटाएं", "Delete", "हटाईं", "हटवा", "মুছুন", "ਹਟਾਓ");
        p("clear_hist_t", "History saaf karein?", "इतिहास साफ़ करें?", "Clear history?", "इतिहास साफ करीं?", "इतिहास साफ करायचा?", "ইতিহাস মুছবেন?", "ਇਤਿਹਾਸ ਸਾਫ਼ ਕਰਨਾ ਹੈ?");
        p("clear_hist_m", "Saari history hamesha ke liye hat jayegi.", "सारा इतिहास हमेशा के लिए हट जाएगा।", "All history will be removed permanently.", "सगरी इतिहास हमेशा खातिर हट जाई।", "सगळा इतिहास कायमचा हटवला जाईल.", "সব ইতিহাস চিরতরে মুছে যাবে।", "ਸਾਰਾ ਇਤਿਹਾਸ ਹਮੇਸ਼ਾ ਲਈ ਹਟ ਜਾਵੇਗਾ।");
        p("clear_bm_t", "Bookmarks hatayein?", "बुकमार्क हटाएं?", "Remove bookmarks?", "बुकमार्क हटाईं?", "बुकमार्क हटवायचे?", "বুকমার্ক মুছবেন?", "ਬੁੱਕਮਾਰਕ ਹਟਾਉਣੇ ਹਨ?");
        p("clear_bm_m", "Saare bookmarks hamesha ke liye hat jayenge.", "सारे बुकमार्क हमेशा के लिए हट जाएंगे।", "All bookmarks will be removed permanently.", "सगरी बुकमार्क हमेशा खातिर हट जाई।", "सगळे बुकमार्क कायमचे हटवले जातील.", "সব বুকমার্ক চিরতরে মুছে যাবে।", "ਸਾਰੇ ਬੁੱਕਮਾਰਕ ਹਮੇਸ਼ਾ ਲਈ ਹਟ ਜਾਣਗੇ।");
        p("search_hist", "History me khojein", "इतिहास में खोजें", "Search history", "इतिहास में खोजीं", "इतिहासात शोधा", "ইতিহাসে খুঁজুন", "ਇਤਿਹਾਸ ਵਿੱਚ ਲੱਭੋ");
        p("search_bm", "Bookmarks me khojein", "बुकमार्क में खोजें", "Search bookmarks", "बुकमार्क में खोजीं", "बुकमार्कमध्ये शोधा", "বুকমার্কে খুঁজুন", "ਬੁੱਕਮਾਰਕ ਵਿੱਚ ਲੱਭੋ");
        p("search_tabs", "Tabs khojein", "टैब खोजें", "Search tabs", "टैब खोजीं", "टॅब शोधा", "ট্যাব খুঁজুন", "ਟੈਬਾਂ ਲੱਭੋ");
        p("tabs_hint", "👉  Tab band karne ke liye side me swipe karein", "👉  टैब बंद करने के लिए साइड में स्वाइप करें", "👉  Swipe sideways to close a tab", "👉  टैब बंद करे खातिर साइड में स्वाइप करीं", "👉  टॅब बंद करण्यासाठी बाजूला स्वाइप करा", "👉  ট্যাব বন্ধ করতে পাশে সোয়াইপ করুন", "👉  ਟੈਬ ਬੰਦ ਕਰਨ ਲਈ ਪਾਸੇ ਸਵਾਈਪ ਕਰੋ");
        p("empty_hist", "Abhi koi history nahi", "अभी कोई इतिहास नहीं", "No history yet", "अबहीं कवनो इतिहास नइखे", "अजून इतिहास नाही", "এখনও কোনো ইতিহাস নেই", "ਹਾਲੇ ਕੋਈ ਇਤਿਹਾਸ ਨਹੀਂ");
        p("empty_bm", "Abhi koi bookmark nahi", "अभी कोई बुकमार्क नहीं", "No bookmarks yet", "अबहीं कवनो बुकमार्क नइखे", "अजून बुकमार्क नाही", "এখনও কোনো বুকমার্ক নেই", "ਹਾਲੇ ਕੋਈ ਬੁੱਕਮਾਰਕ ਨਹੀਂ");
        p("not_found", "Kuch nahi mila", "कुछ नहीं मिला", "Nothing found", "कुछुओ ना मिलल", "काहीच सापडले नाही", "কিছু পাওয়া যায়নি", "ਕੁਝ ਨਹੀਂ ਮਿਲਿਆ");
        p("url_hint", "Search ya URL likhein", "खोजें या URL लिखें", "Search or type URL", "खोजीं भा URL लिखीं", "शोधा किंवा URL लिहा", "খুঁজুন বা URL লিখুন", "ਲੱਭੋ ਜਾਂ URL ਲਿਖੋ");
        p("all", "Sab", "सब", "All", "सब", "सर्व", "সব", "ਸਭ");

        p("tagline", "Tez. Surakshit. Apna Browser.", "तेज़। सुरक्षित। अपना ब्राउज़र।", "Fast. Safe. Your own browser.", "तेज। सुरक्षित। आपन ब्राउज़र।", "वेगवान. सुरक्षित. आपला ब्राउझर.", "দ্রুত। নিরাপদ। নিজের ব্রাউজার।", "ਤੇਜ਼। ਸੁਰੱਖਿਅਤ। ਆਪਣਾ ਬ੍ਰਾਊਜ਼ਰ।");
        p("home_search", "Khojein ya website likhein", "खोजें या वेबसाइट लिखें", "Search or enter website", "खोजीं भा वेबसाइट लिखीं", "शोधा किंवा वेबसाइट लिहा", "খুঁজুন বা ওয়েবসাইট লিখুন", "ਲੱਭੋ ਜਾਂ ਵੈੱਬਸਾਈਟ ਲਿਖੋ");
        p("quick", "⚡ Quick Access", "⚡ झटपट पहुँच", "⚡ Quick Access", "⚡ झटपट पहुँच", "⚡ झटपट प्रवेश", "⚡ দ্রুত অ্যাক্সেস", "⚡ ਝਟਪਟ ਪਹੁੰਚ");
        p("trending", "🔥 Trending", "🔥 ट्रेंडिंग", "🔥 Trending", "🔥 ट्रेंडिंग", "🔥 ट्रेंडिंग", "🔥 ট্রেন্ডিং", "🔥 ਟ੍ਰੈਂਡਿੰਗ");
        p("gm", "Suprabhat 🌅", "सुप्रभात 🌅", "Good morning 🌅", "सुप्रभात 🌅", "सुप्रभात 🌅", "সুপ্রভাত 🌅", "ਸ਼ੁਭ ਸਵੇਰ 🌅");
        p("gd", "Namaste ☀️", "नमस्ते ☀️", "Good afternoon ☀️", "प्रणाम ☀️", "नमस्कार ☀️", "নমস্কার ☀️", "ਸਤ ਸ੍ਰੀ ਅਕਾਲ ☀️");
        p("ge", "Shubh Sandhya 🌇", "शुभ संध्या 🌇", "Good evening 🌇", "शुभ साँझ 🌇", "शुभ संध्याकाळ 🌇", "শুভ সন্ধ্যা 🌇", "ਸ਼ੁਭ ਸ਼ਾਮ 🌇");
        p("gn", "Shubh Ratri 🌙", "शुभ रात्रि 🌙", "Good night 🌙", "शुभ रात 🌙", "शुभ रात्री 🌙", "শুভ রাত্রি 🌙", "ਸ਼ੁਭ ਰਾਤ 🌙");
        p("add", "Jodein", "जोड़ें", "Add", "जोड़ीं", "जोडा", "যোগ করুন", "ਜੋੜੋ");
        p("edit", "Edit", "बदलें", "Edit", "बदलीं", "बदला", "এডিট", "ਬਦਲੋ");
        p("done", "Ho gaya ✓", "हो गया ✓", "Done ✓", "हो गइल ✓", "झाले ✓", "হয়ে গেছে ✓", "ਹੋ ਗਿਆ ✓");
        p("created", "Created by", "निर्माता", "Created by", "बनावे वाला", "निर्माता", "নির্মাতা", "ਨਿਰਮਾਤਾ");
        p("incog_note", "🕶 Aap Incognito tab me hain — history save nahi hogi.", "🕶 आप गुप्त टैब में हैं — इतिहास सेव नहीं होगा।", "🕶 You're in an incognito tab — history won't be saved.", "🕶 रउआ गुपचुप टैब में बानी — इतिहास सेव ना होई।", "🕶 तुम्ही गुप्त टॅबमध्ये आहात — इतिहास सेव्ह होणार नाही.", "🕶 আপনি গোপন ট্যাবে আছেন — ইতিহাস সেভ হবে না।", "🕶 ਤੁਸੀਂ ਗੁਪਤ ਟੈਬ ਵਿੱਚ ਹੋ — ਇਤਿਹਾਸ ਸੇਵ ਨਹੀਂ ਹੋਵੇਗਾ।");

        p("sign_in", "Sign in", "साइन इन", "Sign in", "साइन इन", "साइन इन", "সাইন ইন", "ਸਾਈਨ ਇਨ");
        p("sign_up", "Sign up", "साइन अप", "Sign up", "साइन अप", "साइन अप", "সাইন আপ", "ਸਾਈਨ ਅੱਪ");
        p("sign_out", "Sign out", "साइन आउट", "Sign out", "साइन आउट", "साइन आउट", "সাইন আউট", "ਸਾਈਨ ਆਊਟ");
        p("g_title", "Google se Sign in karein", "Google से साइन इन करें", "Sign in with Google", "Google से साइन इन करीं", "Google ने साइन इन करा", "Google দিয়ে সাইন ইন", "Google ਨਾਲ ਸਾਈਨ ਇਨ ਕਰੋ");
        p("g_sub", "Gmail, YouTube aur Google ek saath", "Gmail, YouTube और Google एक साथ", "Gmail, YouTube & Google together", "Gmail, YouTube आ Google एक साथे", "Gmail, YouTube आणि Google एकत्र", "Gmail, YouTube ও Google একসাথে", "Gmail, YouTube ਤੇ Google ਇਕੱਠੇ");
        p("g_on", "Google account juda hai ✓", "Google खाता जुड़ा है ✓", "Google account connected ✓", "Google खाता जुड़ल बा ✓", "Google खाते जोडले आहे ✓", "Google অ্যাকাউন্ট যুক্ত ✓", "Google ਖਾਤਾ ਜੁੜਿਆ ਹੈ ✓");
        p("g_on_sub", "Gmail, YouTube sab me login", "Gmail, YouTube सब में लॉगिन", "Signed in to Gmail & YouTube", "Gmail, YouTube सब में लॉगिन", "Gmail, YouTube सगळीकडे लॉगिन", "Gmail, YouTube সবেতে লগইন", "Gmail, YouTube ਸਭ ਵਿੱਚ ਲੌਗਇਨ");
        p("sign_out_t", "Sign out karein?", "साइन आउट करें?", "Sign out?", "साइन आउट करीं?", "साइन आउट करायचे?", "সাইন আউট করবেন?", "ਸਾਈਨ ਆਊਟ ਕਰਨਾ ਹੈ?");
        p("sign_out_m", "Google, YouTube aur Gmail se sign out ho jayenge.", "Google, YouTube और Gmail से साइन आउट हो जाएंगे।", "You'll be signed out of Google, YouTube and Gmail.", "Google, YouTube आ Gmail से साइन आउट हो जाईब।", "Google, YouTube आणि Gmail मधून साइन आउट व्हाल.", "Google, YouTube ও Gmail থেকে সাইন আউট হবেন।", "Google, YouTube ਤੇ Gmail ਤੋਂ ਸਾਈਨ ਆਊਟ ਹੋ ਜਾਓਗੇ।");
        p("clear_data_t", "Data clear karein?", "डेटा साफ़ करें?", "Clear browsing data?", "डेटा साफ करीं?", "डेटा साफ करायचा?", "ডেটা মুছবেন?", "ਡਾਟਾ ਸਾਫ਼ ਕਰਨਾ ਹੈ?");
        p("clear_data_m", "Cache, cookies, history aur site data hat jayega. Bookmarks aur downloads safe rahenge.", "कैश, कुकीज़, इतिहास और साइट डेटा हट जाएगा। बुकमार्क और डाउनलोड सुरक्षित रहेंगे।", "Cache, cookies, history and site data will be removed. Bookmarks and downloads stay safe.", "कैश, कुकीज़, इतिहास आ साइट डेटा हट जाई। बुकमार्क आ डाउनलोड सुरक्षित रही।", "कॅशे, कुकीज, इतिहास व साइट डेटा हटेल. बुकमार्क व डाउनलोड सुरक्षित राहतील.", "ক্যাশ, কুকি, ইতিহাস ও সাইট ডেটা মুছে যাবে। বুকমার্ক ও ডাউনলোড নিরাপদ থাকবে।", "ਕੈਸ਼, ਕੁਕੀਜ਼, ਇਤਿਹਾਸ ਤੇ ਸਾਈਟ ਡਾਟਾ ਹਟ ਜਾਵੇਗਾ। ਬੁੱਕਮਾਰਕ ਤੇ ਡਾਊਨਲੋਡ ਸੁਰੱਖਿਅਤ ਰਹਿਣਗੇ।");
        p("vpn", "Free VPN", "फ्री VPN", "Free VPN", "फ्री VPN", "मोफत VPN", "ফ্রি VPN", "ਮੁਫ਼ਤ VPN");
        p("reader", "Reader mode", "पढ़ने का मोड", "Reader mode", "पढ़े वाला मोड", "वाचन मोड", "রিডার মোড", "ਪੜ੍ਹਨ ਮੋਡ");
        p("read_aloud", "Bolkar padhe", "बोलकर पढ़ें", "Read aloud", "बोल के पढ़ीं", "मोठ्याने वाचा", "জোরে পড়ুন", "ਬੋਲ ਕੇ ਪੜ੍ਹੋ");
        p("translate", "Anuvad", "अनुवाद", "Translate", "अनुवाद", "भाषांतर", "অনুবাদ", "ਅਨੁਵਾਦ");
        p("screenshot", "Screenshot", "स्क्रीनशॉट", "Screenshot", "स्क्रीनशॉट", "स्क्रीनशॉट", "স্ক্রিনশট", "ਸਕਰੀਨਸ਼ਾਟ");
        p("add_home", "Home screen par", "होम स्क्रीन पर", "Add to Home", "होम स्क्रीन पर", "होम स्क्रीनवर", "হোম স্ক্রিনে", "ਹੋਮ ਸਕਰੀਨ 'ਤੇ");
        p("recent", "Band tabs", "बंद टैब", "Recent tabs", "बंद टैब", "बंद टॅब", "বন্ধ ট্যাব", "ਬੰਦ ਟੈਬਾਂ");
        p("source", "Page source", "पेज सोर्स", "Page source", "पेज सोर्स", "पेज सोर्स", "পেজ সোর্স", "ਪੇਜ ਸੋਰਸ");
        p("notifications", "Notifications", "सूचनाएं", "Notifications", "सूचना", "सूचना", "বিজ্ঞপ্তি", "ਸੂਚਨਾਵਾਂ");
        p("tools", "Tools", "टूल्स", "Tools", "टूल्स", "साधने", "টুলস", "ਟੂਲ");
        p("quick_toggles", "Jaldi badlein", "झटपट बदलें", "Quick toggles", "झटपट बदलीं", "झटपट बदल", "দ্রুত বদল", "ਝਟਪਟ ਬਦਲੋ");
        p("default_browser", "Default browser banayein", "डिफ़ॉल्ट ब्राउज़र बनाएं", "Set as default browser", "डिफ़ॉल्ट ब्राउज़र बनाईं", "डिफॉल्ट ब्राउझर बनवा", "ডিফল্ট ব্রাউজার করুন", "ਡਿਫ਼ਾਲਟ ਬ੍ਰਾਊਜ਼ਰ ਬਣਾਓ");
        p("is_default", "Baatora default browser hai ✓", "Baatora डिफ़ॉल्ट ब्राउज़र है ✓", "Baatora is your default browser ✓", "Baatora डिफ़ॉल्ट ब्राउज़र बा ✓", "Baatora डिफॉल्ट ब्राउझर आहे ✓", "Baatora ডিফল্ট ব্রাউজার ✓", "Baatora ਡਿਫ਼ਾਲਟ ਬ੍ਰਾਊਜ਼ਰ ਹੈ ✓");
        p("js", "JavaScript", "JavaScript", "JavaScript", "JavaScript", "JavaScript", "JavaScript", "JavaScript");
        p("js_sub", "Websites ke features chalaye", "वेबसाइट के फीचर चलाए", "Run website features", "वेबसाइट के फीचर चलाईं", "वेबसाइटची वैशिष्ट्ये चालवा", "ওয়েবসাইটের ফিচার চালায়", "ਵੈੱਬਸਾਈਟ ਦੇ ਫੀਚਰ ਚਲਾਓ");
        p("safe", "Safe Browsing", "सुरक्षित ब्राउज़िंग", "Safe Browsing", "सुरक्षित ब्राउज़िंग", "सुरक्षित ब्राउझिंग", "নিরাপদ ব্রাউজিং", "ਸੁਰੱਖਿਅਤ ਬ੍ਰਾਊਜ਼ਿੰਗ");
        p("safe_sub", "Khatarnak sites par chetavni", "खतरनाक साइट पर चेतावनी", "Warns about dangerous sites", "खतरनाक साइट पर चेतावनी", "धोकादायक साइटवर इशारा", "বিপজ্জনক সাইটে সতর্কতা", "ਖ਼ਤਰਨਾਕ ਸਾਈਟਾਂ 'ਤੇ ਚੇਤਾਵਨੀ");
        p("tpc", "Third-party cookies", "थर्ड-पार्टी कुकीज़", "Third-party cookies", "थर्ड-पार्टी कुकीज़", "थर्ड-पार्टी कुकीज", "থার্ড-পার্টি কুকি", "ਥਰਡ-ਪਾਰਟੀ ਕੁਕੀਜ਼");
        p("tpc_sub", "Doosri sites ki cookies allow", "दूसरी साइट की कुकीज़ की अनुमति", "Allow cookies from other sites", "दोसर साइट के कुकीज़", "इतर साइटच्या कुकीज", "অন্য সাইটের কুকি", "ਹੋਰ ਸਾਈਟਾਂ ਦੀਆਂ ਕੁਕੀਜ਼");
        p("autoplay", "Video autoplay", "वीडियो ऑटोप्ले", "Video autoplay", "वीडियो ऑटोप्ले", "व्हिडिओ ऑटोप्ले", "ভিডিও অটোপ্লে", "ਵੀਡੀਓ ਆਟੋਪਲੇ");
        p("autoplay_sub", "Video apne aap chalein", "वीडियो अपने आप चलें", "Videos play automatically", "वीडियो अपने आप चले", "व्हिडिओ आपोआप चालतील", "ভিডিও নিজে চলবে", "ਵੀਡੀਓ ਆਪੇ ਚੱਲਣ");
        p("restore", "Tabs yaad rakhein", "टैब याद रखें", "Restore tabs", "टैब याद राखीं", "टॅब लक्षात ठेवा", "ট্যাব মনে রাখুন", "ਟੈਬਾਂ ਯਾਦ ਰੱਖੋ");
        p("restore_sub", "App kholne par purane tabs wapas", "ऐप खोलने पर पुराने टैब वापस", "Reopen your tabs on start", "ऐप खोले पर पुरान टैब वापस", "ॲप उघडल्यावर जुने टॅब परत", "অ্যাপ খুললে পুরনো ট্যাব ফেরত", "ਐਪ ਖੋਲ੍ਹਣ 'ਤੇ ਪੁਰਾਣੀਆਂ ਟੈਬਾਂ");
        p("ask_dl", "Download se pehle poochhein", "डाउनलोड से पहले पूछें", "Ask before download", "डाउनलोड से पहिले पूछीं", "डाउनलोडपूर्वी विचारा", "ডাউনলোডের আগে জিজ্ঞাসা", "ਡਾਊਨਲੋਡ ਤੋਂ ਪਹਿਲਾਂ ਪੁੱਛੋ");
        p("notif_toggle", "Download notifications", "डाउनलोड सूचनाएं", "Download notifications", "डाउनलोड सूचना", "डाउनलोड सूचना", "ডাউনলোড বিজ্ঞপ্তি", "ਡਾਊਨਲੋਡ ਸੂਚਨਾਵਾਂ");
        p("s_advanced", "Advanced", "एडवांस्ड", "Advanced", "एडवांस", "प्रगत", "অ্যাডভান্সড", "ਐਡਵਾਂਸਡ");
        p("vpn_on", "VPN chalu hai", "VPN चालू है", "VPN is ON", "VPN चालू बा", "VPN चालू आहे", "VPN চালু আছে", "VPN ਚਾਲੂ ਹੈ");
        p("vpn_off", "VPN band hai", "VPN बंद है", "VPN is OFF", "VPN बंद बा", "VPN बंद आहे", "VPN বন্ধ আছে", "VPN ਬੰਦ ਹੈ");
        p("vpn_start", "Free VPN chalu karein", "फ्री VPN चालू करें", "Turn on free VPN", "फ्री VPN चालू करीं", "मोफत VPN चालू करा", "ফ্রি VPN চালু করুন", "ਮੁਫ਼ਤ VPN ਚਾਲੂ ਕਰੋ");
        p("mark_read", "Sab padh liya", "सब पढ़ लिया", "Mark all read", "सब पढ़ लिहनी", "सर्व वाचले", "সব পড়া হয়েছে", "ਸਭ ਪੜ੍ਹ ਲਿਆ");
        p("empty_notif", "Koi nayi suchna nahi", "कोई नई सूचना नहीं", "No notifications", "कवनो नया सूचना नइखे", "नवीन सूचना नाही", "কোনো বিজ্ঞপ্তি নেই", "ਕੋਈ ਨਵੀਂ ਸੂਚਨਾ ਨਹੀਂ");
        p("khabar", "📺 Khabar aur Manoranjan", "📺 खबर और मनोरंजन", "📺 News & Entertainment", "📺 खबर आ मनोरंजन", "📺 बातम्या व मनोरंजन", "📺 খবর ও বিনোদন", "📺 ਖ਼ਬਰਾਂ ਤੇ ਮਨੋਰੰਜਨ");
        p("data_today", "Aaj ka data", "आज का डेटा", "Data today", "आज के डेटा", "आजचा डेटा", "আজকের ডেটা", "ਅੱਜ ਦਾ ਡਾਟਾ");
        p("turbo", "Turbo download ⚡", "टर्बो डाउनलोड ⚡", "Turbo download ⚡", "टर्बो डाउनलोड ⚡", "टर्बो डाउनलोड ⚡", "টার্বো ডাউনলোড ⚡", "ਟਰਬੋ ਡਾਊਨਲੋਡ ⚡");
        p("turbo_sub", "File ko 4-6 hisson me ek saath laata hai", "फ़ाइल को 4-6 हिस्सों में एक साथ लाता है", "Downloads files in 4-6 parts at once", "फ़ाइल के 4-6 हिस्सा में एक साथे लावेला", "फाइल 4-6 भागांत एकत्र आणतो", "ফাইল ৪-৬ ভাগে একসাথে নামায়", "ਫ਼ਾਈਲ ਨੂੰ 4-6 ਹਿੱਸਿਆਂ ਵਿੱਚ ਇਕੱਠੇ ਲਿਆਉਂਦਾ ਹੈ");
        p("bottom_nav", "Neeche navigation bar", "नीचे नेविगेशन बार", "Bottom navigation bar", "नीचे नेविगेशन बार", "खालचा नेव्हिगेशन बार", "নিচের নেভিগেশন বার", "ਹੇਠਾਂ ਨੈਵੀਗੇਸ਼ਨ ਬਾਰ");
        p("bottom_nav_sub", "Band karne par buttons upar aa jayenge", "बंद करने पर बटन ऊपर आ जाएंगे", "When off, buttons move to the top", "बंद कइला पर बटन ऊपर आ जाई", "बंद केल्यावर बटणे वर येतील", "বন্ধ করলে বোতাম উপরে যাবে", "ਬੰਦ ਕਰਨ 'ਤੇ ਬਟਨ ਉੱਪਰ ਆ ਜਾਣਗੇ");
        p("auto_hide", "Scroll par bar chhupayein", "स्क्रॉल पर बार छुपाएं", "Hide bar on scroll", "स्क्रॉल पर बार लुकाईं", "स्क्रोलवर बार लपवा", "স্ক্রলে বার লুকান", "ਸਕ੍ਰੋਲ 'ਤੇ ਬਾਰ ਲੁਕਾਓ");
        p("auto_hide_sub", "Neeche scroll karne par zyada jagah", "नीचे स्क्रॉल करने पर ज़्यादा जगह", "More space while scrolling down", "नीचे स्क्रॉल कइला पर ज़्यादा जगह", "खाली स्क्रोल करताना जास्त जागा", "নিচে স্ক্রল করলে বেশি জায়গা", "ਹੇਠਾਂ ਸਕ੍ਰੋਲ ਕਰਨ 'ਤੇ ਵੱਧ ਥਾਂ");
        p("f_today", "Aaj", "आज", "Today", "आज", "आज", "আজ", "ਅੱਜ");
        p("f_week", "7 din", "7 दिन", "7 days", "7 दिन", "7 दिवस", "৭ দিন", "7 ਦਿਨ");
        p("f_month", "30 din", "30 दिन", "30 days", "30 दिन", "30 दिवस", "৩০ দিন", "30 ਦਿਨ");
        p("f_year", "1 saal", "1 साल", "1 year", "1 साल", "1 वर्ष", "১ বছর", "1 ਸਾਲ");
        p("choose_country", "Desh chunein", "देश चुनें", "Choose country", "देश चुनीं", "देश निवडा", "দেশ বেছে নিন", "ਦੇਸ਼ ਚੁਣੋ");
        p("appearance", "Rang mode", "रंग मोड", "Appearance", "रंग मोड", "रंग मोड", "রঙ মোড", "ਰੰਗ ਮੋਡ");
        p("mode_light", "Light", "लाइट", "Light", "उजियार", "लाइट", "লাইট", "ਲਾਈਟ");
        p("mode_dark", "Dark", "डार्क", "Dark", "अन्हार", "डार्क", "ডার্ক", "ਡਾਰਕ");
        p("mode_default", "System default", "सिस्टम डिफ़ॉल्ट", "System default", "सिस्टम डिफ़ॉल्ट", "सिस्टम डिफॉल्ट", "সিস্টেম ডিফল্ট", "ਸਿਸਟਮ ਡਿਫ਼ਾਲਟ");
        p("voice_prompt", "Boliye…", "बोलिए…", "Speak now…", "बोलीं…", "बोला…", "বলুন…", "ਬੋਲੋ…");
        p("most_visited", "🔥 Sabse zyada khule", "🔥 सबसे ज़्यादा खुले", "🔥 Most visited", "🔥 सबसे ज़्यादा खुलल", "🔥 सर्वाधिक भेटी", "🔥 সবচেয়ে বেশি দেখা", "🔥 ਸਭ ਤੋਂ ਵੱਧ ਖੋਲ੍ਹੇ");
        p("copied_link", "Copy kiya link kholein", "कॉपी किया लिंक खोलें", "Open copied link", "कॉपी कइल लिंक खोलीं", "कॉपी केलेली लिंक उघडा", "কপি করা লিংক খুলুন", "ਕਾਪੀ ਕੀਤਾ ਲਿੰਕ ਖੋਲ੍ਹੋ");
    }
}
