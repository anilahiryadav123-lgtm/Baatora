package com.baatora.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.view.View;

/** Ghoomti hui chamakdar ring — 3D intro aur About page ke liye. */
class RingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final int c1, c2;
    private final float strokePx;
    private float phase;

    RingView(Context c, int c1, int c2, float strokePx) {
        super(c);
        this.c1 = c1;
        this.c2 = c2;
        this.strokePx = strokePx;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(strokePx);
    }

    void setPhase(float p) { phase = p; invalidate(); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        paint.setShader(new SweepGradient(w / 2f, h / 2f,
                new int[]{c1 & 0x00FFFFFF, c1, c2, c2 & 0x00FFFFFF}, new float[]{0f, 0.35f, 0.8f, 1f}));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = Math.min(w, h) / 2f - strokePx;
        box.set(w / 2f - r, h / 2f - r, w / 2f + r, h / 2f + r);
        canvas.save();
        canvas.rotate(phase, w / 2f, h / 2f);
        canvas.drawArc(box, 0, 330, false, paint);
        canvas.restore();
    }
}
