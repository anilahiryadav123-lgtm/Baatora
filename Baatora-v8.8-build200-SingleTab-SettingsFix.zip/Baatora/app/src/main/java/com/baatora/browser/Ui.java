package com.baatora.browser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Chhote UI helpers: rang, gol kone, icon tiles aur website logos. */
final class Ui {

    static float density = 1f;
    // Theme ke hisaab se badalne wale rang
    static int BAR1 = 0xFF06103A, NAVY2 = 0xFF0D2A8A, BLUE = 0xFF1E5BFF,
            PAGE1 = 0xFF0B1A5E, NAVY = 0xFF06103A, DEEP = 0xFF040A26,
            ORANGE = 0xFFFF8A00, CYAN = 0xFF00E5FF, GOLD = 0xFFFFC107;
    static int MUTED = 0xFFA9B8F0;

    // ── Light / Dark / System default ──
    static boolean LIGHT = false;
    static String MODE = "default";
    static int TEXT = 0xFFFFFFFF, ICON = 0xFFFFFFFF, ACC = 0xFF1E5BFF;
    /** Rangeen button/card ke upar likha text — kabhi nahi badalta. */
    static final int ON_COLOR = 0xFFFFFFFE;
    /** Sunehre/safed button ke upar gehra text. */
    static final int INK = 0xFF0B1033;

    static void applyMode(String mode, String themeKey) {
        MODE = mode == null ? "default" : mode;
        applyTheme(themeKey);
        LIGHT = MODE.equals("light");
        if (LIGHT) {
            BAR1 = 0xFFFFFFFF; NAVY2 = 0xFFF1F4FF; BLUE = 0xFFDCE6FF;
            PAGE1 = 0xFFF6F8FF; NAVY = 0xFFFFFFFF; DEEP = 0xFFECF0FA;
            ORANGE = 0xFFFF7A00; CYAN = 0xFF0091EA; GOLD = 0xFFE65100; ACC = 0xFF1E5BFF;
        } else if (MODE.equals("dark")) {
            BAR1 = 0xFF121212; NAVY2 = 0xFF1F1F1F; BLUE = 0xFF2C2C2C;
            PAGE1 = 0xFF171717; NAVY = 0xFF0E0E0E; DEEP = 0xFF000000;
            ORANGE = 0xFFFF8A00; CYAN = 0xFF00E5FF; GOLD = 0xFFFFC107; ACC = 0xFF2979FF;
        } else {
            ACC = BLUE;
        }
        TEXT = LIGHT ? 0xFF14194A : 0xFFFFFFFF;
        ICON = LIGHT ? 0xFF1F2A5C : 0xFFFFFFFF;
        MUTED = LIGHT ? 0xFF5B6487 : 0xFFA9B8F0;
    }

    /** Glass jaisa halka rang: dark mode me safed, light mode me halka gehra. */
    static int gl(int alpha) {
        return LIGHT ? (((int) (alpha * 0.7f)) << 24) | 0x0A1A4A : (alpha << 24) | 0xFFFFFF;
    }

    static final String[] THEME_KEYS = {"original", "tiranga", "kesariya", "hariyali", "gulabi", "jamuni",
            "samundar", "laal", "sunehra", "aasmani", "raat",
            "sunset", "neon", "chai", "lavender", "pudina", "galaxy", "rosegold", "jungle", "chandni"};
    static final String[] THEME_NAMES = {"Original Baatora", "Tiranga 🇮🇳", "Kesariya 🧡", "Hariyali 🌱", "Gulabi 💗",
            "Jamuni 🍇", "Samundar 🌊", "Laal Qila 🏯", "Sunehra ✨", "Aasmani ☁️", "Raat AMOLED 🌑",
            "Sunset 🌇", "Neon ⚡", "Chai ☕", "Lavender 💜", "Pudina 🌿", "Galaxy 🌌", "Rose Gold 🌸", "Jungle 🐯", "Chandni 🌙"};
    // bar1, bar2, bar3, page1, page2, page3, accent1, accent2, gold
    static final int[][] THEMES = {
            {0xFF06103A, 0xFF0D2A8A, 0xFF1E5BFF, 0xFF0B1A5E, 0xFF06103A, 0xFF040A26, 0xFFFF8A00, 0xFF00E5FF, 0xFFFFC107},
            {0xFFE65100, 0xFF0A1A5C, 0xFF138808, 0xFF0A1A5C, 0xFF06103A, 0xFF040A26, 0xFFFF9933, 0xFF2ECC71, 0xFFFFE0B2},
            {0xFF3E1A00, 0xFFA84300, 0xFFFF7A00, 0xFF4A1E00, 0xFF2A1000, 0xFF150800, 0xFFFFB300, 0xFFFF5252, 0xFFFFD54F},
            {0xFF03200F, 0xFF0B5D2A, 0xFF1DB954, 0xFF0B3D1E, 0xFF04200F, 0xFF011008, 0xFFFFC107, 0xFF64FFDA, 0xFFC6FF00},
            {0xFF3A0522, 0xFF8E1356, 0xFFE91E63, 0xFF4A0A2E, 0xFF2A0418, 0xFF14020B, 0xFFFFB300, 0xFFFF80AB, 0xFFFFD180},
            {0xFF1A0533, 0xFF4A148C, 0xFF7C4DFF, 0xFF2E0B5A, 0xFF1A0533, 0xFF0C0219, 0xFFFF6D00, 0xFFE040FB, 0xFFFFD740},
            {0xFF002A30, 0xFF00606E, 0xFF00ACC1, 0xFF00404A, 0xFF002227, 0xFF001114, 0xFFFFAB40, 0xFF64FFDA, 0xFF84FFFF},
            {0xFF2A0505, 0xFF8B1A1A, 0xFFE53935, 0xFF4A0C0C, 0xFF2A0505, 0xFF140202, 0xFFFFC107, 0xFFFF8A65, 0xFFFFD54F},
            {0xFF2B1D05, 0xFF6D4C14, 0xFFC8962E, 0xFF3A2808, 0xFF1F1505, 0xFF100A02, 0xFFFFD54F, 0xFFFFAB40, 0xFFFFE082},
            {0xFF0D47A1, 0xFF1976D2, 0xFF29B6F6, 0xFF0B3C7A, 0xFF082A57, 0xFF041A38, 0xFFFF7043, 0xFFFFEB3B, 0xFFFFF59D},
            {0xFF000000, 0xFF141414, 0xFF2A2A2A, 0xFF121212, 0xFF000000, 0xFF000000, 0xFFFF8A00, 0xFF00E5FF, 0xFFFFC107},
            // Sunset
            {0xFF3B0A2E, 0xFF9C2C5E, 0xFFFF6B3D, 0xFF4A1038, 0xFF2B0A24, 0xFF14050F, 0xFFFFB74D, 0xFFFF80AB, 0xFFFFE082},
            // Neon
            {0xFF000F0A, 0xFF003D2B, 0xFF00E676, 0xFF021A12, 0xFF010D09, 0xFF000504, 0xFFFFEA00, 0xFF00E5FF, 0xFF76FF03},
            // Chai
            {0xFF2A1A12, 0xFF5D4037, 0xFF8D6E63, 0xFF3E2723, 0xFF22140F, 0xFF110A07, 0xFFFFB74D, 0xFFFFCC80, 0xFFFFE0B2},
            // Lavender
            {0xFF1E1B4B, 0xFF4338CA, 0xFF818CF8, 0xFF2E2A6B, 0xFF1A1745, 0xFF0D0B26, 0xFFF9A8D4, 0xFFC4B5FD, 0xFFFDE68A},
            // Pudina
            {0xFF04252B, 0xFF0F766E, 0xFF2DD4BF, 0xFF063B42, 0xFF042A30, 0xFF021A1E, 0xFFFFD166, 0xFF99F6E4, 0xFFBEF264},
            // Galaxy
            {0xFF0B0620, 0xFF3B1D8F, 0xFFD946EF, 0xFF150A3A, 0xFF0B0620, 0xFF05030F, 0xFF22D3EE, 0xFFF472B6, 0xFFFDE047},
            // Rose Gold
            {0xFF3B1F26, 0xFF8A4B5A, 0xFFE8A0A8, 0xFF4A2A32, 0xFF2D171C, 0xFF170B0E, 0xFFF7C59F, 0xFFFFD6DA, 0xFFFFE4C7},
            // Jungle
            {0xFF0A1F0D, 0xFF2E5D1E, 0xFF7CB518, 0xFF12301A, 0xFF0A1F0D, 0xFF040E05, 0xFFFFA000, 0xFFB9F6CA, 0xFFFFEE58},
            // Chandni
            {0xFF1B2330, 0xFF3C4A5E, 0xFF90A4AE, 0xFF263040, 0xFF161D28, 0xFF0A0E14, 0xFF80DEEA, 0xFFCFD8DC, 0xFFFFF59D}
    };
    static int themeIdx = 0;

    static void applyTheme(String key) {
        themeIdx = 0;
        for (int i = 0; i < THEME_KEYS.length; i++) if (THEME_KEYS[i].equals(key)) themeIdx = i;
        int[] t = THEMES[themeIdx];
        BAR1 = t[0]; NAVY2 = t[1]; BLUE = t[2];
        PAGE1 = t[3]; NAVY = t[4]; DEEP = t[5];
        ORANGE = t[6]; CYAN = t[7]; GOLD = t[8];
    }

    static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    static GradientDrawable pageBg() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{PAGE1, NAVY, DEEP});
    }

    static GradientDrawable barBg() {
        return new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BAR1, NAVY2, BLUE});
    }

    static final int[][] PALETTE = {
            {0xFFFF9800, 0xFFFF5722}, {0xFF448AFF, 0xFF1A3FD8}, {0xFF00E5FF, 0xFF0091EA},
            {0xFFFF4081, 0xFFC51162}, {0xFFB388FF, 0xFF6200EA}, {0xFFFFD740, 0xFFFF9100},
            {0xFF64FFDA, 0xFF00897B}, {0xFFFF8A80, 0xFFD50000}
    };

    private Ui() {}

    static int dp(float v) { return (int) (v * density + 0.5f); }

    static GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    static GradientDrawable grad(int c1, int c2, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    static GradientDrawable stroke(GradientDrawable g, int color, float widthDp) {
        g.setStroke(dp(widthDp), color);
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color == Color.WHITE ? TEXT : color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static ImageView icon(Context c, int res, int tint) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(res);
        iv.setColorFilter(tint);
        return iv;
    }

    static ImageView iconButton(Context c, int res, View.OnClickListener l) {
        ImageView iv = icon(c, res, ICON);
        iv.setPadding(dp(10), dp(10), dp(10), dp(10));
        ripple(iv, true);
        iv.setOnClickListener(l);
        return iv;
    }

    static void ripple(View v, boolean borderless) {
        TypedValue tv = new TypedValue();
        v.getContext().getTheme().resolveAttribute(borderless
                ? android.R.attr.selectableItemBackgroundBorderless
                : android.R.attr.selectableItemBackground, tv, true);
        v.setForeground(v.getContext().getDrawable(tv.resourceId));
        v.setClickable(true);
    }

    /** Gradient squircle ke andar safed icon (menu ke liye). */
    static FrameLayout iconTile(Context c, int res, int[] colors, int sizeDp) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(grad(colors[0], colors[1], sizeDp * 0.34f));
        f.setElevation(dp(5));
        ImageView iv = icon(c, res, Color.WHITE);
        int pad = dp(sizeDp * 0.24f);
        iv.setPadding(pad, pad, pad, pad);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        return f;
    }

    /** Website ka asli logo (favicon), na mile to rangeen pehla akshar. */
    static FrameLayout siteIcon(Context c, String name, String host, int sizeDp) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(round(Color.WHITE, sizeDp * 0.3f));
        f.setClipToOutline(true);
        String letter = (name == null || name.trim().isEmpty()) ? "?" : name.trim().substring(0, 1).toUpperCase();
        int[] pal = PALETTE[Math.abs((host == null ? letter : host).hashCode()) % PALETTE.length];
        TextView t = text(c, letter, sizeDp * 0.42f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(grad(pal[0], pal[1], sizeDp * 0.3f));
        f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        ImageView iv = new ImageView(c);
        int pad = dp(sizeDp * 0.16f);
        iv.setPadding(pad, pad, pad, pad);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        favicon(iv, host, t);
        return f;
    }

    // ───── Favicon loader (chhota cache ke saath) ─────
    static final LruCache<String, Bitmap> CACHE = new LruCache<>(120);
    static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void favicon(ImageView iv, String host, View hideOnLoad) {
        if (host == null || host.isEmpty()) return;
        iv.setTag(host);
        Bitmap cached = CACHE.get(host);
        if (cached != null) { show(iv, cached, hideOnLoad); return; }
        POOL.execute(() -> {
            Bitmap bm = null;
            try {
                HttpURLConnection con = (HttpURLConnection) new URL(
                        "https://www.google.com/s2/favicons?sz=64&domain=" + host).openConnection();
                con.setConnectTimeout(6000);
                con.setReadTimeout(6000);
                InputStream in = con.getInputStream();
                bm = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) {}
            // Google 16px ka default globe deta hai jab logo na mile — use chhod do
            final Bitmap fb = (bm != null && bm.getWidth() > 16) ? bm : null;
            if (fb != null) CACHE.put(host, fb);
            MAIN.post(() -> { if (fb != null && host.equals(iv.getTag())) show(iv, fb, hideOnLoad); });
        });
    }

    private static void show(ImageView iv, Bitmap b, View hide) {
        iv.setImageBitmap(b);
        iv.setBackgroundColor(Color.WHITE);
        if (hide != null) hide.setVisibility(View.INVISIBLE);
    }
}
