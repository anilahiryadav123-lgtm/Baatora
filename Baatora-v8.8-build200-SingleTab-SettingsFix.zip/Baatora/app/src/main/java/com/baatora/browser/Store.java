package com.baatora.browser;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.TrafficStats;
import android.os.Process;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Chhoti shared cheezein: notifications, aaj ka data, aaj ke roke gaye ads. */
final class Store {
    private Store() {}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("baatora", Context.MODE_PRIVATE); }

    static JSONArray load(Context c, String key) {
        try { return new JSONArray(prefs(c).getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    static synchronized void addNotif(Context c, String type, String title, String msg) {
        try {
            JSONArray old = load(c, "notifs"), arr = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("t", title);
            o.put("m", msg);
            o.put("time", System.currentTimeMillis());
            o.put("read", false);
            arr.put(o);
            for (int i = 0; i < old.length() && arr.length() < 60; i++) arr.put(old.get(i));
            prefs(c).edit().putString("notifs", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).format(new Date()); }

    /** Aaj Baatora ne kitna internet data use kiya (bytes). Phone restart ko bhi sambhalta hai. */
    static synchronized long dataToday(Context c) {
        SharedPreferences p = prefs(c);
        long rx = TrafficStats.getUidRxBytes(Process.myUid()), tx = TrafficStats.getUidTxBytes(Process.myUid());
        if (rx < 0 || tx < 0) return -1;
        long cur = rx + tx;
        String day = today();
        long start = p.getLong("dStart", cur), acc = p.getLong("dAcc", 0), last = p.getLong("dLast", cur);
        if (!day.equals(p.getString("dDay", ""))) { start = cur; acc = 0; }
        else if (cur < last) { acc += last - start; start = 0; }
        p.edit().putString("dDay", day).putLong("dStart", start).putLong("dAcc", acc).putLong("dLast", cur).apply();
        return acc + (cur - start);
    }

    static int adsToday(Context c) {
        SharedPreferences p = prefs(c);
        return today().equals(p.getString("adDay", "")) ? p.getInt("adCount", 0) : 0;
    }

    static synchronized void addAds(Context c, int n) {
        if (n <= 0) return;
        SharedPreferences p = prefs(c);
        String day = today();
        int cur = day.equals(p.getString("adDay", "")) ? p.getInt("adCount", 0) : 0;
        p.edit().putString("adDay", day).putInt("adCount", cur + n).apply();
    }
}
