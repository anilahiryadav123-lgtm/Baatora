package com.baatora.browser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Video link ki lambai (seconds) ya size dekhta hai, taaki chhote ad-clips ko download list se hata saken. */
final class MediaProbe {
    private MediaProbe() {}

    /** return {durationSeconds ya -1, sizeBytes ya -1} */
    static long[] probe(String url, String ua, String cookie, String ref) {
        try {
            String p = new URL(url).getPath().toLowerCase();
            if (p.endsWith(".m3u8")) return new long[]{hlsDuration(url, ua, cookie, ref, 0), -1};
            return new long[]{-1, size(url, ua, cookie, ref)};
        } catch (Throwable e) {
            return new long[]{-1, -1};
        }
    }

    private static HttpURLConnection open(String url, String ua, String cookie, String ref) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setInstanceFollowRedirects(true);
        if (ua != null) c.setRequestProperty("User-Agent", ua);
        if (cookie != null) c.setRequestProperty("Cookie", cookie);
        if (ref != null) c.setRequestProperty("Referer", ref);
        c.setRequestProperty("Accept-Encoding", "identity");
        return c;
    }

    private static long size(String url, String ua, String cookie, String ref) {
        try {
            HttpURLConnection c = open(url, ua, cookie, ref);
            c.setRequestMethod("HEAD");
            long n = c.getContentLengthLong();
            int code = c.getResponseCode();
            c.disconnect();
            if (code < 400 && n > 0) return n;
        } catch (Throwable ignored) {}
        try {
            HttpURLConnection c = open(url, ua, cookie, ref);
            c.setRequestProperty("Range", "bytes=0-0");
            int code = c.getResponseCode();
            long n = -1;
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                if (cr != null && cr.contains("/")) n = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim());
            } else if (code == 200) {
                n = c.getContentLengthLong();
            }
            c.disconnect();
            return n;
        } catch (Throwable e) {
            return -1;
        }
    }

    private static String text(String url, String ua, String cookie, String ref, String[] fin) throws Exception {
        HttpURLConnection c = open(url, ua, cookie, ref);
        if (c.getResponseCode() >= 400) throw new java.io.IOException("HTTP");
        fin[0] = c.getURL().toString();
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16 * 1024];
            int n, total = 0;
            while ((n = in.read(buf)) > 0 && total < 2_000_000) { bo.write(buf, 0, n); total += n; }
            return bo.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    private static long hlsDuration(String url, String ua, String cookie, String ref, int depth) throws Exception {
        String[] fin = new String[1];
        String t = text(url, ua, cookie, ref, fin);
        String base = fin[0] == null ? url : fin[0];
        String[] lines = t.split("\\r?\\n");
        if (t.contains("#EXT-X-STREAM-INF")) {
            if (depth > 0) return -1;
            for (int i = 0; i < lines.length; i++) {
                if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue;
                for (int k = i + 1; k < lines.length; k++) {
                    String u = lines[k].trim();
                    if (u.isEmpty() || u.startsWith("#")) continue;
                    return hlsDuration(new URL(new URL(base), u).toString(), ua, cookie, ref, depth + 1);
                }
            }
            return -1;
        }
        double sum = 0;
        for (String ln : lines) {
            if (!ln.startsWith("#EXTINF:")) continue;
            String v = ln.substring(8);
            int cm = v.indexOf(',');
            if (cm >= 0) v = v.substring(0, cm);
            try { sum += Double.parseDouble(v.trim()); } catch (Exception ignored) {}
        }
        return sum > 0 ? (long) sum : -1;
    }
}
