/* Baatora YouTube Ad Block — page ke shuru me hi chalta hai.
   YouTube ke player data se ads ki jaankari hata deta hai, isliye ad load hi nahi hota. */
(function(){
if(window.__btyt)return;window.__btyt=1;
try{if(window.BaatoraCfg&&!BaatoraCfg.ad())return;}catch(e){}

var AD_KEYS=['adPlacements','adSlots','playerAds','adBreakHeartbeatParams','adBreakParams','adParams','adBreakServiceRenderer'];
var AD_ITEM=/^(adSlotRenderer|promotedSparklesWebRenderer|promotedSparklesTextSearchRenderer|promotedVideoRenderer|compactPromotedVideoRenderer|displayAdRenderer|searchPyvRenderer|inFeedAdLayoutRenderer|bannerPromoRenderer|statementBannerRenderer|brandVideoSingletonRenderer|brandVideoShelfRenderer|primetimePromoRenderer|mealbarPromoRenderer|companionAdRenderer|actionCompanionAdRenderer|adActionInterstitialRenderer|textAdRenderer|carouselAdRenderer|movingThumbnailAdRenderer|reelAdRenderer)$/;

function isAdItem(x){
 if(!x||typeof x!=='object'||Array.isArray(x))return false;
 for(var k in x){
  if(AD_ITEM.test(k))return true;
  if(k==='richItemRenderer'||k==='itemSectionRenderer'||k==='shelfRenderer'||k==='richSectionRenderer'){
   var c=x[k]&&(x[k].content||(x[k].contents&&x[k].contents.length===1&&x[k].contents[0]));
   if(c&&typeof c==='object')for(var j in c)if(AD_ITEM.test(j))return true;
  }
  if(k==='reelItemRenderer'||k==='shortsLockupViewModel'){/* normal */}
 }
 return false;
}
function strip(o,depth){
 if(!o||typeof o!=='object'||depth>40)return;
 if(Array.isArray(o)){
  for(var i=o.length-1;i>=0;i--){if(isAdItem(o[i]))o.splice(i,1);else strip(o[i],depth+1);}
  return;
 }
 for(var a=0;a<AD_KEYS.length;a++)if(AD_KEYS[a] in o){try{delete o[AD_KEYS[a]];}catch(e){o[AD_KEYS[a]]=undefined;}}
 for(var k in o){var v=o[k];if(v&&typeof v==='object')strip(v,depth+1);}
}
function clean(o){
 try{
  if(!o||typeof o!=='object')return o;
  var hit=false;
  if(o.playerResponse||o.adPlacements||o.playerAds||o.adSlots||o.contents||o.onResponseReceivedActions||
     o.onResponseReceivedEndpoints||o.onResponseReceivedCommands||o.continuationContents||o.response||Array.isArray(o))hit=true;
  if(hit)strip(o,0);
 }catch(e){}
 return o;
}
window.__btClean=clean;

/* 1) JSON.parse se aane wala data saaf */
try{
 var jp=JSON.parse;
 JSON.parse=function(){var r=jp.apply(this,arguments);
  try{var s=arguments[0];if(typeof s==='string'&&s.length>200&&/"(adPlacements|playerAds|adSlots|adSlotRenderer|promotedSparkles|displayAdRenderer|inFeedAdLayoutRenderer|adBreakHeartbeatParams)"/.test(s))clean(r);}catch(e){}
  return r;};
}catch(e){}

/* 2) fetch().json() aur .text() */
try{
 var rj=Response.prototype.json;
 Response.prototype.json=function(){return rj.apply(this,arguments).then(function(o){return clean(o);});};
 var rt=Response.prototype.text;
 Response.prototype.text=function(){var self=this;return rt.apply(this,arguments).then(function(t){
   try{if(/youtubei\/v1\/(player|next|browse|search|reel)/.test(self.url||'')&&/"(adPlacements|playerAds|adSlots|adSlotRenderer|promotedSparkles|displayAdRenderer)"/.test(t)){
     return JSON.stringify(clean(jp(t)));}}catch(e){}
   return t;});};
}catch(e){}

/* 3) XHR responses */
try{
 var xo=XMLHttpRequest.prototype.open;
 XMLHttpRequest.prototype.open=function(m,u){this.__bturl=String(u||'');return xo.apply(this,arguments);};
 var desc=Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype,'responseText');
 if(desc&&desc.get){Object.defineProperty(XMLHttpRequest.prototype,'responseText',{configurable:true,get:function(){
   var t=desc.get.call(this);
   try{if(this.__bturl&&/youtubei\/v1\/(player|next|browse|search)|get_video_info/.test(this.__bturl)&&/"(adPlacements|playerAds|adSlots|adSlotRenderer)"/.test(t))return JSON.stringify(clean(jp(t)));}catch(e){}
   return t;}});}
}catch(e){}

/* 4) Page ke andar likha hua data (ytInitialPlayerResponse / ytInitialData) */
function trap(name){
 try{var val;Object.defineProperty(window,name,{configurable:true,
  get:function(){return val;},set:function(v){val=clean(v);}});}catch(e){}
}
trap('ytInitialPlayerResponse');trap('ytInitialData');trap('ytInitialReelWatchSequenceResponse');

/* 5) Bache hue ad dabbe CSS se chhupao */
var css='ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,'+
'ad-slot-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,ytm-promoted-sparkles-text-search-renderer,'+
'ytm-statement-banner-renderer,ytd-statement-banner-renderer,ytm-paid-content-overlay-renderer,ytm-mealbar-promo-renderer,'+
'ytm-companion-slot,ytm-display-ad-renderer,ytm-in-feed-ad-layout-renderer,ytm-brand-video-singleton-renderer,ytm-search-pyv-renderer,'+
'ytm-rich-item-renderer:has(ytm-ad-slot-renderer),ytm-rich-item-renderer:has(ad-slot-renderer),ytm-item-section-renderer:has(ytm-ad-slot-renderer),'+
'ytm-rich-section-renderer:has(ytm-statement-banner-renderer),ytd-rich-item-renderer:has(ytd-ad-slot-renderer),'+
'ytm-reel-shelf-renderer:has(ad-slot-renderer),ytm-merch-shelf-renderer,ytm-product-list-item-renderer,'+
'.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-module .ytp-ad-overlay-slot,#player-ads,#masthead-ad,'+
'.ytm-promoted-sparkles-web-renderer,.video-ads .ytp-ad-overlay-slot,ytm-engagement-panel-section-list-renderer[target-id*=ads],'+
'#tads,#tadsb,#bottomads,[data-text-ad],.commercial-unit-mobile-top,.uEierd{display:none!important}';
function addCss(){try{if(document.getElementById('bt-ytcss'))return;var s=document.createElement('style');s.id='bt-ytcss';s.textContent=css;
 (document.head||document.documentElement).appendChild(s);}catch(e){}}
addCss();document.addEventListener('DOMContentLoaded',addCss);

/* 6) Agar phir bhi koi ad chal jaye to turant skip */
var muted=false;
setInterval(function(){try{
 var p=document.querySelector('.ad-showing,.ad-interrupting');
 var v=document.querySelector('.html5-video-player video,video');
 if(p&&v){
  muted=true;v.muted=true;
  try{v.playbackRate=16;}catch(e){}
  if(isFinite(v.duration)&&v.duration>0&&v.currentTime<v.duration-0.2){try{v.currentTime=v.duration-0.05;}catch(e){}}
  var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-slot button,'+
   '.ytm-skip-ad-button,button[class*=skip-ad],button[class*=skip_ad],.ytp-ad-skip-button-container button');
  if(b)b.click();
 }else if(muted&&v){muted=false;v.muted=false;try{v.playbackRate=1;}catch(e){}}
 var c=document.querySelector('.ytp-ad-overlay-close-button');if(c)c.click();
 /* "Video paused. Continue watching?" ko apne aap haan */
 var cw=document.querySelector('ytm-dialog-renderer .yt-spec-button-shape-next, yt-confirm-dialog-renderer #confirm-button');
 if(cw&&/continue|jaari|haan|yes/i.test(cw.textContent||''))cw.click();
}catch(e){}},300);
})();
